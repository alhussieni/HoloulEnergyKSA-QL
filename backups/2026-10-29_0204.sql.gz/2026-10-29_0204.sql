--
-- PostgreSQL database dump
--

\restrict qw6NzOHu54DVL1C8oxp9MY0bNyi9xBw7X6qcqIUxiyZy2zdBhRERjg8RZcshubQ

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: assets_warranty_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assets_warranty_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if coalesce(current_setting('app.warranty_issuing', true), '') = 'on' then
    if tg_op = 'DELETE' then return old; else return new; end if;
  end if;
  if tg_op = 'DELETE' then
    if old.is_legacy then return old; end if;
    raise exception 'Warranty-bound assets can only be removed together with their certificate.';
  end if;
  if old.is_legacy then return new; end if;
  if (new.customer_id, new.asset_type, new.manufacturer, new.model, new.serial_number, new.quantity,
      new.warranty_start_date, new.warranty_end_date, new.warranty_years, new.performance_warranty_years,
      new.performance_warranty_end_date, new.warranty_number, new.is_legacy)
     is distinct from
     (old.customer_id, old.asset_type, old.manufacturer, old.model, old.serial_number, old.quantity,
      old.warranty_start_date, old.warranty_end_date, old.warranty_years, old.performance_warranty_years,
      old.performance_warranty_end_date, old.warranty_number, old.is_legacy) then
    raise exception 'Warranty data on an asset backed by a certificate is frozen.';
  end if;
  return new;
end $$;


--
-- Name: assets_warranty_insert_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assets_warranty_insert_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if coalesce(new.is_legacy, false) = false
     and coalesce(current_setting('app.warranty_issuing', true), '') <> 'on'
     and (new.warranty_number is not null or new.warranty_start_date is not null
          or new.warranty_end_date is not null or coalesce(new.warranty_years, 0) > 0
          or coalesce(new.performance_warranty_years, 0) > 0) then
    raise exception 'لا يمكن إضافة ضمان لأصل يدويًا — الضمان بيتصدر بس من فاتورة مسددة ومعتمدة (شاشة الفواتير ← 🛡️ الضمان)';
  end if;
  return new;
end $$;


--
-- Name: build_ql_code(jsonb, text, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.build_ql_code(p_snapshot jsonb, p_phone text, p_created timestamp with time zone) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    SET search_path TO 'public'
    AS $_$
declare
  fq jsonb := p_snapshot->'frozenQuote';
  t jsonb := coalesce(p_snapshot->'toggles', '{}'::jsonb);
  inst boolean; sup boolean; scope text; panel text; ph text;
begin
  if fq is null or fq->>'invKW' is null then return null; end if;
  inst := coalesce((t->>'civilworks')::boolean, false) or coalesce((t->>'elecworks')::boolean, false);
  sup  := coalesce((t->>'supply')::boolean, false);
  scope := case when not inst then 'SUP' when sup then 'SI' else 'INS' end;
  panel := regexp_replace(regexp_replace(coalesce(fq->>'panelLabel',''), '\s+', '', 'g'), 'W$', '');
  ph := regexp_replace(coalesce(p_phone,''), '\D', '', 'g');
  return 'QL-' || to_char(p_created at time zone 'Asia/Riyadh', 'DDMonYYYY')
    || '-P-' || coalesce(fq->>'hp', '') || ' HP-' || coalesce(fq->>'invBrandName', 'VEICHI') || ' ' || (fq->>'invKW') || ' KW-'
    || panel || '-' || coalesce(p_snapshot->>'structureType', '') || '-' || scope
    || case when length(ph) >= 4 then '-' || right(ph, 4) else '' end;
end $_$;


--
-- Name: cart_safe_num(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cart_safe_num(t text) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    SET search_path TO 'public'
    AS $_$
  select case when replace(coalesce(t, ''), ',', '') ~ '^\s*-?[0-9]+(\.[0-9]+)?\s*$'
              then btrim(replace(t, ',', ''))::numeric else null end
$_$;


--
-- Name: einvoice_go_live(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.einvoice_go_live() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare n integer;
begin
  if not coalesce((select trial_mode from public.einvoice_config where id = 1), false) then
    raise exception 'Already live.';
  end if;
  perform set_config('app.allow_invoice_delete', 'on', true);
  delete from public.invoices where document_type = 'credit_note';
  delete from public.invoices;
  get diagnostics n = row_count;
  delete from public.invoice_counters;
  update public.einvoice_counters set last_icv = 0 where id = 1;
  update public.einvoice_config set trial_mode = false where id = 1;
  return n;
end $$;


--
-- Name: finance_accept_rfq(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_accept_rfq(p_rfq bigint, p_project bigint) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare r rfqs%rowtype; v_net numeric; v_vr numeric; v_gross numeric; v_proj bigint; v_po bigint; v_first bigint; v_priced int; v_all int; v_desc text; v_tax text; pj record; v_cnt int := 0;
begin
  select * into r from rfqs where id = p_rfq for update;
  if not found then raise exception 'طلب عرض السعر غير موجود'; end if;
  if r.status <> 'quoted' then raise exception 'سجّل رد المورد (الأسعار) الأول قبل القبول'; end if;
  select vat_rate / 100.0 into v_vr from finance_settings where id = 1;
  v_tax := case when r.vat_mode = 'none' or not r.valid_invoice then 'none' else 'recoverable' end;
  select count(*) filter (where unit_price is not null), count(*) into v_priced, v_all from rfq_items where rfq_id = p_rfq;

  if r.is_multi then
    for pj in select distinct nullif(a->>'project_id','')::bigint as project_id
                from rfq_items i, jsonb_array_elements(i.alloc) a where i.rfq_id = p_rfq and i.alloc is not null loop
      v_net := fn_rfq_project_net(p_rfq, pj.project_id);
      if v_net <= 0 then continue; end if;
      v_gross := case when r.vat_mode = 'excl' then round(v_net * (1 + v_vr), 2) else round(v_net, 2) end;
      v_desc := 'حسب عرض سعر المورد RFQ-' || lpad(r.id::text, 4, '0') || ' (طلب مشترك — حصة المشروع)'
             || case when v_priced < v_all then ' (' || v_priced || ' من ' || v_all || ' بنود مسعّرة)' else '' end;
      insert into purchase_orders (supplier_id, project_id, amount, tax_treatment, description, rfq_id)
      values (r.supplier_id, pj.project_id, v_gross, v_tax, v_desc, r.id) returning id into v_po;
      if v_first is null then v_first := v_po; end if;
      v_cnt := v_cnt + 1;
    end loop;
    if v_cnt = 0 then raise exception 'إجمالي العرض صفر'; end if;
    update rfqs set status = 'accepted', po_id = v_first, decided_at = now() where id = p_rfq;
    return v_first;
  end if;

  select coalesce(sum(qty * unit_price), 0) into v_net from rfq_items where rfq_id = p_rfq;
  if r.lump_total is not null then v_net := r.lump_total; end if;
  v_gross := case when r.vat_mode = 'excl' then round(v_net * (1 + v_vr), 2) else round(v_net, 2) end;
  if v_gross <= 0 then raise exception 'إجمالي العرض صفر'; end if;
  v_proj := coalesce(p_project, r.project_id);
  v_desc := 'حسب عرض سعر المورد RFQ-' || lpad(r.id::text, 4, '0')
         || case when r.lump_total is not null then ' (سعر إجمالي)' when v_priced < v_all then ' (' || v_priced || ' من ' || v_all || ' بنود)' else '' end;
  insert into purchase_orders (supplier_id, project_id, amount, tax_treatment, description, rfq_id)
  values (r.supplier_id, v_proj, v_gross, v_tax, v_desc, r.id) returning id into v_po;
  update rfqs set status = 'accepted', po_id = v_po, project_id = v_proj, decided_at = now() where id = p_rfq;
  return v_po;
end $$;


--
-- Name: finance_allocate_advance(bigint, bigint, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_allocate_advance(p_entry bigint, p_bill bigint, p_amount numeric) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare e treasury_entries%rowtype; b supplier_bills%rowtype; a numeric(14,2) := round(coalesce(p_amount, 0), 2); v_erem numeric; v_brem numeric;
begin
  if a <= 0 then raise exception 'المبلغ غير صالح'; end if;
  select * into e from treasury_entries where id = p_entry and kind = 'supplier_payment' and bill_id is null;
  if not found then raise exception 'الدفعة المقدّمة غير موجودة'; end if;
  select * into b from supplier_bills where id = p_bill and doc_type = 'invoice';
  if not found then raise exception 'الفاتورة غير موجودة'; end if;
  if e.supplier_id is distinct from b.supplier_id then raise exception 'الدفعة والفاتورة لموردين مختلفين'; end if;
  v_erem := e.amount - coalesce((select sum(amount) from supplier_payment_allocations where entry_id = e.id), 0);
  v_brem := b.amount - coalesce((select sum(amount) from treasury_entries where bill_id = b.id and kind = 'supplier_payment'), 0)
                     - coalesce((select sum(amount) from supplier_payment_allocations where bill_id = b.id), 0);
  if a > v_erem + 0.005 then raise exception 'المتاح من الدفعة المقدّمة (%) أقل من المبلغ', v_erem; end if;
  if a > v_brem + 0.005 then raise exception 'المبلغ أكبر من المتبقي على الفاتورة (%)', v_brem; end if;
  insert into supplier_payment_allocations (entry_id, bill_id, amount) values (e.id, b.id, a)
    on conflict (entry_id, bill_id) do update set amount = supplier_payment_allocations.amount + excluded.amount;
end $$;


--
-- Name: finance_apply_discount(bigint, numeric, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_apply_discount(p_project bigint, p_amount numeric, p_reason text, p_date date) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_cv numeric; v_inc boolean; v_vr numeric; v_paid numeric; v_gross numeric; v_red numeric;
  a numeric(14,2) := round(coalesce(p_amount, 0), 2); v_id bigint;
begin
  if a <= 0 then raise exception 'مبلغ الخصم غير صالح'; end if;
  if p_reason is null or length(btrim(p_reason)) = 0 then raise exception 'اكتب سبب الخصم'; end if;
  select contract_value into v_cv from projects where id = p_project for update;
  if not found then raise exception 'المشروع غير موجود'; end if;
  v_inc := coalesce((select contract_includes_vat from project_finance_flags where project_id = p_project), true);
  select vat_rate / 100.0 into v_vr from finance_settings where id = 1;
  v_paid := coalesce((select sum(amount) from payments where project_id = p_project), 0);
  v_gross := case when v_inc then coalesce(v_cv, 0) else round(coalesce(v_cv, 0) * (1 + v_vr), 2) end;
  if a > v_gross - v_paid then
    raise exception 'الخصم (%) أكبر من المتبقي على العميل (%)', a, round(v_gross - v_paid, 2);
  end if;
  v_red := case when v_inc then a else round(a / (1 + v_vr), 2) end;
  update projects set contract_value = coalesce(contract_value, 0) - v_red where id = p_project;
  insert into project_discounts (project_id, amount, contract_value_reduction, reason, discount_date, created_by)
  values (p_project, a, v_red, btrim(p_reason), coalesce(p_date, current_date), 'admin') returning id into v_id;
  return v_id;
end $$;


--
-- Name: finance_assign_payment(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_assign_payment(p_payment bigint, p_account bigint) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare pay payments%rowtype; v_id bigint;
begin
  select * into pay from payments where id = p_payment;
  if not found then raise exception 'الدفعة غير موجودة'; end if;
  if exists (select 1 from treasury_entries where payment_id = p_payment) then raise exception 'الدفعة مرتبطة بحساب بالفعل'; end if;
  if not exists (select 1 from treasury_accounts where id = p_account and active) then raise exception 'الحساب غير موجود أو غير نشط'; end if;
  insert into treasury_entries (entry_date, account_id, direction, amount, kind, method, notes, project_id, payment_id, created_by)
  values (pay.payment_date, p_account, 'in', pay.amount, 'customer_receipt', pay.method, pay.notes, pay.project_id, pay.id, 'admin')
  returning id into v_id;
  return v_id;
end $$;


--
-- Name: finance_auto_allocate_supplier(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_auto_allocate_supplier(p_supplier bigint) RETURNS numeric
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare b record; v_total numeric := 0;
begin
  for b in select id from supplier_bills where supplier_id = p_supplier and doc_type = 'invoice' order by bill_date, id loop
    v_total := v_total + fn_allocate_bill(b.id);
  end loop;
  return v_total;
end $$;


--
-- Name: finance_create_rfq(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_create_rfq(p jsonb) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_sup bigint := nullif(p->>'supplier_id','')::bigint;
  v_name text := nullif(btrim(coalesce(p->>'supplier_name','')), '');
  v_id bigint; it jsonb; al jsonb; n int := 0; v_label text; v_qty numeric; v_multi boolean := false; v_alloc jsonb; v_aq numeric;
begin
  if v_sup is null and v_name is not null then
    select id into v_sup from suppliers where lower(name) = lower(v_name);
    if v_sup is null then insert into suppliers (name) values (v_name) returning id into v_sup; end if;
  end if;
  if v_sup is null or not exists (select 1 from suppliers where id = v_sup) then raise exception 'اختر المورد أو اكتب اسم مورد جديد'; end if;
  if jsonb_typeof(p->'items') is distinct from 'array' or jsonb_array_length(p->'items') = 0 then raise exception 'اختر بند واحد على الأقل'; end if;
  select exists (select 1 from jsonb_array_elements(p->'items') x where jsonb_typeof(x->'alloc') = 'array') into v_multi;
  insert into rfqs (supplier_id, quote_id, quote_ref, project_id, notes, is_multi)
  values (v_sup, case when v_multi then null else nullif(p->>'quote_id','')::bigint end, nullif(p->>'quote_ref',''),
          case when v_multi then null else nullif(p->>'project_id','')::bigint end, nullif(p->>'notes',''), v_multi)
  returning id into v_id;
  for it in select * from jsonb_array_elements(p->'items') loop
    v_label := btrim(coalesce(it->>'label', ''));
    v_qty := coalesce(nullif(it->>'qty','')::numeric, 0);
    v_alloc := null;
    if v_multi and jsonb_typeof(it->'alloc') = 'array' then
      v_qty := 0; v_alloc := '[]'::jsonb;
      for al in select * from jsonb_array_elements(it->'alloc') loop
        v_aq := coalesce(nullif(al->>'qty','')::numeric, 0);
        if v_aq <= 0 then continue; end if;
        v_qty := v_qty + v_aq;
        v_alloc := v_alloc || jsonb_build_array(jsonb_build_object('quote_id', nullif(al->>'quote_id','')::bigint, 'project_id', nullif(al->>'project_id','')::bigint, 'qty', v_aq));
      end loop;
    elsif v_multi then
      continue;
    end if;
    if v_label = '' then continue; end if;
    if v_qty <= 0 then raise exception 'اكتب كمية صحيحة للبند: %', v_label; end if;
    n := n + 1;
    insert into rfq_items (rfq_id, line_no, label, qty, unit, qty_note, alloc)
    values (v_id, n, v_label, v_qty, nullif(btrim(coalesce(it->>'unit','')), ''), nullif(btrim(coalesce(it->>'qty_note','')), ''), v_alloc);
  end loop;
  if n = 0 then raise exception 'اختر بند واحد على الأقل'; end if;
  return v_id;
end $$;


--
-- Name: finance_delete_bill(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_delete_bill(p_id bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare b supplier_bills%rowtype;
begin
  select * into b from supplier_bills where id = p_id;
  if not found then raise exception 'الفاتورة غير موجودة'; end if;
  if exists (select 1 from treasury_entries where bill_id = p_id) then
    raise exception 'الفاتورة عليها مدفوعات — احذف المدفوعات أولًا';
  end if;
  delete from supplier_bills where id = p_id;
  if b.project_cost_id is not null then delete from project_costs where id = b.project_cost_id; end if;
  if b.expense_id is not null then delete from expenses where id = b.expense_id; end if;
end $$;


--
-- Name: finance_delete_entry(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_delete_entry(p_id bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare e treasury_entries%rowtype;
begin
  select * into e from treasury_entries where id = p_id;
  if not found then raise exception 'الحركة غير موجودة'; end if;
  if e.transfer_group is not null then
    delete from treasury_entries where transfer_group = e.transfer_group;
  elsif e.payment_id is not null then
    delete from payments where id = e.payment_id;
  else
    delete from treasury_entries where id = p_id;
    if e.expense_id is not null then delete from expenses where id = e.expense_id; end if;
    if e.distribution_id is not null then delete from partner_distributions where id = e.distribution_id; end if;
    if e.project_cost_id is not null then delete from project_costs where id = e.project_cost_id; end if;
  end if;
end $$;


--
-- Name: finance_delete_split_payment(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_delete_split_payment(p_group uuid) RETURNS integer
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare r record; n int := 0;
begin
  for r in select id from treasury_entries where payment_group = p_group order by id loop
    perform finance_delete_entry(r.id); n := n + 1;
  end loop;
  if n = 0 then raise exception 'التحويل غير موجود'; end if;
  return n;
end $$;


--
-- Name: finance_edit_bill(bigint, jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_edit_bill(p_id bigint, p jsonb, p_reason text) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  b supplier_bills%rowtype;
  n_date date; n_amt numeric(14,2); n_num text; n_desc text;
  v_old jsonb := '{}'::jsonb; v_new jsonb := '{}'::jsonb;
  v_used numeric; v_id bigint; v_sign int; v_def text; v_cdesc text;
begin
  if p_reason is null or length(btrim(p_reason)) = 0 then raise exception 'اكتب سبب التعديل'; end if;
  select * into b from supplier_bills where id = p_id for update;
  if not found then raise exception 'الفاتورة غير موجودة'; end if;

  n_date := case when p ? 'bill_date'   then nullif(p->>'bill_date','')::date else b.bill_date end;
  n_amt  := case when p ? 'amount'      then round(coalesce(nullif(p->>'amount','')::numeric, 0), 2) else b.amount end;
  n_num  := case when p ? 'bill_number' then nullif(btrim(p->>'bill_number'),'') else b.bill_number end;
  n_desc := case when p ? 'description' then nullif(btrim(p->>'description'),'') else b.description end;

  if n_amt <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if n_date is null then raise exception 'التاريخ مطلوب'; end if;

  if n_date is distinct from b.bill_date          then v_old := v_old || jsonb_build_object('bill_date', b.bill_date);     v_new := v_new || jsonb_build_object('bill_date', n_date); end if;
  if n_amt  is distinct from round(b.amount, 2)   then v_old := v_old || jsonb_build_object('amount', b.amount);            v_new := v_new || jsonb_build_object('amount', n_amt); end if;
  if n_num  is distinct from b.bill_number        then v_old := v_old || jsonb_build_object('bill_number', b.bill_number); v_new := v_new || jsonb_build_object('bill_number', n_num); end if;
  if n_desc is distinct from b.description        then v_old := v_old || jsonb_build_object('description', b.description); v_new := v_new || jsonb_build_object('description', n_desc); end if;
  if v_new = '{}'::jsonb then raise exception 'مفيش تغيير'; end if;

  -- مينفعش القيمة تبقى أقل من اللي اتدفع أو اتخصم من دفعات مقدّمة على الفاتورة
  if n_amt < round(b.amount, 2) then
    v_used := coalesce((select sum(amount) from treasury_entries where bill_id = b.id), 0)
            + coalesce((select sum(amount) from supplier_payment_allocations where bill_id = b.id), 0);
    if n_amt < v_used - 0.005 then
      raise exception 'القيمة الجديدة أقل من المدفوع/المخصوم على الفاتورة (%) — عدّل أو احذف الدفعات الأول', v_used;
    end if;
  end if;

  update supplier_bills set bill_date = n_date, amount = n_amt, bill_number = n_num, description = n_desc where id = b.id;

  v_sign := case when b.doc_type = 'credit_note' then -1 else 1 end;
  v_def  := case when b.doc_type = 'credit_note' then 'مرتجع ' else 'فاتورة ' end;
  v_cdesc := coalesce(n_desc, v_def || coalesce(n_num, ''));
  if b.project_cost_id is not null then
    update project_costs set amount = v_sign * n_amt, cost_date = n_date,
           description = case when (p ? 'description') or (b.description is null and p ? 'bill_number') then v_cdesc else description end
     where id = b.project_cost_id;
  end if;
  if b.expense_id is not null then
    update expenses set amount = n_amt, expense_date = n_date,
           description = case when p ? 'description' then coalesce(n_desc, description) else description end
     where id = b.expense_id;
  end if;

  -- لو القيمة زادت، الدفعات المقدّمة المتاحة بتتخصم تلقائيًا
  if b.doc_type = 'invoice' and n_amt > round(b.amount, 2) then perform fn_allocate_bill(b.id); end if;

  insert into supplier_bill_edits (bill_id, supplier_id, old_values, new_values, reason)
  values (b.id, b.supplier_id, v_old, v_new, btrim(p_reason)) returning id into v_id;
  return v_id;
end $$;


--
-- Name: finance_edit_entry(bigint, jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_edit_entry(p_id bigint, p jsonb, p_reason text) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  e treasury_entries%rowtype; pay payments%rowtype; r_exp expenses%rowtype; r_cost project_costs%rowtype;
  n_acc bigint; n_date date; n_amt numeric(14,2); n_method text; n_ref text; n_notes text; n_proj bigint; n_po bigint;
  v_old jsonb := '{}'::jsonb; v_new jsonb := '{}'::jsonb; v_id bigint;
  other_acc bigint; v_rem numeric; v_cost bigint; v_exp bigint; v_posup bigint; v_poproj bigint; v_desc text;
begin
  if p_reason is null or length(btrim(p_reason)) = 0 then raise exception 'اكتب سبب التعديل'; end if;
  select * into e from treasury_entries where id = p_id for update;
  if not found then raise exception 'الحركة غير موجودة'; end if;

  n_acc    := case when p ? 'account_id' then nullif(p->>'account_id','')::bigint else e.account_id end;
  n_date   := case when p ? 'entry_date' then nullif(p->>'entry_date','')::date else e.entry_date end;
  n_amt    := case when p ? 'amount' then round(coalesce(nullif(p->>'amount','')::numeric, 0), 2) else e.amount end;
  n_method := case when p ? 'method' then nullif(btrim(p->>'method'),'') else e.method end;
  n_ref    := case when p ? 'reference' then nullif(btrim(p->>'reference'),'') else e.reference end;
  n_notes  := case when p ? 'notes' then nullif(btrim(p->>'notes'),'') else e.notes end;
  n_proj   := case when p ? 'project_id' then nullif(p->>'project_id','')::bigint else e.project_id end;
  n_po     := case when p ? 'po_id' then nullif(p->>'po_id','')::bigint else e.purchase_order_id end;

  if n_amt <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if n_date is null then raise exception 'التاريخ مطلوب'; end if;
  if n_acc is null then raise exception 'اختر الحساب'; end if;
  if n_acc is distinct from e.account_id and not exists (select 1 from treasury_accounts where id = n_acc and active) then
    raise exception 'الحساب غير موجود أو غير نشط';
  end if;
  if e.kind not in ('supplier_payment','supplier_refund') then n_po := e.purchase_order_id; end if;
  if e.kind in ('partner_draw','transfer') then n_proj := e.project_id; end if;
  if n_proj is not null and n_proj is distinct from e.project_id and not exists (select 1 from projects where id = n_proj) then
    raise exception 'المشروع غير موجود';
  end if;

  if n_acc    is distinct from e.account_id        then v_old := v_old || jsonb_build_object('account_id', e.account_id);        v_new := v_new || jsonb_build_object('account_id', n_acc); end if;
  if n_date   is distinct from e.entry_date        then v_old := v_old || jsonb_build_object('entry_date', e.entry_date);        v_new := v_new || jsonb_build_object('entry_date', n_date); end if;
  if n_amt    is distinct from round(e.amount, 2)  then v_old := v_old || jsonb_build_object('amount', e.amount);                v_new := v_new || jsonb_build_object('amount', n_amt); end if;
  if n_method is distinct from e.method            then v_old := v_old || jsonb_build_object('method', e.method);                v_new := v_new || jsonb_build_object('method', n_method); end if;
  if n_ref    is distinct from e.reference         then v_old := v_old || jsonb_build_object('reference', e.reference);          v_new := v_new || jsonb_build_object('reference', n_ref); end if;
  if n_notes  is distinct from e.notes             then v_old := v_old || jsonb_build_object('notes', e.notes);                  v_new := v_new || jsonb_build_object('notes', n_notes); end if;
  if n_proj   is distinct from e.project_id        then v_old := v_old || jsonb_build_object('project_id', e.project_id);        v_new := v_new || jsonb_build_object('project_id', n_proj); end if;
  if n_po     is distinct from e.purchase_order_id then v_old := v_old || jsonb_build_object('purchase_order_id', e.purchase_order_id); v_new := v_new || jsonb_build_object('purchase_order_id', n_po); end if;
  if v_new = '{}'::jsonb then raise exception 'مفيش تغيير'; end if;

  if e.kind = 'transfer' then
    if e.transfer_group is null then raise exception 'تحويل غير مكتمل'; end if;
    select account_id into other_acc from treasury_entries where transfer_group = e.transfer_group and id <> e.id limit 1;
    if n_acc = other_acc then raise exception 'حساب التحويل (من) و(إلى) لازم يختلفوا'; end if;
    update treasury_entries set entry_date = n_date, amount = n_amt, method = n_method, reference = n_ref, notes = n_notes
     where transfer_group = e.transfer_group;
    update treasury_entries set account_id = n_acc where id = e.id;

  else
    if e.kind = 'customer_receipt' then
      select * into pay from payments where id = e.payment_id for update;
      if not found then raise exception 'دفعة العميل غير موجودة'; end if;
      if n_proj is null then raise exception 'اختر المشروع'; end if;
      if n_proj is distinct from e.project_id and pay.milestone_id is not null then
        raise exception 'الدفعة مربوطة بمرحلة دفع في مشروعها — مينفعش تتنقل لمشروع تاني';
      end if;
      update payments set amount = n_amt, payment_date = n_date, method = n_method, notes = n_notes, project_id = n_proj where id = pay.id;
      if n_amt <> round(pay.amount, 2) or n_date <> pay.payment_date::date then
        insert into payment_edits (payment_id, project_id, old_amount, new_amount, old_date, new_date, reason, edited_by)
        values (pay.id, n_proj, round(pay.amount, 2), n_amt, pay.payment_date::date, n_date, btrim(p_reason), 'admin');
      end if;

    elsif e.kind in ('supplier_payment','supplier_refund') then
      if e.kind = 'supplier_payment' and e.bill_id is not null then
        if n_proj is distinct from e.project_id or n_po is distinct from e.purchase_order_id then
          raise exception 'الدفعة على فاتورة — المشروع والطلب بيتحددوا من الفاتورة';
        end if;
        select b.amount
               - coalesce((select sum(x.amount) from treasury_entries x where x.bill_id = b.id and x.kind = 'supplier_payment' and x.id <> e.id), 0)
               - coalesce((select sum(a.amount) from supplier_payment_allocations a where a.bill_id = b.id), 0)
          into v_rem from supplier_bills b where b.id = e.bill_id;
        if n_amt > coalesce(v_rem, 0) + 0.005 then raise exception 'المبلغ أكبر من المتبقي على الفاتورة (%)', v_rem; end if;
      else
        if n_po is not null then
          select supplier_id, project_id into v_posup, v_poproj from purchase_orders where id = n_po;
          if not found then raise exception 'أمر الشراء غير موجود'; end if;
          if v_posup <> e.supplier_id then raise exception 'أمر الشراء ده بتاع مورد تاني'; end if;
          if n_proj is null then n_proj := v_poproj; end if;
        end if;
        if e.kind = 'supplier_payment' then delete from supplier_payment_allocations where entry_id = e.id; end if;
      end if;

    elsif e.kind = 'expense' then
      v_desc := case when p ? 'notes' then n_notes else e.notes end;
      if e.expense_id is not null then
        select * into r_exp from expenses where id = e.expense_id for update;
        if n_proj is null then
          update expenses set expense_date = n_date, amount = n_amt, description = coalesce(v_desc, description) where id = r_exp.id;
        else
          if r_exp.recurring_id is not null then raise exception 'مصروف متكرر — مينفعش يتنقل لمشروع'; end if;
          insert into project_costs (project_id, cost_type, description, amount, cost_date, supplier, tax_treatment)
          values (n_proj, coalesce(r_exp.category,'other'), coalesce(v_desc, r_exp.description), n_amt, n_date, null, coalesce(r_exp.tax_treatment,'none'))
          returning id into v_cost;
          update treasury_entries set expense_id = null, project_cost_id = v_cost where id = e.id;
          delete from expenses where id = r_exp.id;
        end if;
      elsif e.project_cost_id is not null then
        select * into r_cost from project_costs where id = e.project_cost_id for update;
        if n_proj is null then
          insert into expenses (expense_date, category, description, amount, tax_treatment, created_by)
          values (n_date, coalesce(r_cost.cost_type,'other'), coalesce(v_desc, r_cost.description), n_amt, coalesce(r_cost.tax_treatment,'none'), 'treasury')
          returning id into v_exp;
          update treasury_entries set project_cost_id = null, expense_id = v_exp where id = e.id;
          delete from project_costs where id = r_cost.id;
        else
          update project_costs set project_id = n_proj, cost_date = n_date, amount = n_amt, description = coalesce(v_desc, description) where id = r_cost.id;
        end if;
      end if;

    elsif e.kind = 'partner_draw' then
      if e.distribution_id is not null then
        update partner_distributions set amount = n_amt, distribution_date = n_date,
               notes = case when p ? 'notes' then n_notes else notes end where id = e.distribution_id;
      end if;
    end if;

    update treasury_entries set account_id = n_acc, entry_date = n_date, amount = n_amt, method = n_method, reference = n_ref,
           notes = n_notes, project_id = n_proj, purchase_order_id = n_po where id = e.id;
    if e.kind = 'supplier_payment' and e.bill_id is null then perform finance_auto_allocate_supplier(e.supplier_id); end if;
  end if;

  insert into treasury_entry_edits (entry_id, kind, old_values, new_values, reason)
  values (e.id, e.kind, v_old, v_new, btrim(p_reason)) returning id into v_id;
  return v_id;
end $$;


--
-- Name: finance_edit_payment(bigint, numeric, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_edit_payment(p_payment bigint, p_amount numeric, p_date date, p_reason text) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare pay payments%rowtype; a numeric(14,2) := round(coalesce(p_amount, 0), 2); v_id bigint;
begin
  if a <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if p_date is null then raise exception 'التاريخ مطلوب'; end if;
  if p_reason is null or length(btrim(p_reason)) = 0 then raise exception 'اكتب سبب التعديل'; end if;
  select * into pay from payments where id = p_payment for update;
  if not found then raise exception 'الدفعة غير موجودة'; end if;
  if a = round(pay.amount, 2) and p_date = pay.payment_date::date then
    raise exception 'مفيش تغيير: المبلغ والتاريخ زي ما هم';
  end if;
  insert into payment_edits (payment_id, project_id, old_amount, new_amount, old_date, new_date, reason, edited_by)
  values (pay.id, pay.project_id, round(pay.amount, 2), a, pay.payment_date::date, p_date, btrim(p_reason), 'admin')
  returning id into v_id;
  update payments set amount = a, payment_date = p_date where id = pay.id;      -- trg_payments_recalc re-derives payment status
  update treasury_entries set amount = a, entry_date = p_date where payment_id = pay.id;
  return v_id;
end $$;


--
-- Name: finance_generate_recurring(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_generate_recurring(p_month date) RETURNS integer
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare m date := date_trunc('month', p_month::timestamp)::date; n integer;
begin
  insert into public.expenses (expense_date, category, description, amount, tax_treatment, recurring_id, created_by)
  select m, r.category, r.description, r.amount, r.tax_treatment, r.id, 'recurring'
  from public.recurring_expenses r
  where r.active and r.start_month <= m and (r.end_month is null or r.end_month >= m)
  on conflict (recurring_id, expense_date) where recurring_id is not null do nothing;
  get diagnostics n = row_count;
  return n;
end $$;


--
-- Name: finance_record_bill(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_bill(p jsonb) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_supplier bigint := nullif(p->>'supplier_id','')::bigint;
  v_name text := nullif(btrim(coalesce(p->>'supplier_name','')), '');
  v_project bigint := nullif(p->>'project_id','')::bigint;
  v_po bigint := nullif(p->>'po_id','')::bigint;
  v_amount numeric(14,2) := round(coalesce(nullif(p->>'amount','')::numeric, 0), 2);
  v_date date := coalesce(nullif(p->>'bill_date','')::date, current_date);
  v_tax text := coalesce(nullif(p->>'tax_treatment',''), 'recoverable');
  v_desc text := nullif(p->>'description','');
  v_num text := nullif(p->>'bill_number','');
  v_type text := coalesce(nullif(p->>'doc_type',''), 'invoice');
  v_sname text; v_cost bigint; v_exp bigint; v_id bigint; v_posup bigint; v_poproj bigint; v_postatus text;
begin
  if v_amount <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if v_type not in ('invoice','credit_note') then raise exception 'نوع المستند غير صالح'; end if;
  if v_po is not null then
    select supplier_id, project_id, status into v_posup, v_poproj, v_postatus from purchase_orders where id = v_po;
    if not found then raise exception 'طلب الشراء غير موجود'; end if;
    if v_postatus = 'cancelled' then raise exception 'طلب الشراء ملغي'; end if;
    if v_supplier is null and v_name is null then v_supplier := v_posup; end if;
    if v_project is null then v_project := v_poproj; end if;
  end if;
  if v_supplier is null and v_name is not null then
    select id into v_supplier from suppliers where lower(name) = lower(v_name);
    if v_supplier is null then insert into suppliers (name) values (v_name) returning id into v_supplier; end if;
  end if;
  select name into v_sname from suppliers where id = v_supplier;
  if v_sname is null then raise exception 'اختر المورد أو اكتب اسم مورد جديد'; end if;
  if v_po is not null and v_supplier <> v_posup then raise exception 'طلب الشراء ده بتاع مورد تاني'; end if;
  if v_project is not null and not exists (select 1 from projects where id = v_project) then raise exception 'المشروع غير موجود'; end if;

  if v_type = 'invoice' then
    if v_project is not null then
      insert into project_costs (project_id, cost_type, description, amount, cost_date, supplier, tax_treatment)
      values (v_project, coalesce(nullif(p->>'cost_type',''), 'other'), coalesce(v_desc, 'فاتورة ' || coalesce(v_num, '')), v_amount, v_date, v_sname, v_tax)
      returning id into v_cost;
    else
      insert into expenses (expense_date, category, description, amount, tax_treatment, created_by)
      values (v_date, 'other', coalesce(v_desc, 'مشتريات من ' || v_sname), v_amount, v_tax, 'treasury')
      returning id into v_exp;
    end if;
  elsif v_project is not null then
    insert into project_costs (project_id, cost_type, description, amount, cost_date, supplier, tax_treatment)
    values (v_project, coalesce(nullif(p->>'cost_type',''), 'other'), coalesce(v_desc, 'مرتجع ' || coalesce(v_num, '')), -v_amount, v_date, v_sname, v_tax)
    returning id into v_cost;
  end if;

  insert into supplier_bills (supplier_id, project_id, bill_number, bill_date, amount, tax_treatment, description, project_cost_id, expense_id, purchase_order_id, doc_type)
  values (v_supplier, v_project, v_num, v_date, v_amount, v_tax, v_desc, v_cost, v_exp, v_po, v_type) returning id into v_id;

  if v_type = 'invoice' then perform fn_allocate_bill(v_id); end if;
  return v_id;
end $$;


--
-- Name: finance_record_entry(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_entry(p jsonb) RETURNS bigint
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_kind text := p->>'kind';
  v_amount numeric(14,2) := round(coalesce(nullif(p->>'amount','')::numeric, 0), 2);
  v_acc bigint := nullif(p->>'account_id','')::bigint;
  v_date date := coalesce(nullif(p->>'entry_date','')::date, current_date);
  v_method text := nullif(p->>'method','');
  v_ref text := nullif(p->>'reference','');
  v_notes text := nullif(p->>'notes','');
  v_project bigint := nullif(p->>'project_id','')::bigint;
  v_supplier bigint := nullif(p->>'supplier_id','')::bigint;
  v_bill bigint := nullif(p->>'bill_id','')::bigint;
  v_partner bigint := nullif(p->>'partner_id','')::bigint;
  v_po bigint := nullif(p->>'po_id','')::bigint;
  v_dir text; v_payment bigint; v_expense bigint; v_dist bigint; v_cost bigint; v_id bigint;
  v_rem numeric; v_bsupplier bigint; v_bproject bigint; v_bpo bigint; v_posup bigint; v_poproj bigint;
begin
  if v_amount <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if v_acc is null or not exists (select 1 from treasury_accounts where id = v_acc and active) then
    raise exception 'الحساب غير موجود أو غير نشط';
  end if;

  if v_kind = 'customer_receipt' then
    if v_project is null or not exists (select 1 from projects where id = v_project) then raise exception 'اختر المشروع'; end if;
    v_dir := 'in';
    select pp.id into v_payment from payments pp
     where pp.project_id = v_project and pp.auto_created and abs(pp.amount - v_amount) < 0.005
       and not exists (select 1 from treasury_entries e where e.payment_id = pp.id)
     order by pp.id limit 1 for update;
    if v_payment is not null then
      update payments set payment_date = v_date, method = coalesce(v_method, method),
             notes = coalesce(v_notes, notes), auto_created = false where id = v_payment;
    else
      insert into payments (project_id, amount, payment_date, method, notes)
      values (v_project, v_amount, v_date, v_method, v_notes) returning id into v_payment;
    end if;

  elsif v_kind = 'supplier_payment' then
    v_dir := 'out';
    if v_bill is not null then
      select b.supplier_id, b.project_id, b.purchase_order_id,
             b.amount - coalesce((select sum(e.amount) from treasury_entries e where e.bill_id = b.id and e.kind = 'supplier_payment'), 0)
                      - coalesce((select sum(a.amount) from supplier_payment_allocations a where a.bill_id = b.id), 0)
        into v_bsupplier, v_bproject, v_bpo, v_rem
      from supplier_bills b where b.id = v_bill and b.doc_type = 'invoice';
      if not found then raise exception 'الفاتورة غير موجودة'; end if;
      v_supplier := v_bsupplier; v_project := v_bproject; v_po := v_bpo;
      if v_amount > v_rem + 0.005 then raise exception 'المبلغ أكبر من المتبقي على الفاتورة (%)', v_rem; end if;
    elsif v_supplier is null or not exists (select 1 from suppliers where id = v_supplier) then
      raise exception 'اختر المورد';
    else
      if v_po is not null then
        select supplier_id, project_id into v_posup, v_poproj from purchase_orders where id = v_po;
        if not found then raise exception 'طلب الشراء غير موجود'; end if;
        if v_posup <> v_supplier then raise exception 'طلب الشراء ده بتاع مورد تاني'; end if;
        if v_project is null then v_project := v_poproj; end if;
      end if;
      if v_project is not null and not exists (select 1 from projects where id = v_project) then raise exception 'المشروع غير موجود'; end if;
    end if;

  elsif v_kind = 'supplier_refund' then
    v_dir := 'in';
    if v_supplier is null or not exists (select 1 from suppliers where id = v_supplier) then raise exception 'اختر المورد'; end if;
    v_bill := null;
    if v_project is not null and not exists (select 1 from projects where id = v_project) then raise exception 'المشروع غير موجود'; end if;

  elsif v_kind = 'expense' then
    v_dir := 'out';
    if v_project is not null then
      if not exists (select 1 from projects where id = v_project) then raise exception 'المشروع غير موجود'; end if;
      insert into project_costs (project_id, cost_type, description, amount, cost_date, supplier, tax_treatment)
      values (v_project, coalesce(nullif(p->>'category',''), 'other'), nullif(p->>'description',''), v_amount, v_date,
              nullif(p->>'payee',''), coalesce(nullif(p->>'tax_treatment',''), 'none'))
      returning id into v_cost;
    else
      insert into expenses (expense_date, category, description, amount, tax_treatment, created_by)
      values (v_date, coalesce(nullif(p->>'category',''), 'other'), nullif(p->>'description',''), v_amount,
              coalesce(nullif(p->>'tax_treatment',''), 'recoverable'), 'treasury') returning id into v_expense;
    end if;

  elsif v_kind = 'partner_draw' then
    v_dir := 'out';
    if v_partner is null then raise exception 'اختر الشريك'; end if;
    insert into partner_distributions (partner_id, amount, distribution_date, kind, notes)
    values (v_partner, v_amount, v_date, coalesce(nullif(p->>'dist_kind',''), 'draw'), v_notes) returning id into v_dist;

  elsif v_kind = 'other' then
    v_dir := p->>'direction';
    if v_dir is null or v_dir not in ('in','out') then raise exception 'الاتجاه غير صالح'; end if;
  else
    raise exception 'نوع الحركة غير صالح';
  end if;

  insert into treasury_entries (entry_date, account_id, direction, amount, kind, method, reference, notes,
                                project_id, supplier_id, bill_id, payment_id, expense_id, distribution_id, project_cost_id,
                                purchase_order_id, created_by)
  values (v_date, v_acc, v_dir, v_amount, v_kind, v_method, v_ref, coalesce(v_notes, nullif(p->>'description','')),
          v_project, v_supplier, v_bill, v_payment, v_expense, v_dist, v_cost,
          case when v_kind in ('supplier_payment','supplier_refund') then v_po end, 'admin')
  returning id into v_id;

  if v_kind = 'supplier_payment' and v_bill is null then perform finance_auto_allocate_supplier(v_supplier); end if;
  return v_id;
end $$;


--
-- Name: finance_record_rfq_quote(bigint, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_rfq_quote(p_rfq bigint, p jsonb) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  r rfqs%rowtype; pr jsonb; v_mode text; v_valid boolean; v_lump numeric; v_price numeric; v_line int; v_n int;
begin
  select * into r from rfqs where id = p_rfq for update;
  if not found then raise exception 'طلب عرض السعر غير موجود'; end if;
  if r.status in ('rejected','cancelled') then raise exception 'الطلب اتقفل — مينفعش تعدّل أسعاره'; end if;
  if r.status = 'accepted' and (
       exists (select 1 from supplier_bills b join purchase_orders o on o.id = b.purchase_order_id where o.rfq_id = p_rfq)
    or exists (select 1 from treasury_entries t join purchase_orders o on o.id = t.purchase_order_id where o.rfq_id = p_rfq)) then
    raise exception 'الطلب اتقبل واتسجّل على أمر الشراء فواتير أو دفعات — عدّل من تبويب أوامر الشراء';
  end if;

  v_mode := coalesce(nullif(p->>'vat_mode',''), r.vat_mode);
  if v_mode is null or v_mode not in ('incl','excl','none') then raise exception 'حدّد هل أسعار المورد شاملة الضريبة أم لا'; end if;
  v_valid := coalesce((p->>'valid_invoice')::boolean, r.valid_invoice, true);

  if coalesce(p->>'mode','items') = 'lump' then
    if r.is_multi then raise exception 'السعر الإجمالي الواحد مش متاح في الطلب المشترك — سجّل سعر كل بند'; end if;
    v_lump := round(coalesce(nullif(p->>'lump_total','')::numeric, 0), 2);
    if v_lump <= 0 then raise exception 'اكتب السعر الإجمالي اللي بلّغه المورد'; end if;
    update rfq_items set unit_price = null where rfq_id = p_rfq;
  else
    v_lump := null;
    for pr in select * from jsonb_array_elements(coalesce(p->'prices', '[]'::jsonb)) loop
      v_line := (pr->>'line_no')::int;
      v_price := nullif(pr->>'unit_price','')::numeric;
      if v_price is not null and v_price < 0 then raise exception 'السعر لا يكون سالب'; end if;
      update rfq_items set unit_price = case when v_price is null then null else round(v_price, 4) end where rfq_id = p_rfq and line_no = v_line;
      get diagnostics v_n = row_count;
      if v_n = 0 then raise exception 'البند رقم % مش موجود في الطلب', v_line; end if;
    end loop;
    if not exists (select 1 from rfq_items where rfq_id = p_rfq and unit_price is not null) then raise exception 'سجّل سعر بند واحد على الأقل'; end if;
  end if;

  update rfqs set
    status = case when status = 'accepted' then status else 'quoted' end,
    vat_mode = v_mode, valid_invoice = v_valid, lump_total = v_lump,
    supplier_quote_ref  = case when p ? 'supplier_quote_ref'  then nullif(p->>'supplier_quote_ref','')  else supplier_quote_ref end,
    supplier_quote_date = case when p ? 'supplier_quote_date' then nullif(p->>'supplier_quote_date','')::date else supplier_quote_date end,
    quoted_at = coalesce(quoted_at, now())
  where id = p_rfq;

  if r.status = 'accepted' then perform fn_rfq_sync_pos(p_rfq); end if;
end $$;


--
-- Name: finance_record_split_bill(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_split_bill(p jsonb) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare g uuid := gen_random_uuid(); ln jsonb; v_sum numeric := 0; v_total numeric := round(coalesce(nullif(p->>'total','')::numeric, 0), 2);
  v_amt numeric; v_id bigint; v_ids bigint[] := '{}';
begin
  if jsonb_typeof(p->'lines') is distinct from 'array' or jsonb_array_length(p->'lines') < 1 then raise exception 'أضف سطر واحد على الأقل'; end if;
  for ln in select * from jsonb_array_elements(p->'lines') loop
    v_amt := round(coalesce(nullif(ln->>'amount','')::numeric, 0), 2);
    if v_amt <= 0 then raise exception 'مبلغ أحد الأسطر غير صالح'; end if;
    v_sum := v_sum + v_amt;
  end loop;
  if v_total > 0 and abs(v_sum - v_total) > 0.005 then raise exception 'مجموع الأسطر (%) لا يساوي قيمة الفاتورة (%)', v_sum, v_total; end if;
  for ln in select * from jsonb_array_elements(p->'lines') loop
    v_id := finance_record_bill(jsonb_build_object('supplier_id',p->>'supplier_id','supplier_name',p->>'supplier_name','project_id',ln->>'project_id','po_id',ln->>'po_id',
      'amount',ln->>'amount','bill_date',p->>'bill_date','tax_treatment',p->>'tax_treatment','description',coalesce(nullif(ln->>'description',''), p->>'description'),
      'bill_number',p->>'bill_number','cost_type',coalesce(nullif(ln->>'cost_type',''), p->>'cost_type'),'doc_type',p->>'doc_type'));
    v_ids := v_ids || v_id;
  end loop;
  update supplier_bills set bill_group = g where id = any(v_ids);
  return g;
end $$;


--
-- Name: finance_record_split_payment(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_split_payment(p jsonb) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare g uuid := gen_random_uuid(); ln jsonb; v_sum numeric := 0; v_total numeric := round(coalesce(nullif(p->>'total','')::numeric, 0), 2);
  v_amt numeric; v_id bigint; v_ids bigint[] := '{}'; v_sup bigint := nullif(p->>'supplier_id','')::bigint; v_bsup bigint;
begin
  if v_sup is null or not exists (select 1 from suppliers where id = v_sup) then raise exception 'اختر المورد'; end if;
  if jsonb_typeof(p->'lines') is distinct from 'array' or jsonb_array_length(p->'lines') < 1 then raise exception 'أضف سطر واحد على الأقل'; end if;
  for ln in select * from jsonb_array_elements(p->'lines') loop
    v_amt := round(coalesce(nullif(ln->>'amount','')::numeric, 0), 2);
    if v_amt <= 0 then raise exception 'مبلغ أحد الأسطر غير صالح'; end if;
    v_sum := v_sum + v_amt;
    if nullif(ln->>'bill_id','') is not null then
      select supplier_id into v_bsup from supplier_bills where id = (ln->>'bill_id')::bigint;
      if v_bsup is distinct from v_sup then raise exception 'إحدى الفواتير بتاعة مورد تاني'; end if;
    end if;
  end loop;
  if v_total > 0 and abs(v_sum - v_total) > 0.005 then raise exception 'مجموع الأسطر (%) لا يساوي مبلغ التحويل (%)', v_sum, v_total; end if;
  for ln in select * from jsonb_array_elements(p->'lines') loop
    v_id := finance_record_entry(jsonb_build_object('kind','supplier_payment','account_id',p->>'account_id','entry_date',p->>'entry_date',
      'method',p->>'method','reference',p->>'reference','notes',coalesce(nullif(ln->>'notes',''), p->>'notes'),'supplier_id',p->>'supplier_id',
      'amount',ln->>'amount','project_id',ln->>'project_id','po_id',ln->>'po_id','bill_id',ln->>'bill_id'));
    v_ids := v_ids || v_id;
  end loop;
  update treasury_entries set payment_group = g where id = any(v_ids);
  return g;
end $$;


--
-- Name: finance_record_transfer(bigint, bigint, numeric, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_record_transfer(p_from bigint, p_to bigint, p_amount numeric, p_date date, p_notes text) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare g uuid := gen_random_uuid(); a numeric(14,2) := round(coalesce(p_amount, 0), 2);
begin
  if a <= 0 then raise exception 'المبلغ غير صالح'; end if;
  if p_from is null or p_to is null or p_from = p_to then raise exception 'اختر حسابين مختلفين'; end if;
  if not exists (select 1 from treasury_accounts where id = p_from and active)
     or not exists (select 1 from treasury_accounts where id = p_to and active) then
    raise exception 'الحساب غير موجود أو غير نشط';
  end if;
  insert into treasury_entries (entry_date, account_id, direction, amount, kind, notes, transfer_group, created_by)
  values (coalesce(p_date, current_date), p_from, 'out', a, 'transfer', p_notes, g, 'admin'),
         (coalesce(p_date, current_date), p_to, 'in', a, 'transfer', p_notes, g, 'admin');
  return g;
end $$;


--
-- Name: finance_reject_rfq(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_reject_rfq(p_rfq bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare r rfqs%rowtype;
begin
  select * into r from rfqs where id = p_rfq for update;
  if not found then raise exception 'طلب عرض السعر غير موجود'; end if;
  if r.status not in ('draft','sent','quoted') then raise exception 'الطلب اتقفل بالفعل'; end if;
  update rfqs set status = 'rejected', decided_at = now() where id = p_rfq;
end $$;


--
-- Name: finance_set_entry_link(bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_set_entry_link(p_entry bigint, p_project bigint, p_po bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare e treasury_entries%rowtype; v_posup bigint; v_poproj bigint;
begin
  select * into e from treasury_entries where id = p_entry and kind in ('supplier_payment', 'supplier_refund');
  if not found then raise exception 'الحركة غير موجودة'; end if;
  if e.bill_id is not null then raise exception 'الدفعة مرتبطة بفاتورة بالفعل'; end if;
  if p_po is not null then
    select supplier_id, project_id into v_posup, v_poproj from purchase_orders where id = p_po;
    if not found then raise exception 'طلب الشراء غير موجود'; end if;
    if v_posup <> e.supplier_id then raise exception 'طلب الشراء ده بتاع مورد تاني'; end if;
    if p_project is null then p_project := v_poproj; end if;
  end if;
  if p_project is not null and not exists (select 1 from projects where id = p_project) then raise exception 'المشروع غير موجود'; end if;
  delete from supplier_payment_allocations where entry_id = e.id;
  update treasury_entries set project_id = p_project, purchase_order_id = p_po where id = e.id;
  if e.kind = 'supplier_payment' then perform finance_auto_allocate_supplier(e.supplier_id); end if;
end $$;


--
-- Name: finance_unallocate_advance(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_unallocate_advance(p_entry bigint, p_bill bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  delete from supplier_payment_allocations where entry_id = p_entry and bill_id = p_bill;
end $$;


--
-- Name: finance_undo_discount(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.finance_undo_discount(p_id bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare d project_discounts%rowtype;
begin
  select * into d from project_discounts where id = p_id;
  if not found then raise exception 'الخصم غير موجود'; end if;
  perform 1 from projects where id = d.project_id for update;
  update projects set contract_value = coalesce(contract_value, 0) + d.contract_value_reduction where id = d.project_id;
  delete from project_discounts where id = p_id;
end $$;


--
-- Name: fn_allocate_bill(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_allocate_bill(p_bill bigint) RETURNS numeric
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare b supplier_bills%rowtype; v_need numeric; v_take numeric; v_total numeric := 0; e record;
begin
  select * into b from supplier_bills where id = p_bill and doc_type = 'invoice';
  if not found then return 0; end if;
  v_need := b.amount - coalesce((select sum(amount) from treasury_entries where bill_id = b.id and kind = 'supplier_payment'), 0)
                     - coalesce((select sum(amount) from supplier_payment_allocations where bill_id = b.id), 0);
  for e in
    select x.id, x.amount - coalesce((select sum(a.amount) from supplier_payment_allocations a where a.entry_id = x.id), 0) as rem
    from treasury_entries x
    where x.supplier_id = b.supplier_id and x.kind = 'supplier_payment' and x.bill_id is null
      and ( (b.purchase_order_id is not null and x.purchase_order_id = b.purchase_order_id)
         or (x.purchase_order_id is null and x.project_id is not null and x.project_id is not distinct from b.project_id)
         or (x.purchase_order_id is null and x.project_id is null) )
    order by case when b.purchase_order_id is not null and x.purchase_order_id = b.purchase_order_id then 0
                  when x.project_id is not null then 1 else 2 end, x.entry_date, x.id
  loop
    exit when v_need <= 0.005;
    if e.rem > 0.005 then
      v_take := least(e.rem, v_need);
      insert into supplier_payment_allocations (entry_id, bill_id, amount) values (e.id, b.id, v_take)
        on conflict (entry_id, bill_id) do update set amount = supplier_payment_allocations.amount + excluded.amount;
      v_need := v_need - v_take; v_total := v_total + v_take;
    end if;
  end loop;
  return v_total;
end $$;


--
-- Name: fn_project_recalc_payment(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_project_recalc_payment(p_project bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_cv numeric; v_old text; v_label text; v_paid numeric; v_new text;
begin
  select contract_value, payment_status, project_number
    into v_cv, v_old, v_label
    from public.projects where id = p_project;
  if not found then return; end if;

  select coalesce(sum(amount), 0) into v_paid
    from public.payments where project_id = p_project;

  v_new := case
    when v_paid <= 0 then 'unpaid'
    when coalesce(v_cv, 0) > 0 and v_paid >= v_cv then 'paid'
    else 'partial' end;

  if v_new is distinct from v_old then
    update public.projects set payment_status = v_new where id = p_project;
    perform public.sys_audit('auto_sync', 'project', p_project, v_label,
      jsonb_build_object('payment_status', v_old, 'paid', v_paid),
      jsonb_build_object('payment_status', v_new, 'paid', v_paid));
  end if;
end $$;


--
-- Name: fn_rfq_project_net(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_rfq_project_net(p_rfq bigint, p_project bigint) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select coalesce(sum(i.unit_price * (select coalesce(sum((a->>'qty')::numeric), 0) from jsonb_array_elements(i.alloc) a
                                      where nullif(a->>'project_id','')::bigint is not distinct from p_project)), 0)
  from rfq_items i where i.rfq_id = p_rfq and i.unit_price is not null and i.alloc is not null $$;


--
-- Name: fn_rfq_sync_pos(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_rfq_sync_pos(p_rfq bigint) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare r rfqs%rowtype; v_vr numeric; v_net numeric; v_gross numeric; po record;
begin
  select * into r from rfqs where id = p_rfq;
  select vat_rate / 100.0 into v_vr from finance_settings where id = 1;
  if not r.is_multi then
    if r.po_id is null then return; end if;
    select coalesce(r.lump_total, sum(qty * unit_price), 0) into v_net from rfq_items where rfq_id = p_rfq;
    v_gross := case when r.vat_mode = 'excl' then round(v_net * (1 + v_vr), 2) else round(v_net, 2) end;
    if v_gross <= 0 then raise exception 'إجمالي العرض صفر'; end if;
    update purchase_orders set amount = v_gross, tax_treatment = case when r.vat_mode = 'none' or not r.valid_invoice then 'none' else 'recoverable' end where id = r.po_id;
  else
    for po in select id, project_id from purchase_orders where rfq_id = p_rfq loop
      v_net := fn_rfq_project_net(p_rfq, po.project_id);
      v_gross := case when r.vat_mode = 'excl' then round(v_net * (1 + v_vr), 2) else round(v_net, 2) end;
      if v_gross <= 0 then raise exception 'إجمالي أمر الشراء %: صفر — سجّل سعر بند واحد على الأقل لكل مشروع', po.id; end if;
      update purchase_orders set amount = v_gross, tax_treatment = case when r.vat_mode = 'none' or not r.valid_invoice then 'none' else 'recoverable' end where id = po.id;
    end loop;
  end if;
end $$;


--
-- Name: fn_sync_project_pipeline(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_sync_project_pipeline(p_opp bigint, p_cust bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  r record;
  v_today date := (now() at time zone 'Asia/Riyadh')::date;
begin
  if exists (select 1 from public.projects
              where opportunity_id = p_opp and status <> 'cancelled') then
    -- a live project exists: the deal is won
    for r in select id, name, stage from public.opportunities
              where id = p_opp and stage is distinct from 'won' loop
      update public.opportunities
         set stage = 'won', stage_changed_at = now(), probability = 100,
             next_follow_up_date = null, updated_at = now()
       where id = r.id;
      perform public.sys_audit('stage_change', 'opportunity', r.id, r.name,
        jsonb_build_object('stage', r.stage), jsonb_build_object('stage', 'won', 'auto', true));
    end loop;

    if not exists (select 1 from public.quotations
                    where opportunity_id = p_opp and status = 'accepted') then
      update public.quotations set status = 'accepted', updated_at = now()
       where id = (select id from public.quotations
                    where opportunity_id = p_opp and status in ('draft', 'sent')
                    order by version desc, id desc limit 1);
    end if;

    for r in select id, name, status from public.customers
              where id = p_cust and status is distinct from 'won' loop
      update public.customers set status = 'won', updated_at = now() where id = r.id;
      perform public.sys_audit('status_change', 'customer', r.id, r.name,
        jsonb_build_object('status', r.status), jsonb_build_object('status', 'won', 'auto', true));
    end loop;
  else
    -- no live project left: reopen the deal for follow-up
    for r in select id, name, stage from public.opportunities
              where id = p_opp and stage = 'won' loop
      update public.opportunities
         set stage = 'negotiation', stage_changed_at = now(), probability = null,
             next_action = 'متابعة بعد إلغاء المشروع',
             next_follow_up_date = v_today + 2, updated_at = now()
       where id = r.id;
      perform public.sys_audit('stage_change', 'opportunity', r.id, r.name,
        jsonb_build_object('stage', 'won'), jsonb_build_object('stage', 'negotiation', 'auto', true));
    end loop;

    if not exists (select 1 from public.projects
                    where customer_id = p_cust and status <> 'cancelled') then
      for r in select id, name from public.customers
                where id = p_cust and status = 'won' loop
        update public.customers set status = 'negotiating', updated_at = now() where id = r.id;
        perform public.sys_audit('status_change', 'customer', r.id, r.name,
          jsonb_build_object('status', 'won'), jsonb_build_object('status', 'negotiating', 'auto', true));
      end loop;
    end if;
  end if;
end $$;


--
-- Name: hp_segment(numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.hp_segment(p_hp numeric) RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select case
    when p_hp is null or p_hp <= 0 then null
    when p_hp <= c.small_max  then 'small'
    when p_hp <= c.medium_max then 'medium'
    when p_hp <= c.large_max  then 'large'
    else 'mega'
  end
  from public.segment_config c where c.id = 1;
$$;


--
-- Name: invoices_block_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_block_delete() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if coalesce(current_setting('app.allow_invoice_delete', true), '') = 'on'
     or coalesce((select trial_mode from public.einvoice_config where id = 1), false) then
    return old;
  end if;
  raise exception 'Issued invoices cannot be deleted. Issue a credit note instead.';
end $$;


--
-- Name: invoices_block_tamper(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_block_tamper() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if coalesce(current_setting('app.allow_invoice_delete', true), '') = 'on' then
    return new;
  end if;
  if (new.invoice_number, new.invoice_type, new.document_type, new.related_invoice_id,
      new.items, new.discount_total, new.vat_percent, new.subtotal, new.vat_amount, new.total,
      new.qr_base64, new.issued_at, new.customer_name, new.customer_vat_number,
      new.customer_cr_number, new.customer_address, new.customer_id, new.icv, new.uuid, new.supply_date)
     is distinct from
     (old.invoice_number, old.invoice_type, old.document_type, old.related_invoice_id,
      old.items, old.discount_total, old.vat_percent, old.subtotal, old.vat_amount, old.total,
      old.qr_base64, old.issued_at, old.customer_name, old.customer_vat_number,
      old.customer_cr_number, old.customer_address, old.customer_id, old.icv, old.uuid, old.supply_date)
  then
    raise exception 'Issued invoice content is immutable. Issue a credit note and a new invoice instead.';
  end if;
  return new;
end $$;


--
-- Name: invoices_enrich_warranty_items(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_enrich_warranty_items() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  it jsonb; out_items jsonb := '[]'::jsonb; std jsonb;
  v_code text; v_cat text; v_cls text; v_req boolean; v_years numeric; v_perf numeric;
  v_sn text; v_sn_n text; v_qty numeric; v_brand text; v_model text; v_seen text[] := '{}';
  p public.products%rowtype; v_has_p boolean; wr public.warranty_rules%rowtype;
begin
  if not exists (select 1 from public.warranty_category_map) then return new; end if;
  if new.document_type is distinct from 'invoice' or jsonb_typeof(new.items) <> 'array' then return new; end if;
  select data->'standardWarranties' into std from public.crm_settings order by id limit 1;

  for it in select value from jsonb_array_elements(new.items) loop
    if it->>'type' = 'product' and coalesce(it->>'code', '') <> '' then
      v_code := it->>'code';
      v_cat := null;
      select * into p from public.products where catalog_name = v_code limit 1;
      v_has_p := found;
      if v_has_p then
        v_cat := p.catalog_category;
        it := it || jsonb_build_object('product_code', p.product_code);
      elsif v_code like 'PANEL-%' then
        v_cat := 'ألواح الطاقة الشمسية';
      else
        select b->>'category' into v_cat
          from public.pricing_config pc, jsonb_array_elements(pc.data->'productCatalog') b, jsonb_array_elements(b->'rows') r
          where r->>0 = v_code limit 1;
      end if;
      v_cls := null; v_req := null; wr := null;
      select warranty_class, requires_serial into v_cls, v_req from public.warranty_category_map where category = v_cat;
      if v_cls is not null then
        if v_has_p then
          v_req := p.requires_serial;
          select * into wr from public.warranty_rules r2 where r2.catalog_category = p.catalog_category and r2.brand = p.brand;
        end if;
        -- precedence: product override > admin rule (category + brand) > class default
        v_years := case when v_has_p and p.warranty_years is not null then p.warranty_years
                        when wr.warranty_years is not null then wr.warranty_years
                        else nullif(std->v_cls->>'defectYears', '')::numeric end;
        v_perf  := case when v_has_p and p.performance_warranty_years is not null then p.performance_warranty_years
                        when wr.performance_warranty_years is not null then wr.performance_warranty_years
                        else nullif(std->v_cls->>'performanceYears', '')::numeric end;
        if v_years is not null and v_years > 0 then
          v_sn := nullif(trim(coalesce(it->>'serial', '')), '');
          if v_sn is null then v_sn := substring(it->>'name' from '(?i)SN:\s*([^\s/،,;]+)'); end if;
          v_qty := coalesce(nullif(it->>'qty', '')::numeric, 0);
          if v_req then
            if v_sn is null then
              raise exception 'الصنف "%" يحتاج رقم تسلسلي — اكتبه في خانة الرقم التسلسلي', v_code;
            end if;
            if v_qty <> 1 then
              raise exception 'الصنف "%" له رقم تسلسلي، فلازم كل وحدة في بند مستقل بكمية 1', v_code;
            end if;
            v_sn_n := upper(regexp_replace(v_sn, '\s+', '', 'g'));
            if v_sn_n = any (v_seen) then
              raise exception 'الرقم التسلسلي % مكرر داخل نفس الفاتورة', v_sn;
            end if;
            if exists (select 1 from public.invoices i, jsonb_array_elements(i.items) x
                       where i.document_type = 'invoice' and i.status <> 'cancelled' and i.id is distinct from new.id
                         and upper(regexp_replace(coalesce(x->>'serial', ''), '\s+', '', 'g')) = v_sn_n) then
              raise exception 'الرقم التسلسلي % مسجّل في فاتورة أخرى', v_sn;
            end if;
            if v_sn_n not in ('N/A', 'NA', '-')
               and exists (select 1 from public.assets a
                           where a.status is distinct from 'removed' and a.serial_number is not null
                             and upper(regexp_replace(a.serial_number, '\s+', '', 'g')) = v_sn_n
                             and coalesce(a.warranty_number, '') not like 'GC-' || coalesce(new.invoice_number, '~') || '-%') then
              raise exception 'الرقم التسلسلي % مسجّل مسبقًا في ضمان آخر', v_sn;
            end if;
            v_seen := v_seen || v_sn_n;
          end if;
          v_model := case when v_has_p and coalesce(p.part_number, '') <> '' then p.part_number else v_code end;
          v_brand := case when v_has_p and p.brand is not null then p.brand
                          when v_code like 'PANEL-%' then split_part(v_code, '-', 2) else null end;
          it := it || jsonb_strip_nulls(jsonb_build_object(
                  'warranty_class', v_cls, 'serial_required', v_req, 'model', v_model, 'brand', v_brand,
                  'serial', v_sn, 'warranty_years', v_years, 'performance_warranty_years', v_perf));
        end if;
      end if;
    end if;
    out_items := out_items || jsonb_build_array(it);
  end loop;
  new.items := out_items;
  return new;
end $$;


--
-- Name: invoices_enrich_warranty_items_old(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_enrich_warranty_items_old() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  it jsonb; out_items jsonb := '[]'::jsonb; std jsonb;
  v_code text; v_cat text; v_cls text; v_req boolean; v_years numeric; v_perf numeric;
  v_sn text; v_qty numeric; v_brand text; v_seen text[] := '{}';
begin
  if not exists (select 1 from public.warranty_category_map) then return new; end if;
  if new.document_type is distinct from 'invoice' or jsonb_typeof(new.items) <> 'array' then return new; end if;
  select data->'standardWarranties' into std from public.crm_settings order by id limit 1;

  for it in select value from jsonb_array_elements(new.items) loop
    if it->>'type' = 'product' and coalesce(it->>'code', '') <> '' then
      v_code := it->>'code';
      v_cat := null;
      if v_code like 'PANEL-%' then
        v_cat := 'ألواح الطاقة الشمسية';
      else
        select b->>'category' into v_cat
          from public.pricing_config pc, jsonb_array_elements(pc.data->'productCatalog') b, jsonb_array_elements(b->'rows') r
          where r->>0 = v_code limit 1;
      end if;
      v_cls := null;
      select warranty_class, requires_serial into v_cls, v_req from public.warranty_category_map where category = v_cat;
      if v_cls is not null then
        v_years := nullif(std->v_cls->>'defectYears', '')::numeric;
        if v_years is not null and v_years > 0 then
          v_perf := nullif(std->v_cls->>'performanceYears', '')::numeric;
          v_sn := substring(it->>'name' from '(?i)SN:\s*([^\s/،,;]+)');
          v_qty := coalesce(nullif(it->>'qty', '')::numeric, 0);
          if v_req then
            if v_sn is null then
              raise exception 'الصنف "%" يحتاج رقم تسلسلي — اكتبه في خانة الرقم التسلسلي', v_code;
            end if;
            if v_qty <> 1 then
              raise exception 'الصنف "%" له رقم تسلسلي، فلازم كل وحدة في بند مستقل بكمية 1', v_code;
            end if;
            if upper(v_sn) = any (v_seen) then
              raise exception 'الرقم التسلسلي % مكرر داخل نفس الفاتورة', v_sn;
            end if;
            if exists (select 1 from public.invoices i, jsonb_array_elements(i.items) x
                       where i.document_type = 'invoice' and i.status <> 'cancelled' and upper(x->>'serial') = upper(v_sn)) then
              raise exception 'الرقم التسلسلي % مسجّل في فاتورة أخرى', v_sn;
            end if;
            v_seen := v_seen || upper(v_sn);
          end if;
          v_brand := case when v_code like 'PANEL-%' then split_part(v_code, '-', 2) else null end;
          it := it || jsonb_strip_nulls(jsonb_build_object(
                  'warranty_class', v_cls, 'serial_required', v_req, 'model', v_code, 'brand', v_brand,
                  'serial', v_sn, 'warranty_years', v_years, 'performance_warranty_years', v_perf));
        end if;
      end if;
    end if;
    out_items := out_items || jsonb_build_array(it);
  end loop;
  new.items := out_items;
  return new;
end $$;


--
-- Name: invoices_enrich_warranty_items_prev(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_enrich_warranty_items_prev() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  it jsonb; out_items jsonb := '[]'::jsonb; std jsonb;
  v_code text; v_cat text; v_cls text; v_req boolean; v_years numeric; v_perf numeric;
  v_sn text; v_sn_n text; v_qty numeric; v_brand text; v_model text; v_seen text[] := '{}';
  p public.products%rowtype; v_has_p boolean;
begin
  if not exists (select 1 from public.warranty_category_map) then return new; end if;
  if new.document_type is distinct from 'invoice' or jsonb_typeof(new.items) <> 'array' then return new; end if;
  select data->'standardWarranties' into std from public.crm_settings order by id limit 1;

  for it in select value from jsonb_array_elements(new.items) loop
    if it->>'type' = 'product' and coalesce(it->>'code', '') <> '' then
      v_code := it->>'code';
      v_cat := null;
      select * into p from public.products where catalog_name = v_code limit 1;
      v_has_p := found;
      if v_has_p then
        v_cat := p.catalog_category;
        it := it || jsonb_build_object('product_code', p.product_code);
      elsif v_code like 'PANEL-%' then
        v_cat := 'ألواح الطاقة الشمسية';
      else
        select b->>'category' into v_cat
          from public.pricing_config pc, jsonb_array_elements(pc.data->'productCatalog') b, jsonb_array_elements(b->'rows') r
          where r->>0 = v_code limit 1;
      end if;
      v_cls := null; v_req := null;
      select warranty_class, requires_serial into v_cls, v_req from public.warranty_category_map where category = v_cat;
      if v_cls is not null then
        if v_has_p then v_req := p.requires_serial; end if;
        v_years := case when v_has_p and p.warranty_years is not null then p.warranty_years
                        else nullif(std->v_cls->>'defectYears', '')::numeric end;
        v_perf  := case when v_has_p and p.performance_warranty_years is not null then p.performance_warranty_years
                        else nullif(std->v_cls->>'performanceYears', '')::numeric end;
        if v_years is not null and v_years > 0 then
          v_sn := nullif(trim(coalesce(it->>'serial', '')), '');
          if v_sn is null then v_sn := substring(it->>'name' from '(?i)SN:\s*([^\s/،,;]+)'); end if;
          v_qty := coalesce(nullif(it->>'qty', '')::numeric, 0);
          if v_req then
            if v_sn is null then
              raise exception 'الصنف "%" يحتاج رقم تسلسلي — اكتبه في خانة الرقم التسلسلي', v_code;
            end if;
            if v_qty <> 1 then
              raise exception 'الصنف "%" له رقم تسلسلي، فلازم كل وحدة في بند مستقل بكمية 1', v_code;
            end if;
            v_sn_n := upper(regexp_replace(v_sn, '\s+', '', 'g'));
            if v_sn_n = any (v_seen) then
              raise exception 'الرقم التسلسلي % مكرر داخل نفس الفاتورة', v_sn;
            end if;
            if exists (select 1 from public.invoices i, jsonb_array_elements(i.items) x
                       where i.document_type = 'invoice' and i.status <> 'cancelled' and i.id is distinct from new.id
                         and upper(regexp_replace(coalesce(x->>'serial', ''), '\s+', '', 'g')) = v_sn_n) then
              raise exception 'الرقم التسلسلي % مسجّل في فاتورة أخرى', v_sn;
            end if;
            if v_sn_n not in ('N/A', 'NA', '-')
               and exists (select 1 from public.assets a
                           where a.status is distinct from 'removed' and a.serial_number is not null
                             and upper(regexp_replace(a.serial_number, '\s+', '', 'g')) = v_sn_n
                             and coalesce(a.warranty_number, '') not like 'GC-' || coalesce(new.invoice_number, '~') || '-%') then
              raise exception 'الرقم التسلسلي % مسجّل مسبقًا في ضمان آخر', v_sn;
            end if;
            v_seen := v_seen || v_sn_n;
          end if;
          v_model := case when v_has_p and coalesce(p.part_number, '') <> '' then p.part_number else v_code end;
          v_brand := case when v_has_p and p.brand is not null then p.brand
                          when v_code like 'PANEL-%' then split_part(v_code, '-', 2) else null end;
          it := it || jsonb_strip_nulls(jsonb_build_object(
                  'warranty_class', v_cls, 'serial_required', v_req, 'model', v_model, 'brand', v_brand,
                  'serial', v_sn, 'warranty_years', v_years, 'performance_warranty_years', v_perf));
        end if;
      end if;
    end if;
    out_items := out_items || jsonb_build_array(it);
  end loop;
  new.items := out_items;
  return new;
end $$;


--
-- Name: invoices_require_issued_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_require_issued_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if new.issued_at is null then
    raise exception 'Invoices must be issued through the invoice-api function (issued_at is required).';
  end if;
  return new;
end $$;


--
-- Name: invoices_void_warranties(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_void_warranties() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
    perform set_config('app.warranty_issuing', 'on', true);
    update public.assets set status = 'removed'
      where id in (select asset_id from public.warranty_certificates where invoice_id = new.id and status = 'active');
    update public.warranty_certificates
      set status = 'void', voided_at = now(), void_reason = 'invoice cancelled by credit note'
      where invoice_id = new.id and status = 'active';
    perform set_config('app.warranty_issuing', '', true);
  end if;
  return new;
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    project_id bigint,
    customer_id bigint NOT NULL,
    milestone_id bigint,
    invoice_number text NOT NULL,
    invoice_date date DEFAULT CURRENT_DATE NOT NULL,
    due_date date,
    customer_name text,
    customer_phone text,
    customer_vat_number text,
    customer_cr_number text,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    discount_total numeric DEFAULT 0 NOT NULL,
    vat_percent numeric DEFAULT 15 NOT NULL,
    subtotal numeric DEFAULT 0 NOT NULL,
    vat_amount numeric DEFAULT 0 NOT NULL,
    total numeric DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    invoice_type text DEFAULT 'simplified'::text NOT NULL,
    rep_username text,
    payment_method text,
    paid_at timestamp with time zone,
    qr_base64 text,
    approval_status text DEFAULT 'approved'::text NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    customer_address text,
    source_quotation_id bigint,
    issued_at timestamp with time zone,
    document_type text DEFAULT 'invoice'::text NOT NULL,
    related_invoice_id bigint,
    reason text,
    source_calc_quote_id bigint,
    icv bigint,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_hash text,
    previous_invoice_hash text,
    supply_date date,
    seller_snapshot jsonb,
    CONSTRAINT invoices_approval_status_check CHECK ((approval_status = ANY (ARRAY['pending'::text, 'approved'::text]))),
    CONSTRAINT invoices_document_type_check CHECK ((document_type = ANY (ARRAY['invoice'::text, 'credit_note'::text]))),
    CONSTRAINT invoices_invoice_type_check CHECK ((invoice_type = ANY (ARRAY['simplified'::text, 'standard'::text])))
);


--
-- Name: COLUMN invoices.source_quotation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.invoices.source_quotation_id IS 'If this invoice was issued against an existing customer quotation, the quotation it was generated from (items are pulled from that quotation server-side).';


--
-- Name: issue_document(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.issue_document(p_row jsonb, p_doc_type text) RETURNS public.invoices
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_prefix text; v_base text; v_key text; v_seq int; v_icv bigint; v_num text;
  v_r public.invoices; v_out public.invoices; v_issue_day date; v_supply date;
begin
  v_r := jsonb_populate_record(null::public.invoices, p_row);
  v_issue_day := (v_r.issued_at at time zone 'Asia/Riyadh')::date;
  v_supply := coalesce(v_r.supply_date, v_issue_day);
  if v_supply > v_issue_day then
    raise exception 'Supply date cannot be after the issue date';
  end if;
  if v_supply < date '2018-01-01' then
    raise exception 'Supply date is not valid';
  end if;

  select coalesce(nullif(trim(invoice_prefix), ''), 'HEWDS') into v_base from public.company_profile where id = 1;
  v_base := coalesce(v_base, 'HEWDS');
  v_prefix := case when p_doc_type = 'credit_note' then v_base || '-CN' else v_base || '-INV' end;
  v_key := v_prefix || '-' || to_char(now() at time zone 'Asia/Riyadh', 'YYYYMM');

  insert into public.invoice_counters (counter_key, last_value) values (v_key, 1)
  on conflict (counter_key) do update set last_value = public.invoice_counters.last_value + 1
  returning last_value into v_seq;

  update public.einvoice_counters set last_icv = last_icv + 1 where id = 1
  returning last_icv into v_icv;

  v_num := v_key || '-' || lpad(v_seq::text, 4, '0');

  insert into public.invoices (
    project_id, customer_id, milestone_id, source_quotation_id, source_calc_quote_id,
    invoice_number, icv, invoice_type, document_type, related_invoice_id, reason,
    issued_at, supply_date, due_date, customer_name, customer_phone, customer_address,
    customer_vat_number, customer_cr_number, items, discount_total, vat_percent,
    subtotal, vat_amount, total, status, payment_method, paid_at, rep_username,
    qr_base64, notes, created_by, approval_status, approved_by, approved_at, seller_snapshot
  ) values (
    v_r.project_id, v_r.customer_id, v_r.milestone_id, v_r.source_quotation_id, v_r.source_calc_quote_id,
    v_num, v_icv, v_r.invoice_type, v_r.document_type, v_r.related_invoice_id, v_r.reason,
    v_r.issued_at, v_supply, v_r.due_date, v_r.customer_name, v_r.customer_phone, v_r.customer_address,
    v_r.customer_vat_number, v_r.customer_cr_number, v_r.items, v_r.discount_total, v_r.vat_percent,
    v_r.subtotal, v_r.vat_amount, v_r.total, v_r.status, v_r.payment_method, v_r.paid_at, v_r.rep_username,
    v_r.qr_base64, v_r.notes, v_r.created_by, v_r.approval_status, v_r.approved_by, v_r.approved_at, v_r.seller_snapshot
  ) returning * into v_out;

  return v_out;
end $$;


--
-- Name: issue_warranty_certificates(bigint, date, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.issue_warranty_certificates(p_invoice_id bigint, p_receipt_date date, p_actor text, p_actor_role text DEFAULT 'rep'::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  inv public.invoices%rowtype;
  v_today date := (now() at time zone 'Asia/Riyadh')::date;
  v_issue_day date; v_min date; v_receipt date;
  it jsonb; ord bigint;
  v_class text; v_model text; v_brand text; v_serial text; v_serial_n text; v_req boolean;
  v_qty numeric; v_years numeric; v_perf numeric;
  v_start date; v_end date; v_perf_end date;
  v_rev int; v_number text; v_asset_id bigint; v_cert_id bigint;
  v_prev public.warranty_certificates%rowtype;
  v_issued jsonb := '[]'::jsonb; v_existing jsonb := '[]'::jsonb;
begin
  select * into inv from public.invoices where id = p_invoice_id for update;
  if not found then raise exception 'Invoice not found'; end if;
  if inv.document_type <> 'invoice' then raise exception 'Warranty certificates can only be issued against an invoice'; end if;
  if inv.status <> 'paid' then raise exception 'Invoice is not paid (status: %)', inv.status; end if;
  if inv.approval_status <> 'approved' then raise exception 'Invoice is not approved yet'; end if;
  if inv.issued_at is null then raise exception 'Invoice has not been issued'; end if;
  if exists (select 1 from public.invoices where related_invoice_id = inv.id and document_type = 'credit_note') then
    raise exception 'Invoice was cancelled by a credit note';
  end if;

  v_issue_day := (inv.issued_at at time zone 'Asia/Riyadh')::date;
  v_min := least(coalesce(inv.supply_date, v_issue_day), v_issue_day);
  v_receipt := coalesce(p_receipt_date, inv.supply_date, v_issue_day);
  if v_receipt < v_min then raise exception 'Receipt date cannot be before the invoice supply date (%)', v_min; end if;
  if v_receipt > v_today then raise exception 'Receipt date cannot be in the future'; end if;

  for it, ord in
    select e.value, e.ordinality from jsonb_array_elements(inv.items) with ordinality as e(value, ordinality)
  loop
    v_class := nullif(trim(coalesce(it->>'warranty_class', '')), '');
    if v_class is null then continue; end if;

    select * into v_prev from public.warranty_certificates
      where invoice_id = inv.id and line_index = (ord - 1)::int and status = 'active';
    if found then
      v_existing := v_existing || jsonb_build_object('line_index', ord - 1, 'id', v_prev.id, 'certificate_number', v_prev.certificate_number);
      continue;
    end if;

    v_model  := nullif(trim(coalesce(it->>'model', '')), '');
    v_brand  := nullif(trim(coalesce(it->>'brand', '')), '');
    v_serial := nullif(trim(coalesce(it->>'serial', '')), '');
    v_req    := coalesce((it->>'serial_required')::boolean, true);
    v_qty    := coalesce(nullif(it->>'qty', '')::numeric, 0);
    v_years  := coalesce(nullif(it->>'warranty_years', '')::numeric, 0);
    v_perf   := nullif(it->>'performance_warranty_years', '')::numeric;

    if v_model is null then raise exception 'Line %: model is required', ord; end if;
    if v_years <= 0 then raise exception 'Line %: warranty years is required', ord; end if;
    if v_qty < 1 or v_qty <> trunc(v_qty) then raise exception 'Line %: invalid quantity', ord; end if;
    if v_req then
      if v_serial is null then raise exception 'Line %: serial number is required', ord; end if;
      if v_qty <> 1 then raise exception 'Line %: serialized items must have quantity 1', ord; end if;
      v_serial_n := upper(regexp_replace(v_serial, '\s+', '', 'g'));
    else
      v_serial_n := null;
    end if;

    v_start := v_receipt;
    v_end := (v_start + make_interval(months => round(v_years * 12)::int) - interval '1 day')::date;
    v_perf_end := case when v_perf is not null and v_perf > 0
      then (v_start + make_interval(months => round(v_perf * 12)::int) - interval '1 day')::date end;

    select coalesce(max(revision) + 1, 0) into v_rev from public.warranty_certificates
      where invoice_id = inv.id and line_index = (ord - 1)::int;
    v_number := 'GC-' || inv.invoice_number || '-' || lpad(ord::text, 2, '0') || case when v_rev > 0 then '-R' || v_rev else '' end;

    perform set_config('app.warranty_issuing', 'on', true);
    insert into public.assets (customer_id, asset_type, manufacturer, model, serial_number, quantity,
      warranty_start_date, warranty_end_date, warranty_years, performance_warranty_years,
      performance_warranty_end_date, warranty_number, status, is_legacy, notes)
    values (inv.customer_id, v_class, v_brand, v_model, v_serial, v_qty::int,
      v_start, v_end, v_years, v_perf, v_perf_end, v_number, 'active', false, 'Issued from invoice ' || inv.invoice_number)
    returning id into v_asset_id;
    perform set_config('app.warranty_issuing', '', true);

    insert into public.warranty_certificates (certificate_number, invoice_id, line_index, revision, customer_id, asset_id,
      serial_normalized, warranty_start, warranty_end, snapshot, issued_by)
    values (v_number, inv.id, (ord - 1)::int, v_rev, inv.customer_id, v_asset_id, v_serial_n, v_start, v_end,
      jsonb_build_object(
        'certificate_number', v_number,
        'invoice', jsonb_build_object('id', inv.id, 'number', inv.invoice_number, 'issued_at', inv.issued_at, 'supply_date', inv.supply_date),
        'receipt_date', v_receipt,
        'customer', jsonb_build_object('id', inv.customer_id, 'name', inv.customer_name, 'phone', inv.customer_phone),
        'item', jsonb_build_object('line_index', ord - 1, 'name', it->>'name', 'class', v_class, 'brand', v_brand,
                 'model', v_model, 'serial', v_serial, 'qty', v_qty,
                 'warranty_years', v_years, 'performance_warranty_years', v_perf),
        'warranty', jsonb_build_object('start', v_start, 'end', v_end, 'performance_end', v_perf_end),
        'seller', inv.seller_snapshot),
      p_actor)
    returning id into v_cert_id;

    insert into public.audit_log (actor, actor_role, action_type, entity_type, entity_id, entity_label, new_value)
    values (p_actor, p_actor_role, 'issue_warranty', 'warranty_certificate', v_cert_id, v_number,
            jsonb_build_object('invoice', inv.invoice_number, 'start', v_start, 'end', v_end));

    v_issued := v_issued || jsonb_build_object('line_index', ord - 1, 'id', v_cert_id, 'certificate_number', v_number);
  end loop;

  if jsonb_array_length(v_issued) = 0 and jsonb_array_length(v_existing) = 0 then
    raise exception 'No warranty-eligible lines on this invoice';
  end if;
  return jsonb_build_object('issued', v_issued, 'existing', v_existing);
end $$;


--
-- Name: next_invoice_seq(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.next_invoice_seq(p_key text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v integer;
begin
  insert into public.invoice_counters (counter_key, last_value) values (p_key, 1)
  on conflict (counter_key) do update set last_value = public.invoice_counters.last_value + 1
  returning last_value into v;
  return v;
end $$;


--
-- Name: next_product_code(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.next_product_code(p_family text) RETURNS text
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare n integer;
begin
  update public.product_families set next_seq = next_seq + 1 where prefix = p_family returning next_seq - 1 into n;
  if n is null then raise exception 'Unknown product family %', p_family; end if;
  return p_family || '-' || lpad(n::text, 5, '0');
end $$;


--
-- Name: next_quote_ref(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.next_quote_ref(p_at timestamp with time zone) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare k text; n int;
begin
  k := 'QL-' || to_char(p_at at time zone 'Asia/Riyadh', 'YYYYMM');
  insert into public.quote_ref_counters (counter_key, last_value) values (k, 1)
  on conflict (counter_key) do update set last_value = public.quote_ref_counters.last_value + 1
  returning last_value into n;
  return k || '-' || lpad(n::text, 4, '0');
end $$;


--
-- Name: pipeline_alerts(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_alerts(p_rep text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  with base as (
    select * from public.v_pipeline_opps
    where is_open and (p_rep is null or rep_norm = p_rep)),
  today as (select (now() at time zone 'Asia/Riyadh')::date d)
  select jsonb_build_object(
    'overdue', (select count(*) from base where is_overdue),
    'stale',   (select count(*) from base where is_stale),
    'today',   (select count(*) from base, today where next_follow_up_date = today.d),
    'by_rep',  coalesce((select jsonb_agg(x order by (x->>'overdue')::int desc) from (
        select jsonb_build_object('rep', case when rep_norm='' then '(بدون مندوب)' else rep_norm end,
          'overdue', count(*) filter (where is_overdue),
          'stale', count(*) filter (where is_stale),
          'today', count(*) filter (where next_follow_up_date = (select d from today))) x
        from base group by rep_norm) s), '[]'::jsonb),
    'top_overdue', coalesce((select jsonb_agg(public.pipeline_card(to_jsonb(t)) order by t.next_follow_up_date) from (
        select * from base where is_overdue order by next_follow_up_date asc, estimated_value desc nulls last limit 8) t), '[]'::jsonb)
  )
$$;


--
-- Name: pipeline_board(jsonb, integer, text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_board(p jsonb, p_per_stage integer DEFAULT 12, p_expand text[] DEFAULT '{}'::text[]) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  with f as (select * from public.pipeline_filtered(p)),
  stats as (
    select stage, count(*) n, coalesce(sum(estimated_value),0) total, coalesce(sum(weighted_value),0) weighted
    from f group by stage),
  ranked as (
    select f.*, row_number() over (partition by f.stage
      order by f.is_overdue desc, f.estimated_value desc nulls last, f.stage_changed_at desc, f.id) rn
    from f where f.is_open or f.stage = any(p_expand))
  select jsonb_build_object(
    'stages', coalesce((select jsonb_object_agg(stage, jsonb_build_object('count',n,'total',total,'weighted',round(weighted))) from stats), '{}'::jsonb),
    'cards',  coalesce((select jsonb_agg(public.pipeline_card(to_jsonb(r)) order by r.stage, r.rn) from ranked r where r.rn <= p_per_stage), '[]'::jsonb),
    'totals', jsonb_build_object(
        'count', (select count(*) from f),
        'open_count', (select count(*) from f where is_open),
        'open_value', (select coalesce(sum(estimated_value),0) from f where is_open),
        'open_weighted', (select round(coalesce(sum(weighted_value),0)) from f where is_open)),
    'all_open_weighted', (select round(coalesce(sum(weighted_value),0)) from public.v_pipeline_opps where is_open),
    'all_count', (select count(*) from public.v_pipeline_opps)
  )
$$;


--
-- Name: pipeline_card(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_card(j jsonb) RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $$
  select jsonb_build_object(
    'id',j->'id','name',j->'name','stage',j->'stage','estimated_value',j->'estimated_value','prob_eff',j->'prob_eff',
    'project_type',j->'project_type','segment',j->'segment','sales_person',j->'sales_person',
    'next_action',j->'next_action','next_follow_up_date',j->'next_follow_up_date',
    'days_in_stage',j->'days_in_stage','is_overdue',j->'is_overdue','is_stale',j->'is_stale',
    'customer_name',j->'customer_name','customer_phone',j->'customer_phone','site_name',j->'site_name')
$$;


--
-- Name: stage_default_prob(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stage_default_prob(p_stage text) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $$
  select case p_stage
    when 'new_lead' then 10 when 'qualified' then 20 when 'initial_contact' then 20
    when 'survey_required' then 30 when 'survey_completed' then 40 when 'technical_study' then 50
    when 'quotation_sent' then 60 when 'negotiation' then 75 when 'final_approval' then 90
    when 'follow_up_later' then 10 when 'won' then 100 else 0 end
$$;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    name text,
    phone text NOT NULL,
    rep_username text,
    quotes_count integer DEFAULT 0 NOT NULL,
    first_quote_at timestamp with time zone,
    last_quote_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    price_feedback text,
    blocker_reason text,
    blocker_notes text,
    next_follow_up_date date,
    last_contact_at timestamp with time zone,
    assigned_rep text,
    priority text DEFAULT 'warm'::text,
    lost_reason_detail text,
    city text,
    crm_created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_type text DEFAULT 'individual'::text,
    classification text,
    commercial_registration text,
    vat_number text,
    unified_number text,
    region text,
    lead_source text
);


--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunities (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    contact_id bigint,
    name text NOT NULL,
    project_type text,
    stage text DEFAULT 'new_lead'::text NOT NULL,
    stage_changed_at timestamp with time zone DEFAULT now() NOT NULL,
    estimated_capacity text,
    estimated_value numeric,
    expected_cost numeric,
    probability integer,
    expected_closing_date date,
    sales_person text,
    competitor_name text,
    competitor_price numeric,
    lost_reason text,
    next_action text,
    next_follow_up_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    segment text
);


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    name text NOT NULL,
    region text,
    city text,
    location_address text,
    gps_lat double precision,
    gps_lng double precision,
    google_maps_link text,
    farm_area text,
    agricultural_activity text,
    number_of_wells integer,
    number_of_pumps integer,
    water_source text,
    well_depth text,
    required_water_flow text,
    required_operating_hours text,
    current_energy_source text,
    diesel_consumption text,
    electricity_consumption text,
    existing_system text,
    technical_notes text,
    photos jsonb DEFAULT '[]'::jsonb NOT NULL,
    documents jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: v_pipeline_opps; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_pipeline_opps WITH (security_invoker='true') AS
 SELECT o.id,
    o.name,
    o.stage,
    o.estimated_value,
    o.probability,
    COALESCE((o.probability)::numeric, public.stage_default_prob(o.stage)) AS prob_eff,
    ((COALESCE(o.estimated_value, (0)::numeric) * COALESCE((o.probability)::numeric, public.stage_default_prob(o.stage))) / (100)::numeric) AS weighted_value,
    o.project_type,
    o.segment,
    o.sales_person,
    regexp_replace(btrim(COALESCE(o.sales_person, ''::text)), '\s+'::text, ' '::text, 'g'::text) AS rep_norm,
    o.next_action,
    o.next_follow_up_date,
    COALESCE(o.stage_changed_at, o.created_at) AS stage_changed_at,
    o.created_at,
    o.customer_id,
    c.name AS customer_name,
    c.phone AS customer_phone,
    s.name AS site_name,
    (o.stage <> ALL (ARRAY['won'::text, 'lost'::text])) AS is_open,
    ((o.stage <> ALL (ARRAY['won'::text, 'lost'::text])) AND (o.next_follow_up_date IS NOT NULL) AND (o.next_follow_up_date < ((now() AT TIME ZONE 'Asia/Riyadh'::text))::date)) AS is_overdue,
    ((o.stage <> ALL (ARRAY['won'::text, 'lost'::text])) AND (COALESCE(o.stage_changed_at, o.created_at) < (now() - '14 days'::interval))) AS is_stale,
    GREATEST(0, (((now() AT TIME ZONE 'Asia/Riyadh'::text))::date - (COALESCE(o.stage_changed_at, o.created_at))::date)) AS days_in_stage
   FROM ((public.opportunities o
     LEFT JOIN public.customers c ON ((c.id = o.customer_id)))
     LEFT JOIN public.sites s ON ((s.id = o.site_id)));


--
-- Name: pipeline_filtered(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_filtered(p jsonb) RETURNS SETOF public.v_pipeline_opps
    LANGUAGE sql STABLE
    AS $$
  select v.* from public.v_pipeline_opps v
  where (nullif(p->>'rep','') is null or v.rep_norm = p->>'rep')
    and (nullif(p->>'segment','') is null or v.segment = p->>'segment')
    and (nullif(p->>'type','') is null or v.project_type = p->>'type')
    and (not coalesce((p->>'overdue')::boolean,false) or v.is_overdue)
    and (not coalesce((p->>'stale')::boolean,false) or v.is_stale)
    and (nullif(btrim(coalesce(p->>'search','')),'') is null or
         (coalesce(v.name,'')||' '||coalesce(v.customer_name,'')||' '||coalesce(v.customer_phone,'')||' '||coalesce(v.site_name,'')||' '||coalesce(v.next_action,''))
         ilike '%'||replace(replace(btrim(p->>'search'),'%','\%'),'_','\_')||'%')
$$;


--
-- Name: pipeline_stage_page(jsonb, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_stage_page(p jsonb, p_stage text, p_offset integer, p_limit integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('cards', coalesce(jsonb_agg(public.pipeline_card(to_jsonb(t)) order by t.rn), '[]'::jsonb))
  from (
    select f.*, row_number() over (order by f.is_overdue desc, f.estimated_value desc nulls last, f.stage_changed_at desc, f.id) rn
    from public.pipeline_filtered(p) f where f.stage = p_stage
    order by rn
    offset greatest(p_offset,0) limit least(greatest(p_limit,1),200)
  ) t
$$;


--
-- Name: pipeline_table(jsonb, text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pipeline_table(p jsonb, p_sort text, p_dir text, p_offset integer, p_limit integer) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_col text := case p_sort
    when 'name' then 'name' when 'customer_name' then 'customer_name' when 'estimated_value' then 'estimated_value'
    when 'prob_eff' then 'prob_eff' when 'next_follow_up_date' then 'next_follow_up_date'
    when 'days_in_stage' then 'days_in_stage' when 'sales_person' then 'sales_person'
    when 'segment' then 'segment' when 'stage' then 'stage' else 'stage_changed_at' end;
  v_dir text := case when lower(coalesce(p_dir,'')) = 'asc' then 'asc' else 'desc' end;
  v_rows jsonb; v_total bigint;
begin
  select count(*) into v_total from public.pipeline_filtered(p);
  execute format(
    'select coalesce(jsonb_agg(public.pipeline_card(to_jsonb(t)) order by t.rn), ''[]''::jsonb) from (
       select f.*, row_number() over (order by f.%I %s nulls last, f.id) rn
       from public.pipeline_filtered($1) f
       order by rn offset $2 limit $3) t',
    v_col, v_dir)
  into v_rows using p, greatest(p_offset,0), least(greatest(p_limit,1),200);
  return jsonb_build_object('rows', v_rows, 'total', v_total);
end $_$;


--
-- Name: products_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.products_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    if new.product_code is null or new.product_code = '' then
      new.product_code := public.next_product_code(new.family);
    end if;
    return new;
  elsif tg_op = 'UPDATE' then
    if new.product_code is distinct from old.product_code then raise exception 'product_code is immutable'; end if;
    if new.family is distinct from old.family then raise exception 'product family is immutable'; end if;
    new.updated_at := now();
    return new;
  end if;
  raise exception 'Products cannot be deleted; set status = inactive.';
end $$;


--
-- Name: quotes_cart_enforce(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.quotes_cart_enforce() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  cfg jsonb; vatr numeric; is_rep boolean;
  k text; kc jsonb; it jsonb; e jsonb;
  mode text; unit text; price numeric; qty numeric; amt numeric; minimum numeric;
  repedit boolean; label text; cprice numeric; p numeric; q numeric;
  items_sub numeric := 0; extras_sub numeric := 0; gross numeric;
  adj_in numeric; adj numeric; net numeric; vat_amt numeric; total numeric;
  out_extras jsonb := '[]'::jsonb; seen text[] := '{}';
begin
  if new.snapshot is null or new.snapshot->>'type' is distinct from 'product-cart' then
    return new;
  end if;
  begin
    select data into cfg from public.pricing_config where id = 1;
    vatr := coalesce(public.cart_safe_num(cfg->>'vat'), 0.15);
    is_rep := coalesce(new.rep_username, '') <> '';

    if jsonb_typeof(new.snapshot->'items') = 'array' then
      for it in select * from jsonb_array_elements(new.snapshot->'items') loop
        p := coalesce(public.cart_safe_num(it->>'price'), 0);
        q := greatest(1, round(coalesce(public.cart_safe_num(it->>'qty'), 1)));
        items_sub := items_sub + greatest(p, 0) * q;
      end loop;
    end if;

    if is_rep and jsonb_typeof(new.snapshot->'extras') = 'array' then
      for e in select * from jsonb_array_elements(new.snapshot->'extras') loop
        k := e->>'key';
        if k is null or k not in ('civil', 'elec', 'transport') or k = any(seen) then continue; end if;
        seen := seen || k;
        kc := cfg->'offgrid'->'cartExtras'->k;
        mode := case when kc->>'mode' = 'fixed' then 'fixed' else 'variable' end;
        unit := coalesce(nullif(kc->>'unit', ''), case k when 'transport' then 'trip' else 'panel' end);
        price := coalesce(public.cart_safe_num(kc->>'price'),
                   public.cart_safe_num(case k when 'civil' then cfg->>'mechInstallPerPanel'
                                               when 'elec' then cfg->>'elecInstallPerPanel'
                                               else cfg->>'transportPerTrip' end), 0);
        minimum := case when k = 'transport'
                        then coalesce(public.cart_safe_num(kc->>'minimum'), public.cart_safe_num(cfg->>'transportMinimum'), 0)
                        else 0 end;
        repedit := coalesce(kc->>'repEdit' = 'true', false);
        label := coalesce(nullif(kc->>'label', ''),
                   case k when 'civil' then 'أعمال التركيب المدني' when 'elec' then 'أعمال التركيب الكهربائي' else 'النقل' end);
        cprice := public.cart_safe_num(e->>'unitPrice');
        if repedit and cprice is not null and cprice >= 0 then price := cprice; end if;
        if mode = 'fixed' then
          qty := 1; amt := price;
        else
          qty := greatest(0, coalesce(public.cart_safe_num(e->>'qty'), 0));
          amt := qty * price;
          if k = 'transport' and qty > 0 and minimum > 0 then amt := greatest(amt, minimum); end if;
        end if;
        amt := round(amt, 2);
        if amt > 0 then
          out_extras := out_extras || jsonb_build_array(jsonb_build_object(
            'key', k, 'label', label, 'mode', mode, 'unit', unit, 'qty', qty,
            'unitPrice', price, 'amount', amt, 'repEditable', repedit));
          extras_sub := extras_sub + amt;
        end if;
      end loop;
    end if;

    adj_in := case when is_rep then coalesce(public.cart_safe_num(new.snapshot->>'specialDiscountAmt'), 0) else 0 end;
    gross := items_sub + extras_sub;
    adj := case when adj_in > 0 then least(gross, adj_in) else adj_in end;
    net := gross - adj;
    vat_amt := net * vatr;
    total := net + vat_amt;

    new.snapshot := new.snapshot || jsonb_build_object(
      'extras', out_extras, 'itemsSubtotal', round(items_sub, 2), 'extrasSubtotal', round(extras_sub, 2),
      'specialDiscountAmt', adj, 'subtotal', round(net, 2), 'vat', round(vat_amt, 2),
      'total', round(total, 2), 'vatRate', vatr, 'serverVerified', true);
    new.final_total := round(total);
  exception when others then
    raise warning 'quotes_cart_enforce skipped: %', sqlerrm;
  end;
  return new;
end $$;


--
-- Name: quotes_stamp_codes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.quotes_stamp_codes() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
declare r text; ql text; parent_ref text; base text; n int; ok boolean;
begin
  if new.ref_code is null then
    new.created_at := coalesce(new.created_at, now());

    -- Revision of an existing quote of the SAME customer: keeps the base reference, adds -R1, -R2 ...
    parent_ref := nullif(new.snapshot->>'revisionOf', '');
    if parent_ref is not null then
      base := regexp_replace(parent_ref, '-R[0-9]+$', '');
      select true into ok from public.quotes
        where (ref_code = base or ref_code like base || '-R%') and client_phone = new.client_phone limit 1;
      if coalesce(ok, false) then
        select coalesce(max(revision_no), 0) + 1 into n from public.quotes
          where ref_code = base or ref_code like base || '-R%';
        r := base || '-R' || n;
        new.revision_no := n;
      else
        new.snapshot := new.snapshot - 'revisionOf';
      end if;
    end if;

    if r is null then r := public.next_quote_ref(new.created_at); end if;
    new.ref_code := r;
    ql := public.build_ql_code(new.snapshot, new.client_phone, new.created_at);
    new.ql_code := ql;
    if new.snapshot is not null then
      new.snapshot := new.snapshot || jsonb_strip_nulls(jsonb_build_object('refCode', r, 'qlCode', ql, 'revisionNo', new.revision_no));
    end if;
  end if;
  return new;
end $_$;


--
-- Name: sync_products_from_catalog(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_products_from_catalog() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare n integer := 0; k integer;
begin
  insert into public.products (family, category, catalog_category, catalog_name, brand, name_ar, requires_serial, status)
  select m.family, m.sub_category, s.catname, s.nm, nullif(s.det->>'brand',''), s.nm, m.requires_serial,
         case when s.det->>'available' = 'false' then 'inactive' else 'active' end
  from (
    select distinct on (t.r->>0) c->>'category' catname, t.r->>0 nm, x.o c_ord, t.ord r_ord,
           c->'productDetails'->((t.ord - 1)::text) det
    from public.pricing_config pc, jsonb_array_elements(pc.data->'productCatalog') with ordinality x(c, o),
         jsonb_array_elements(c->'rows') with ordinality t(r, ord)
    where pc.id = 1 and coalesce(t.r->>0, '') <> ''
    order by t.r->>0, x.o, t.ord
  ) s
  join public.catalog_category_map m on m.catalog_category = s.catname
  where not exists (select 1 from public.products p where p.catalog_name = s.nm)
  order by s.c_ord, s.r_ord;
  get diagnostics k = row_count; n := n + k;

  insert into public.products (family, category, catalog_category, catalog_name, brand, name_ar, requires_serial, status)
  select m.family, m.sub_category, m.catalog_category,
         'PANEL-' || (p->>'brand') || '-' || (p->>'power') || 'W', p->>'brand', (p->>'brand') || ' ' || (p->>'power') || 'W',
         m.requires_serial, case when coalesce(p->>'visible', 'true') = 'false' then 'inactive' else 'active' end
  from public.pricing_config pc, jsonb_array_elements(pc.data->'panels') with ordinality t(p, ord),
       public.catalog_category_map m
  where pc.id = 1 and m.catalog_category = 'ألواح الطاقة الشمسية'
    and coalesce(p->>'brand', '') <> '' and coalesce(p->>'power', '') <> ''
    and not exists (select 1 from public.products x where x.catalog_name = 'PANEL-' || (p->>'brand') || '-' || (p->>'power') || 'W')
  order by ord;
  get diagnostics k = row_count; n := n + k;

  -- mirror availability of existing products from the catalog
  update public.products pr set status = case when s.det->>'available' = 'false' then 'inactive' else 'active' end
  from (
    select t.r->>0 nm, c->'productDetails'->((t.ord - 1)::text) det
    from public.pricing_config pc, jsonb_array_elements(pc.data->'productCatalog') c, jsonb_array_elements(c->'rows') with ordinality t(r, ord)
    where pc.id = 1
  ) s
  where pr.catalog_name = s.nm and s.det is not null
    and pr.status is distinct from case when s.det->>'available' = 'false' then 'inactive' else 'active' end;

  update public.products pr set status = case when coalesce(p->>'visible', 'true') = 'false' then 'inactive' else 'active' end
  from public.pricing_config pc, jsonb_array_elements(pc.data->'panels') p
  where pc.id = 1 and pr.catalog_name = 'PANEL-' || (p->>'brand') || '-' || (p->>'power') || 'W'
    and pr.status is distinct from case when coalesce(p->>'visible', 'true') = 'false' then 'inactive' else 'active' end;
  return n;
end $$;


--
-- Name: sys_audit(text, text, bigint, text, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sys_audit(p_action text, p_entity text, p_id bigint, p_label text, p_old jsonb, p_new jsonb) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.audit_log
    (actor, actor_role, action_type, entity_type, entity_id, entity_label, old_value, new_value)
  values ('system', 'system', p_action, p_entity, p_id, p_label, p_old, p_new);
exception when others then
  null; -- never break the primary action over a logging failure
end $$;


--
-- Name: trg_category_map_warranty(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_category_map_warranty() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  -- A newly mapped catalog category also becomes warranty-capable (inert until a rule/years are set).
  insert into public.warranty_category_map (category, warranty_class, requires_serial)
  values (new.catalog_category, coalesce(nullif(new.sub_category, ''), lower(new.family)), new.requires_serial)
  on conflict (category) do nothing;
  return null;
end $$;


--
-- Name: trg_guard_linked_cost(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_guard_linked_cost() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare b record; v_exp bigint;
begin
  if exists (select 1 from public.treasury_entries where project_cost_id = old.id) then
    raise exception 'التكلفة دي مرتبطة بحركة في الخزنة — احذف الحركة من شاشة الخزنة';
  end if;
  if exists (select 1 from public.projects where id = old.project_id) then
    for b in select * from public.supplier_bills where project_cost_id = old.id loop
      v_exp := null;
      if b.doc_type = 'invoice' then
        insert into public.expenses (expense_date, category, description, amount, tax_treatment, created_by)
        values (b.bill_date, 'other', coalesce(b.description, 'فاتورة ' || coalesce(b.bill_number, '') || ' (اتشالت من المشروع)'), b.amount, b.tax_treatment, 'treasury')
        returning id into v_exp;
      end if;
      update public.supplier_bills set project_id = null, project_cost_id = null, expense_id = v_exp where id = b.id;
    end loop;
  end if;
  return old;
end $$;


--
-- Name: trg_guard_linked_distribution(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_guard_linked_distribution() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if exists (select 1 from public.treasury_entries where distribution_id = old.id) then
    raise exception 'السحب ده مرتبط بحركة في الخزنة — احذف الحركة من شاشة الخزنة';
  end if;
  return old;
end $$;


--
-- Name: trg_guard_linked_expense(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_guard_linked_expense() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if exists (select 1 from public.treasury_entries where expense_id = old.id) then
    raise exception 'المصروف ده مرتبط بحركة في الخزنة — احذف الحركة من شاشة الخزنة';
  end if;
  if exists (select 1 from public.supplier_bills where expense_id = old.id) then
    raise exception 'المصروف ده ناتج عن فاتورة مورد — احذف الفاتورة من شاشة الموردين';
  end if;
  return old;
end $$;


--
-- Name: trg_milestone_paid_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_milestone_paid_sync() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_pay bigint; v_avail numeric; v_short numeric;
begin
  if coalesce(current_setting('app.skip_ms_sync', true), '') = '1' then return new; end if;
  if new.status is not distinct from old.status then return new; end if;

  if new.status = 'paid' then
    if exists (select 1 from payments where milestone_id = new.id) then return new; end if;
    if coalesce(new.amount, 0) <= 0 then return new; end if;
    select id into v_pay from payments
     where project_id = new.project_id and milestone_id is null and abs(amount - new.amount) < 0.005
     order by payment_date, id limit 1 for update;
    if v_pay is not null then
      update payments set milestone_id = new.id where id = v_pay;
      return new;
    end if;
    select coalesce(sum(amount), 0) into v_avail from payments where project_id = new.project_id and milestone_id is null;
    v_avail := v_avail - coalesce((select sum(m.amount) from payment_milestones m
        where m.project_id = new.project_id and m.id <> new.id and m.status = 'paid'
          and not exists (select 1 from payments x where x.milestone_id = m.id)), 0);
    v_short := new.amount - greatest(v_avail, 0);
    if v_short > 0.005 then
      insert into payments (project_id, amount, payment_date, notes, milestone_id, auto_created)
      values (new.project_id, round(v_short, 2), current_date, 'تلقائي من خطة السداد: ' || coalesce(new.title, ''), new.id, true);
    end if;

  elsif old.status = 'paid' then
    delete from payments p where p.milestone_id = new.id and p.auto_created
       and not exists (select 1 from treasury_entries e where e.payment_id = p.id);
    update payments set milestone_id = null where milestone_id = new.id;
  end if;
  return new;
end $$;


--
-- Name: trg_opportunities_set_segment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_opportunities_set_segment() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v numeric;
begin
  begin
    v := nullif(regexp_replace(coalesce(new.estimated_capacity,''), '[^0-9.]', '', 'g'), '')::numeric;
  exception when others then v := null; end;
  new.segment := public.hp_segment(v);
  return new;
end $$;


--
-- Name: trg_payment_delete_milestone(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_payment_delete_milestone() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if pg_trigger_depth() > 1 or old.milestone_id is null then return null; end if;
  perform set_config('app.skip_ms_sync', '1', true);
  update payment_milestones set status = 'pending', updated_at = now() where id = old.milestone_id and status = 'paid';
  perform set_config('app.skip_ms_sync', '0', true);
  return null;
end $$;


--
-- Name: trg_payment_match_milestone(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_payment_match_milestone() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_m bigint;
begin
  if new.milestone_id is not null then return new; end if;
  select m.id into v_m from payment_milestones m
   where m.project_id = new.project_id and m.status <> 'paid' and m.amount is not null
     and abs(m.amount - new.amount) < 0.005
     and not exists (select 1 from payments x where x.milestone_id = m.id)
   order by m.due_date nulls last, m.id limit 1 for update;
  if v_m is not null then
    new.milestone_id := v_m;
    perform set_config('app.skip_ms_sync', '1', true);
    update payment_milestones set status = 'paid', updated_at = now() where id = v_m;
    perform set_config('app.skip_ms_sync', '0', true);
  end if;
  return new;
end $$;


--
-- Name: trg_payments_recalc(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_payments_recalc() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if tg_op in ('INSERT', 'UPDATE') then
      perform public.fn_project_recalc_payment(new.project_id);
    end if;
    if tg_op = 'DELETE' or (tg_op = 'UPDATE' and old.project_id is distinct from new.project_id) then
      perform public.fn_project_recalc_payment(old.project_id);
    end if;
  exception when others then
    raise warning 'trg_payments_recalc failed: %', sqlerrm;
  end;
  return null;
end $$;


--
-- Name: trg_pricing_config_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_pricing_config_sync() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    perform public.sync_products_from_catalog();
  exception when others then
    raise warning 'sync_products_from_catalog failed: %', sqlerrm;
  end;
  return null;
end $$;


--
-- Name: trg_projects_contract_recalc(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_projects_contract_recalc() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if new.contract_value is distinct from old.contract_value then
      perform public.fn_project_recalc_payment(new.id);
    end if;
  exception when others then
    raise warning 'trg_projects_contract_recalc failed: %', sqlerrm;
  end;
  return null;
end $$;


--
-- Name: trg_projects_pipeline_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_projects_pipeline_sync() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if tg_op = 'INSERT' then
      perform public.fn_sync_project_pipeline(new.opportunity_id, new.customer_id);
    elsif tg_op = 'DELETE' then
      perform public.fn_sync_project_pipeline(old.opportunity_id, old.customer_id);
    elsif tg_op = 'UPDATE'
          and ((old.status = 'cancelled') is distinct from (new.status = 'cancelled')) then
      perform public.fn_sync_project_pipeline(new.opportunity_id, new.customer_id);
    end if;
  exception when others then
    raise warning 'trg_projects_pipeline_sync failed: %', sqlerrm;
  end;
  return null;
end $$;


--
-- Name: trg_projects_status_auto(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_projects_status_auto() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if tg_op = 'INSERT' then
      if new.status is null or new.status = 'pending' then
        new.status := 'preparing';
      end if;
      if new.actual_supply_date is not null and new.status <> 'cancelled' then
        new.status := 'commissioned';
      end if;
    else
      if new.actual_supply_date is distinct from old.actual_supply_date then
        if new.actual_supply_date is not null and new.status <> 'cancelled' then
          new.status := 'commissioned';
        elsif new.actual_supply_date is null
              and new.status = 'commissioned' and old.status = 'commissioned' then
          new.status := 'preparing';
        end if;
      end if;
    end if;
  exception when others then
    raise warning 'trg_projects_status_auto failed: %', sqlerrm;
  end;
  return new;
end $$;


--
-- Name: trg_quotations_set_segment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_quotations_set_segment() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin new.segment := public.hp_segment(new.pump_hp); return new; end $$;


--
-- Name: trg_quotes_auto_opportunity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_quotes_auto_opportunity() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if new.customer_id is null then return new; end if;
    if exists (select 1 from public.opportunities o
               where o.customer_id = new.customer_id and o.stage not in ('won','lost')) then
      return new;
    end if;
    insert into public.opportunities
      (customer_id, name, project_type, stage, estimated_capacity, estimated_value,
       sales_person, next_action, next_follow_up_date, notes)
    values
      (new.customer_id,
       'عرض سعر ' || coalesce(nullif(trim(to_char(new.hp, 'FM999999990.##')), ''), '?') || ' حصان',
       'solar_pumping', 'quotation_sent',
       new.hp::text, new.final_total,
       new.rep_display_name,
       'متابعة العرض مع العميل',
       current_date + case when new.segment in ('large','mega') then 2 else 3 end,
       'أُنشئت تلقائيًا من عرض السعر ' || coalesce(new.ref_code, new.id::text));
  exception when others then
    null; -- never break quote saving
  end;
  return new;
end $$;


--
-- Name: trg_quotes_bump_customer_priority(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_quotes_bump_customer_priority() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.customer_id is not null and new.segment in ('large','mega') then
    update public.customers set priority = 'hot', updated_at = now()
    where id = new.customer_id and coalesce(priority,'') <> 'hot';
  end if;
  return new;
end $$;


--
-- Name: trg_quotes_mark_contacted(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_quotes_mark_contacted() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  begin
    if new.customer_id is not null then
      update public.customers set status = 'contacted', updated_at = now()
       where id = new.customer_id and status = 'new';
    end if;
  exception when others then
    raise warning 'trg_quotes_mark_contacted failed: %', sqlerrm;
  end;
  return new;
end $$;


--
-- Name: trg_quotes_set_segment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_quotes_set_segment() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin new.segment := public.hp_segment(new.hp); return new; end $$;


--
-- Name: void_warranty_certificate(bigint, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.void_warranty_certificate(p_cert_id bigint, p_reason text, p_actor text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare c public.warranty_certificates%rowtype;
begin
  if length(trim(coalesce(p_reason, ''))) < 3 then raise exception 'Void reason is required'; end if;
  select * into c from public.warranty_certificates where id = p_cert_id for update;
  if not found or c.status <> 'active' then raise exception 'Active certificate not found'; end if;
  perform set_config('app.warranty_issuing', 'on', true);
  update public.assets set status = 'removed' where id = c.asset_id;
  perform set_config('app.warranty_issuing', '', true);
  update public.warranty_certificates set status = 'void', voided_at = now(), void_reason = trim(p_reason) where id = c.id;
  insert into public.audit_log (actor, actor_role, action_type, entity_type, entity_id, entity_label, new_value)
  values (p_actor, 'admin', 'void_warranty', 'warranty_certificate', c.id, c.certificate_number, jsonb_build_object('reason', trim(p_reason)));
  return jsonb_build_object('ok', true, 'certificate_number', c.certificate_number);
end $$;


--
-- Name: warranty_cert_after_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.warranty_cert_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if old.asset_id is not null then
    perform set_config('app.warranty_issuing', 'on', true);
    delete from public.assets where id = old.asset_id and is_legacy = false;
    perform set_config('app.warranty_issuing', '', true);
  end if;
  return old;
end $$;


--
-- Name: warranty_cert_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.warranty_cert_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'DELETE' then
    if coalesce(current_setting('app.allow_invoice_delete', true), '') = 'on'
       or coalesce((select trial_mode from public.einvoice_config where id = 1), false) then
      return old;
    end if;
    raise exception 'Warranty certificates cannot be deleted. Void the certificate instead.';
  end if;
  if (new.certificate_number, new.invoice_id, new.line_index, new.revision, new.customer_id, new.asset_id,
      new.serial_normalized, new.snapshot, new.warranty_start, new.warranty_end, new.issued_by, new.issued_at)
     is distinct from
     (old.certificate_number, old.invoice_id, old.line_index, old.revision, old.customer_id, old.asset_id,
      old.serial_normalized, old.snapshot, old.warranty_start, old.warranty_end, old.issued_by, old.issued_at) then
    raise exception 'Issued warranty certificate content is immutable.';
  end if;
  if old.status = 'void' and new.status <> 'void' then
    raise exception 'A voided certificate cannot be reactivated.';
  end if;
  return new;
end $$;


--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    activity_type text DEFAULT 'call'::text NOT NULL,
    description text,
    result text,
    next_action text,
    next_follow_up_date date,
    rep_username text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: admin_secret; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_secret (
    id integer DEFAULT 1 NOT NULL,
    password_hash text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    session_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    id integer DEFAULT 1 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    opportunity_id bigint,
    asset_type text DEFAULT 'other'::text NOT NULL,
    manufacturer text,
    model text,
    serial_number text,
    capacity text,
    quantity integer DEFAULT 1,
    location_note text,
    installation_date date,
    warranty_start_date date,
    warranty_end_date date,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    warranty_years numeric,
    performance_warranty_years numeric,
    performance_warranty_end_date date,
    warranty_years_requested numeric,
    warranty_request_status text DEFAULT 'none'::text NOT NULL,
    warranty_requested_by text,
    warranty_approved_by text,
    warranty_approved_at timestamp with time zone,
    warranty_number text,
    is_legacy boolean DEFAULT false NOT NULL,
    CONSTRAINT assets_warranty_request_status_check CHECK ((warranty_request_status = ANY (ARRAY['none'::text, 'pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor text NOT NULL,
    actor_role text NOT NULL,
    action_type text NOT NULL,
    entity_type text NOT NULL,
    entity_id bigint,
    entity_label text,
    old_value jsonb,
    new_value jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: catalog_category_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.catalog_category_map (
    catalog_category text NOT NULL,
    family text NOT NULL,
    sub_category text,
    requires_serial boolean DEFAULT false NOT NULL
);


--
-- Name: company_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_profile (
    id integer DEFAULT 1 NOT NULL,
    name_ar text NOT NULL,
    short_name_ar text,
    name_en text,
    vat_number text,
    cr_number text,
    commercial_reg text,
    national_address_code text,
    address jsonb DEFAULT '{}'::jsonb NOT NULL,
    phone text,
    whatsapp text,
    email text,
    website text,
    logo_url text,
    invoice_prefix text DEFAULT 'HEWDS'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT company_profile_id_check CHECK ((id = 1))
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    name text NOT NULL,
    "position" text,
    mobile text,
    whatsapp text,
    email text,
    preferred_contact_method text,
    decision_power text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: crm_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_interactions (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    rep_username text,
    interaction_type text DEFAULT 'call'::text NOT NULL,
    note text,
    outcome text,
    status_after text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.crm_interactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.crm_interactions_id_seq OWNED BY public.crm_interactions.id;


--
-- Name: crm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_settings (
    id integer DEFAULT 1 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT crm_settings_id_check CHECK ((id = 1))
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: einvoice_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.einvoice_config (
    id integer DEFAULT 1 NOT NULL,
    trial_mode boolean DEFAULT true NOT NULL,
    CONSTRAINT einvoice_config_id_check CHECK ((id = 1))
);


--
-- Name: einvoice_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.einvoice_counters (
    id integer DEFAULT 1 NOT NULL,
    last_icv bigint DEFAULT 0 NOT NULL,
    CONSTRAINT einvoice_counters_id_check CHECK ((id = 1))
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id bigint NOT NULL,
    expense_date date DEFAULT CURRENT_DATE NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    description text,
    amount numeric(14,2) NOT NULL,
    tax_treatment text DEFAULT 'recoverable'::text NOT NULL,
    recurring_id bigint,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT expenses_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT expenses_tax_treatment_check CHECK ((tax_treatment = ANY (ARRAY['recoverable'::text, 'none'::text])))
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.expenses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: finance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_settings (
    id integer DEFAULT 1 NOT NULL,
    vat_rate numeric DEFAULT 15 NOT NULL,
    reserve_pct numeric DEFAULT 0 NOT NULL,
    completed_statuses text[] DEFAULT ARRAY['commissioned'::text, 'completed'::text, 'handed_over'::text, 'closed'::text] NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT finance_settings_id_check CHECK ((id = 1)),
    CONSTRAINT finance_settings_reserve_pct_check CHECK (((reserve_pct >= (0)::numeric) AND (reserve_pct < (100)::numeric))),
    CONSTRAINT finance_settings_vat_rate_check CHECK (((vat_rate >= (0)::numeric) AND (vat_rate <= (100)::numeric)))
);


--
-- Name: invoice_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_counters (
    counter_key text NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: maintenance_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_contracts (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    project_id bigint,
    contract_number text,
    start_date date,
    end_date date,
    contract_value numeric,
    visits_per_year integer,
    next_visit_date date,
    responsible_engineer text,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_contracts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_contracts_id_seq OWNED BY public.maintenance_contracts.id;


--
-- Name: opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opportunities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opportunities_id_seq OWNED BY public.opportunities.id;


--
-- Name: partner_distributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partner_distributions (
    id bigint NOT NULL,
    partner_id bigint NOT NULL,
    amount numeric(14,2) NOT NULL,
    distribution_date date DEFAULT CURRENT_DATE NOT NULL,
    kind text DEFAULT 'profit'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT partner_distributions_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT partner_distributions_kind_check CHECK ((kind = ANY (ARRAY['profit'::text, 'draw'::text, 'advance'::text])))
);


--
-- Name: partner_distributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.partner_distributions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.partner_distributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: partner_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partner_shares (
    id bigint NOT NULL,
    partner_id bigint NOT NULL,
    share_pct numeric NOT NULL,
    effective_from date DEFAULT '2000-01-01'::date NOT NULL,
    effective_to date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT partner_shares_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT partner_shares_share_pct_check CHECK (((share_pct > (0)::numeric) AND (share_pct <= (100)::numeric)))
);


--
-- Name: partner_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.partner_shares ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.partner_shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partners (
    id bigint NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partners_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.partners ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.partners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_edits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_edits (
    id bigint NOT NULL,
    payment_id bigint NOT NULL,
    project_id bigint,
    old_amount numeric(14,2) NOT NULL,
    new_amount numeric(14,2) NOT NULL,
    old_date date NOT NULL,
    new_date date NOT NULL,
    reason text NOT NULL,
    edited_by text DEFAULT 'admin'::text NOT NULL,
    edited_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT payment_edits_new_amount_check CHECK ((new_amount > (0)::numeric)),
    CONSTRAINT payment_edits_reason_check CHECK ((length(btrim(reason)) > 0))
);


--
-- Name: payment_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.payment_edits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payment_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_milestones (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    title text NOT NULL,
    percentage numeric,
    amount numeric,
    due_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_milestones_id_seq OWNED BY public.payment_milestones.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    method text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    milestone_id bigint,
    auto_created boolean DEFAULT false NOT NULL
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pricing_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_config (
    id integer DEFAULT 1 NOT NULL,
    data jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: product_families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_families (
    prefix text NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    next_seq integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_families_prefix_check CHECK ((prefix ~ '^[A-Z]{3}$'::text))
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    product_code text NOT NULL,
    family text NOT NULL,
    category text,
    catalog_category text,
    catalog_name text,
    brand text,
    name_ar text NOT NULL,
    part_number text,
    warranty_years numeric,
    performance_warranty_years numeric,
    requires_serial boolean DEFAULT false NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    admin_notes jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supplier_discount_pct numeric,
    CONSTRAINT products_performance_warranty_years_check CHECK (((performance_warranty_years IS NULL) OR (performance_warranty_years >= (0)::numeric))),
    CONSTRAINT products_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text]))),
    CONSTRAINT products_supplier_discount_pct_check CHECK (((supplier_discount_pct IS NULL) OR ((supplier_discount_pct >= ('-100'::integer)::numeric) AND (supplier_discount_pct <= (100)::numeric)))),
    CONSTRAINT products_warranty_years_check CHECK (((warranty_years IS NULL) OR (warranty_years >= (0)::numeric)))
);


--
-- Name: COLUMN products.catalog_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.catalog_name IS 'Bridge: exact name used by compute-quote / invoice item code (productCatalog row[0] or PANEL-<brand>-<power>W).';


--
-- Name: COLUMN products.warranty_years; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.warranty_years IS 'NULL = fall back to crm_settings.standardWarranties by class; 0 = no warranty.';


--
-- Name: COLUMN products.admin_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.admin_notes IS 'Internal only. Never returned by public actions.';


--
-- Name: COLUMN products.supplier_discount_pct; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.supplier_discount_pct IS 'Internal only. Product-level importer discount (%). Overrides the (category, brand) supplierDiscountPct in pricing_config.discounts when set.';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: project_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_costs (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    cost_type text DEFAULT 'other'::text NOT NULL,
    description text,
    amount numeric DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    cost_date date,
    supplier text,
    tax_treatment text DEFAULT 'recoverable'::text NOT NULL,
    CONSTRAINT project_costs_tax_treatment_chk CHECK ((tax_treatment = ANY (ARRAY['recoverable'::text, 'none'::text])))
);


--
-- Name: project_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_costs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_costs_id_seq OWNED BY public.project_costs.id;


--
-- Name: project_discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_discounts (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    amount numeric(14,2) NOT NULL,
    contract_value_reduction numeric(14,2) NOT NULL,
    reason text NOT NULL,
    discount_date date DEFAULT CURRENT_DATE NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_discounts_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT project_discounts_reason_check CHECK ((length(btrim(reason)) > 0)),
    CONSTRAINT project_discounts_reduction_positive CHECK ((contract_value_reduction > (0)::numeric))
);


--
-- Name: project_discounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.project_discounts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_discounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_finance_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_finance_flags (
    project_id bigint NOT NULL,
    contract_includes_vat boolean DEFAULT true NOT NULL,
    completion_date date,
    notes text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    project_number text NOT NULL,
    contract_value numeric,
    scope_type text,
    contract_signed_date date,
    project_manager text,
    engineer text,
    planned_supply_date date,
    actual_supply_date date,
    planned_install_date date,
    actual_install_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id_system_type text,
    inverter_spec text,
    panel_spec text,
    structure_type text,
    payment_status text DEFAULT 'unpaid'::text NOT NULL
);


--
-- Name: COLUMN projects.payment_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.projects.payment_status IS 'unpaid | partial | paid — derived from payments vs contract_value by trigger';


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id bigint NOT NULL,
    po_number text,
    supplier_id bigint NOT NULL,
    project_id bigint,
    order_date date DEFAULT CURRENT_DATE NOT NULL,
    description text,
    amount numeric(14,2) NOT NULL,
    tax_treatment text DEFAULT 'recoverable'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    rfq_id bigint,
    CONSTRAINT purchase_orders_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT purchase_orders_status_check CHECK ((status = ANY (ARRAY['open'::text, 'cancelled'::text]))),
    CONSTRAINT purchase_orders_tax_treatment_check CHECK ((tax_treatment = ANY (ARRAY['recoverable'::text, 'none'::text])))
);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.purchase_orders ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    quotation_number text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    linked_quote_id bigint,
    valid_until date,
    sales_person text,
    engineer text,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    discount_total numeric DEFAULT 0 NOT NULL,
    vat_percent numeric DEFAULT 15 NOT NULL,
    subtotal numeric DEFAULT 0 NOT NULL,
    vat_amount numeric DEFAULT 0 NOT NULL,
    total numeric DEFAULT 0 NOT NULL,
    cost numeric,
    gross_profit numeric,
    gross_margin numeric,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ql_reference text,
    id_system_type text,
    pump_hp numeric,
    capacity_kw numeric,
    inverter_spec text,
    panel_spec text,
    structure_type text,
    scope_type text,
    segment text
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: quote_financials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_financials (
    quote_id bigint NOT NULL,
    financials jsonb NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE quote_financials; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.quote_financials IS 'Cost basis / margin snapshot at quote time. Service-role only (admin).';


--
-- Name: quote_ref_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_ref_counters (
    counter_key text NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id bigint NOT NULL,
    rep_username text,
    rep_display_name text,
    client_name text,
    client_phone text,
    hp numeric,
    final_total numeric,
    snapshot jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_id bigint,
    ref_code text,
    ql_code text,
    revision_no integer DEFAULT 0 NOT NULL,
    segment text
);


--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_expenses (
    id bigint NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    description text,
    amount numeric(14,2) NOT NULL,
    tax_treatment text DEFAULT 'recoverable'::text NOT NULL,
    start_month date DEFAULT (date_trunc('month'::text, (CURRENT_DATE)::timestamp without time zone))::date NOT NULL,
    end_month date,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recurring_expenses_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT recurring_expenses_tax_treatment_check CHECK ((tax_treatment = ANY (ARRAY['recoverable'::text, 'none'::text])))
);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.recurring_expenses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.recurring_expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reps (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_version integer DEFAULT 1 NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: reps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reps_id_seq OWNED BY public.reps.id;


--
-- Name: rfq_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_items (
    id bigint NOT NULL,
    rfq_id bigint NOT NULL,
    line_no integer NOT NULL,
    label text NOT NULL,
    qty numeric(14,3) NOT NULL,
    unit_price numeric(14,4),
    unit text,
    qty_note text,
    alloc jsonb,
    CONSTRAINT rfq_items_qty_check CHECK ((qty > (0)::numeric)),
    CONSTRAINT rfq_items_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


--
-- Name: rfq_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rfq_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rfq_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rfqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfqs (
    id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    quote_id bigint,
    quote_ref text,
    project_id bigint,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    supplier_quote_ref text,
    supplier_quote_date date,
    vat_mode text,
    valid_invoice boolean DEFAULT true NOT NULL,
    po_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    quoted_at timestamp with time zone,
    decided_at timestamp with time zone,
    lump_total numeric(14,2),
    is_multi boolean DEFAULT false NOT NULL,
    CONSTRAINT rfqs_lump_total_check CHECK (((lump_total IS NULL) OR (lump_total > (0)::numeric))),
    CONSTRAINT rfqs_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'sent'::text, 'quoted'::text, 'accepted'::text, 'rejected'::text, 'cancelled'::text]))),
    CONSTRAINT rfqs_vat_mode_check CHECK ((vat_mode = ANY (ARRAY['incl'::text, 'excl'::text, 'none'::text])))
);


--
-- Name: rfqs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rfqs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rfqs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: segment_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.segment_config (
    id integer DEFAULT 1 NOT NULL,
    small_max numeric DEFAULT 15 NOT NULL,
    medium_max numeric DEFAULT 250 NOT NULL,
    large_max numeric DEFAULT 800 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT segment_config_check CHECK (((small_max > (0)::numeric) AND (small_max < medium_max) AND (medium_max < large_max))),
    CONSTRAINT segment_config_id_check CHECK ((id = 1))
);


--
-- Name: service_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_tickets (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    asset_id bigint,
    project_id bigint,
    ticket_number text NOT NULL,
    issue_description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    assigned_engineer text,
    resolution_notes text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_tickets_id_seq OWNED BY public.service_tickets.id;


--
-- Name: site_surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_surveys (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    site_id bigint,
    customer_id bigint NOT NULL,
    engineer_name text,
    survey_date date,
    gps_lat double precision,
    gps_lng double precision,
    pump_type text,
    pump_manufacturer text,
    pump_model text,
    pump_hp text,
    pump_kw text,
    flow text,
    head text,
    well_depth text,
    static_water_level text,
    dynamic_water_level text,
    motor_manufacturer text,
    motor_model text,
    motor_hp text,
    motor_kw text,
    motor_voltage text,
    motor_current text,
    motor_frequency text,
    motor_rpm text,
    motor_power_factor text,
    motor_efficiency text,
    existing_diesel_generator text,
    generator_capacity text,
    diesel_consumption text,
    electricity_grid text,
    electricity_tariff text,
    existing_solar text,
    hours_per_day text,
    days_per_month text,
    seasonal_operation text,
    required_water_production text,
    available_area text,
    roof_or_ground text,
    shading text,
    orientation text,
    tilt text,
    soil text,
    access text,
    distance text,
    cable_length text,
    technical_notes text,
    photos jsonb DEFAULT '[]'::jsonb NOT NULL,
    documents jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_surveys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_surveys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_surveys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_surveys_id_seq OWNED BY public.site_surveys.id;


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: supplier_bill_edits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_bill_edits (
    id bigint NOT NULL,
    bill_id bigint NOT NULL,
    supplier_id bigint,
    old_values jsonb NOT NULL,
    new_values jsonb NOT NULL,
    reason text NOT NULL,
    edited_by text DEFAULT 'admin'::text NOT NULL,
    edited_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT supplier_bill_edits_reason_check CHECK ((length(btrim(reason)) > 0))
);


--
-- Name: supplier_bill_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.supplier_bill_edits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.supplier_bill_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: supplier_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_bills (
    id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    project_id bigint,
    bill_number text,
    bill_date date DEFAULT CURRENT_DATE NOT NULL,
    amount numeric(14,2) NOT NULL,
    tax_treatment text DEFAULT 'recoverable'::text NOT NULL,
    description text,
    project_cost_id bigint,
    expense_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    purchase_order_id bigint,
    doc_type text DEFAULT 'invoice'::text NOT NULL,
    bill_group uuid,
    CONSTRAINT supplier_bills_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT supplier_bills_doc_type_check CHECK ((doc_type = ANY (ARRAY['invoice'::text, 'credit_note'::text]))),
    CONSTRAINT supplier_bills_tax_treatment_check CHECK ((tax_treatment = ANY (ARRAY['recoverable'::text, 'none'::text])))
);


--
-- Name: supplier_bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.supplier_bills ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.supplier_bills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: supplier_payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_payment_allocations (
    id bigint NOT NULL,
    entry_id bigint NOT NULL,
    bill_id bigint NOT NULL,
    amount numeric(14,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT supplier_payment_allocations_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: supplier_payment_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.supplier_payment_allocations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.supplier_payment_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id bigint NOT NULL,
    name text NOT NULL,
    vat_number text,
    phone text,
    notes text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: technical_studies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technical_studies (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    site_survey_id bigint,
    quote_id bigint,
    pv_capacity text,
    number_of_panels text,
    panel_model text,
    panel_wattage text,
    inverter text,
    inverter_capacity text,
    pump text,
    vfd text,
    structure text,
    dc_cables text,
    ac_cables text,
    protection text,
    combiner_boxes text,
    monitoring text,
    expected_production text,
    expected_operating_hours text,
    estimated_diesel_saving text,
    estimated_electricity_saving text,
    capex numeric,
    opex numeric,
    estimated_roi text,
    payback_period text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: technical_studies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.technical_studies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: technical_studies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.technical_studies_id_seq OWNED BY public.technical_studies.id;


--
-- Name: treasury_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_accounts (
    id bigint NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    holder text,
    opening_balance numeric(14,2) DEFAULT 0 NOT NULL,
    opening_date date DEFAULT CURRENT_DATE NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT treasury_accounts_kind_check CHECK ((kind = ANY (ARRAY['cash'::text, 'bank'::text, 'custody'::text])))
);


--
-- Name: treasury_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.treasury_accounts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.treasury_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: treasury_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_entries (
    id bigint NOT NULL,
    entry_date date DEFAULT CURRENT_DATE NOT NULL,
    account_id bigint NOT NULL,
    direction text NOT NULL,
    amount numeric(14,2) NOT NULL,
    kind text NOT NULL,
    method text,
    reference text,
    notes text,
    project_id bigint,
    supplier_id bigint,
    bill_id bigint,
    payment_id bigint,
    expense_id bigint,
    distribution_id bigint,
    transfer_group uuid,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_cost_id bigint,
    purchase_order_id bigint,
    payment_group uuid,
    CONSTRAINT treasury_entries_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT treasury_entries_direction_check CHECK ((direction = ANY (ARRAY['in'::text, 'out'::text]))),
    CONSTRAINT treasury_entries_kind_check CHECK ((kind = ANY (ARRAY['customer_receipt'::text, 'supplier_payment'::text, 'supplier_refund'::text, 'expense'::text, 'partner_draw'::text, 'transfer'::text, 'other'::text])))
);


--
-- Name: treasury_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.treasury_entries ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.treasury_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: treasury_entry_edits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_entry_edits (
    id bigint NOT NULL,
    entry_id bigint NOT NULL,
    kind text,
    old_values jsonb NOT NULL,
    new_values jsonb NOT NULL,
    reason text NOT NULL,
    edited_by text DEFAULT 'admin'::text NOT NULL,
    edited_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: treasury_entry_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.treasury_entry_edits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.treasury_entry_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_account_balances; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_account_balances AS
SELECT
    NULL::bigint AS account_id,
    NULL::text AS name,
    NULL::text AS kind,
    NULL::text AS holder,
    NULL::boolean AS active,
    NULL::numeric(14,2) AS opening_balance,
    NULL::date AS opening_date,
    NULL::numeric AS total_in,
    NULL::numeric AS total_out,
    NULL::numeric AS balance;


--
-- Name: v_monthly_expenses; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_monthly_expenses WITH (security_invoker='true') AS
 WITH s AS (
         SELECT (finance_settings.vat_rate / 100.0) AS vr
           FROM public.finance_settings
          WHERE (finance_settings.id = 1)
        )
 SELECT (date_trunc('month'::text, (e.expense_date)::timestamp without time zone))::date AS month,
    e.category,
    round(sum(e.amount), 2) AS gross,
    round(sum(
        CASE
            WHEN (e.tax_treatment = 'recoverable'::text) THEN (e.amount / ((1)::numeric + s.vr))
            ELSE e.amount
        END), 2) AS net,
    round(sum(
        CASE
            WHEN (e.tax_treatment = 'recoverable'::text) THEN (e.amount - (e.amount / ((1)::numeric + s.vr)))
            ELSE (0)::numeric
        END), 2) AS input_vat
   FROM (public.expenses e
     CROSS JOIN s)
  GROUP BY ((date_trunc('month'::text, (e.expense_date)::timestamp without time zone))::date), e.category;


--
-- Name: v_project_profit; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_project_profit WITH (security_invoker='true') AS
 WITH s AS (
         SELECT (finance_settings.vat_rate / 100.0) AS vr,
            finance_settings.completed_statuses
           FROM public.finance_settings
          WHERE (finance_settings.id = 1)
        ), c AS (
         SELECT pc.project_id,
            sum(pc.amount) AS cost_gross,
            sum(
                CASE
                    WHEN (pc.tax_treatment = 'recoverable'::text) THEN (pc.amount - (pc.amount / ((1)::numeric + ( SELECT s.vr
                       FROM s))))
                    ELSE (0)::numeric
                END) AS input_vat
           FROM public.project_costs pc
          GROUP BY pc.project_id
        ), p AS (
         SELECT payments.project_id,
            sum(payments.amount) AS collected
           FROM public.payments
          GROUP BY payments.project_id
        ), base AS (
         SELECT pr.id AS project_id,
            pr.project_number,
            pr.customer_id,
            cu.name AS customer_name,
            pr.status,
            pr.contract_value,
            (pr.status = ANY (s.completed_statuses)) AS is_completed,
            COALESCE(f.completion_date, pr.actual_install_date, (pr.updated_at)::date) AS completion_date,
            COALESCE(f.contract_includes_vat, true) AS contract_includes_vat,
            COALESCE(pr.contract_value, (0)::numeric) AS cv,
            COALESCE(c.cost_gross, (0)::numeric) AS cost_gross,
            COALESCE(c.input_vat, (0)::numeric) AS input_vat,
            COALESCE(p.collected, (0)::numeric) AS collected,
            s.vr
           FROM (((((public.projects pr
             CROSS JOIN s)
             LEFT JOIN public.customers cu ON ((cu.id = pr.customer_id)))
             LEFT JOIN public.project_finance_flags f ON ((f.project_id = pr.id)))
             LEFT JOIN c ON ((c.project_id = pr.id)))
             LEFT JOIN p ON ((p.project_id = pr.id)))
        ), calc AS (
         SELECT base.project_id,
            base.project_number,
            base.customer_id,
            base.customer_name,
            base.status,
            base.contract_value,
            base.is_completed,
            base.completion_date,
            base.contract_includes_vat,
            base.cv,
            base.cost_gross,
            base.input_vat,
            base.collected,
            base.vr,
                CASE
                    WHEN base.contract_includes_vat THEN (base.cv / ((1)::numeric + base.vr))
                    ELSE base.cv
                END AS contract_net,
                CASE
                    WHEN base.contract_includes_vat THEN base.cv
                    ELSE (base.cv * ((1)::numeric + base.vr))
                END AS contract_gross
           FROM base
        )
 SELECT project_id,
    project_number,
    customer_id,
    customer_name,
    status,
    is_completed,
    completion_date,
    contract_includes_vat,
    round(contract_gross, 2) AS contract_gross,
    round(contract_net, 2) AS contract_net,
    round((contract_gross - contract_net), 2) AS output_vat,
    round(cost_gross, 2) AS cost_gross,
    round(input_vat, 2) AS input_vat,
    round((cost_gross - input_vat), 2) AS cost_net,
    round((contract_net - (cost_gross - input_vat)), 2) AS actual_profit,
        CASE
            WHEN (contract_net > (0)::numeric) THEN round((((contract_net - (cost_gross - input_vat)) / contract_net) * (100)::numeric), 1)
            ELSE NULL::numeric
        END AS margin_pct,
    round(collected, 2) AS collected,
    round((contract_gross - collected), 2) AS remaining
   FROM calc;


--
-- Name: v_monthly_pnl; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_monthly_pnl WITH (security_invoker='true') AS
 WITH months AS (
         SELECT (generate_series(date_trunc('month'::text, (LEAST(COALESCE(( SELECT min(v_project_profit.completion_date) AS min
                   FROM public.v_project_profit
                  WHERE v_project_profit.is_completed), CURRENT_DATE), COALESCE(( SELECT min(expenses.expense_date) AS min
                   FROM public.expenses), CURRENT_DATE), CURRENT_DATE))::timestamp without time zone), date_trunc('month'::text, (CURRENT_DATE)::timestamp without time zone), '1 mon'::interval))::date AS month
        ), proj AS (
         SELECT (date_trunc('month'::text, (v_project_profit.completion_date)::timestamp without time zone))::date AS month,
            count(*) AS projects_completed,
            sum(v_project_profit.contract_net) AS revenue_net,
            sum(v_project_profit.cost_net) AS project_costs_net,
            sum(v_project_profit.actual_profit) AS project_profit
           FROM public.v_project_profit
          WHERE v_project_profit.is_completed
          GROUP BY ((date_trunc('month'::text, (v_project_profit.completion_date)::timestamp without time zone))::date)
        ), exp AS (
         SELECT v_monthly_expenses.month,
            sum(v_monthly_expenses.net) AS expenses_net
           FROM public.v_monthly_expenses
          GROUP BY v_monthly_expenses.month
        )
 SELECT m.month,
    COALESCE(proj.projects_completed, (0)::bigint) AS projects_completed,
    round(COALESCE(proj.revenue_net, (0)::numeric), 2) AS revenue_net,
    round(COALESCE(proj.project_costs_net, (0)::numeric), 2) AS project_costs_net,
    round(COALESCE(proj.project_profit, (0)::numeric), 2) AS project_profit,
    round(COALESCE(exp.expenses_net, (0)::numeric), 2) AS expenses_net,
    round((COALESCE(proj.project_profit, (0)::numeric) - COALESCE(exp.expenses_net, (0)::numeric)), 2) AS net_profit
   FROM ((months m
     LEFT JOIN proj ON ((proj.month = m.month)))
     LEFT JOIN exp ON ((exp.month = m.month)));


--
-- Name: v_partner_monthly; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_partner_monthly WITH (security_invoker='true') AS
 SELECT pn.month,
    pt.id AS partner_id,
    pt.name AS partner_name,
    ps.share_pct,
    pn.net_profit,
    round((((pn.net_profit * ((1)::numeric - (fs.reserve_pct / 100.0))) * ps.share_pct) / 100.0), 2) AS share_amount
   FROM (((public.v_monthly_pnl pn
     CROSS JOIN ( SELECT finance_settings.reserve_pct
           FROM public.finance_settings
          WHERE (finance_settings.id = 1)) fs)
     JOIN public.partner_shares ps ON (((ps.effective_from <= (((pn.month + '1 mon'::interval))::date - 1)) AND ((ps.effective_to IS NULL) OR (ps.effective_to >= pn.month)))))
     JOIN public.partners pt ON (((pt.id = ps.partner_id) AND pt.active)));


--
-- Name: v_partner_balance; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_partner_balance WITH (security_invoker='true') AS
 SELECT pt.id AS partner_id,
    pt.name AS partner_name,
    COALESCE(e.earned, (0)::numeric) AS earned,
    COALESCE(d.distributed, (0)::numeric) AS distributed,
    (COALESCE(e.earned, (0)::numeric) - COALESCE(d.distributed, (0)::numeric)) AS balance
   FROM ((public.partners pt
     LEFT JOIN ( SELECT v_partner_monthly.partner_id,
            sum(v_partner_monthly.share_amount) AS earned
           FROM public.v_partner_monthly
          GROUP BY v_partner_monthly.partner_id) e ON ((e.partner_id = pt.id)))
     LEFT JOIN ( SELECT partner_distributions.partner_id,
            sum(partner_distributions.amount) AS distributed
           FROM public.partner_distributions
          GROUP BY partner_distributions.partner_id) d ON ((d.partner_id = pt.id)))
  WHERE pt.active;


--
-- Name: v_purchase_orders; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_purchase_orders WITH (security_invoker='true') AS
 SELECT po.id AS po_id,
    COALESCE(po.po_number, ('PO-'::text || lpad((po.id)::text, 4, '0'::text))) AS po_number,
    po.supplier_id,
    s.name AS supplier_name,
    po.project_id,
    pr.project_number,
    po.order_date,
    po.description,
    po.amount,
    po.tax_treatment,
    po.status,
    po.notes,
    COALESCE(b.billed, (0)::numeric) AS billed,
    COALESCE(p.paid, (0)::numeric) AS paid,
    (po.amount - COALESCE(b.billed, (0)::numeric)) AS remaining_to_bill,
    GREATEST((COALESCE(b.billed, (0)::numeric) - COALESCE(p.paid, (0)::numeric)), (0)::numeric) AS remaining_to_pay,
    GREATEST((COALESCE(p.paid, (0)::numeric) - COALESCE(b.billed, (0)::numeric)), (0)::numeric) AS advance_unbilled,
    (GREATEST(po.amount, COALESCE(b.billed, (0)::numeric)) - COALESCE(p.paid, (0)::numeric)) AS remaining_total
   FROM ((((public.purchase_orders po
     JOIN public.suppliers s ON ((s.id = po.supplier_id)))
     LEFT JOIN public.projects pr ON ((pr.id = po.project_id)))
     LEFT JOIN ( SELECT supplier_bills.purchase_order_id,
            sum(
                CASE
                    WHEN (supplier_bills.doc_type = 'invoice'::text) THEN supplier_bills.amount
                    ELSE (- supplier_bills.amount)
                END) AS billed
           FROM public.supplier_bills
          WHERE (supplier_bills.purchase_order_id IS NOT NULL)
          GROUP BY supplier_bills.purchase_order_id) b ON ((b.purchase_order_id = po.id)))
     LEFT JOIN ( SELECT x.po_id,
            sum(x.amount) AS paid
           FROM ( SELECT e.purchase_order_id AS po_id,
                    e.amount
                   FROM public.treasury_entries e
                  WHERE ((e.kind = 'supplier_payment'::text) AND (e.purchase_order_id IS NOT NULL))
                UNION ALL
                 SELECT sb.purchase_order_id,
                    e.amount
                   FROM (public.treasury_entries e
                     JOIN public.supplier_bills sb ON ((sb.id = e.bill_id)))
                  WHERE ((e.kind = 'supplier_payment'::text) AND (e.purchase_order_id IS NULL) AND (sb.purchase_order_id IS NOT NULL))
                UNION ALL
                 SELECT sb.purchase_order_id,
                    a.amount
                   FROM ((public.supplier_payment_allocations a
                     JOIN public.supplier_bills sb ON ((sb.id = a.bill_id)))
                     JOIN public.treasury_entries e ON ((e.id = a.entry_id)))
                  WHERE ((sb.purchase_order_id IS NOT NULL) AND (e.purchase_order_id IS DISTINCT FROM sb.purchase_order_id))) x
          GROUP BY x.po_id) p ON ((p.po_id = po.id)));


--
-- Name: v_rfqs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_rfqs WITH (security_invoker='true') AS
 SELECT r.id AS rfq_id,
    ('RFQ-'::text || lpad((r.id)::text, 4, '0'::text)) AS rfq_number,
    r.supplier_id,
    s.name AS supplier_name,
    s.phone AS supplier_phone,
    r.quote_id,
    r.quote_ref,
    r.project_id,
    pr.project_number,
    r.status,
    r.notes,
    r.supplier_quote_ref,
    r.supplier_quote_date,
    r.vat_mode,
    r.valid_invoice,
    r.po_id,
    r.created_at,
    r.sent_at,
    r.quoted_at,
    r.decided_at,
    ( SELECT count(*) AS count
           FROM public.rfq_items i
          WHERE (i.rfq_id = r.id)) AS items_count,
    COALESCE(r.lump_total, n.net_total) AS net_total,
        CASE
            WHEN (COALESCE(r.lump_total, n.net_total) IS NULL) THEN NULL::numeric
            WHEN (r.vat_mode = 'excl'::text) THEN round((COALESCE(r.lump_total, n.net_total) * ((1)::numeric + fs.vr)), 2)
            ELSE round(COALESCE(r.lump_total, n.net_total), 2)
        END AS total_gross,
    COALESCE(n.priced_count, (0)::bigint) AS priced_count,
    r.lump_total,
    r.is_multi
   FROM ((((public.rfqs r
     JOIN public.suppliers s ON ((s.id = r.supplier_id)))
     LEFT JOIN public.projects pr ON ((pr.id = r.project_id)))
     CROSS JOIN ( SELECT (finance_settings.vat_rate / 100.0) AS vr
           FROM public.finance_settings
          WHERE (finance_settings.id = 1)) fs)
     LEFT JOIN ( SELECT rfq_items.rfq_id,
            sum((rfq_items.qty * rfq_items.unit_price)) AS net_total,
            count(*) AS priced_count
           FROM public.rfq_items
          WHERE (rfq_items.unit_price IS NOT NULL)
          GROUP BY rfq_items.rfq_id) n ON ((n.rfq_id = r.id)));


--
-- Name: v_segment_report; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_segment_report WITH (security_invoker='true') AS
 SELECT COALESCE(q.segment, 'unclassified'::text) AS segment,
    count(*) AS quotes_count,
    count(DISTINCT q.customer_id) AS customers_count,
    round(avg(q.final_total)) AS avg_quote_value,
    round(sum(q.final_total)) AS total_quoted_value,
    round(avg((q.final_total / NULLIF(q.hp, (0)::numeric)))) AS avg_price_per_hp,
    count(DISTINCT q.customer_id) FILTER (WHERE (c.status = 'won'::text)) AS won_customers,
    count(DISTINCT q.customer_id) FILTER (WHERE (c.status = 'lost'::text)) AS lost_customers,
    count(DISTINCT q.customer_id) FILTER (WHERE (c.status = 'negotiating'::text)) AS negotiating_customers,
    round(((100.0 * (count(DISTINCT q.customer_id) FILTER (WHERE (c.status = 'won'::text)))::numeric) / (NULLIF(count(DISTINCT q.customer_id), 0))::numeric), 1) AS win_rate_pct
   FROM (public.quotes q
     LEFT JOIN public.customers c ON ((c.id = q.customer_id)))
  GROUP BY COALESCE(q.segment, 'unclassified'::text)
  ORDER BY (array_position(ARRAY['small'::text, 'medium'::text, 'large'::text, 'mega'::text, 'unclassified'::text], COALESCE(q.segment, 'unclassified'::text)));


--
-- Name: v_supplier_balances; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_supplier_balances WITH (security_invoker='true') AS
 SELECT s.id AS supplier_id,
    s.name,
    s.vat_number,
    s.phone,
    s.active,
    (COALESCE(b.inv, (0)::numeric) - COALESCE(b.cn, (0)::numeric)) AS total_bills,
    (COALESCE(p.paid, (0)::numeric) - COALESCE(p.refund, (0)::numeric)) AS total_paid,
    ((COALESCE(b.inv, (0)::numeric) - COALESCE(b.cn, (0)::numeric)) - (COALESCE(p.paid, (0)::numeric) - COALESCE(p.refund, (0)::numeric))) AS balance,
    GREATEST((0)::numeric, ((COALESCE(p.adv, (0)::numeric) - COALESCE(al.alloc, (0)::numeric)) - COALESCE(p.refund, (0)::numeric))) AS advance_open,
    COALESCE(b.cn, (0)::numeric) AS credit_notes,
    COALESCE(p.refund, (0)::numeric) AS refunds
   FROM (((public.suppliers s
     LEFT JOIN ( SELECT supplier_bills.supplier_id,
            sum(supplier_bills.amount) FILTER (WHERE (supplier_bills.doc_type = 'invoice'::text)) AS inv,
            sum(supplier_bills.amount) FILTER (WHERE (supplier_bills.doc_type = 'credit_note'::text)) AS cn
           FROM public.supplier_bills
          GROUP BY supplier_bills.supplier_id) b ON ((b.supplier_id = s.id)))
     LEFT JOIN ( SELECT treasury_entries.supplier_id,
            sum(treasury_entries.amount) FILTER (WHERE (treasury_entries.kind = 'supplier_payment'::text)) AS paid,
            sum(treasury_entries.amount) FILTER (WHERE ((treasury_entries.kind = 'supplier_payment'::text) AND (treasury_entries.bill_id IS NULL))) AS adv,
            sum(treasury_entries.amount) FILTER (WHERE (treasury_entries.kind = 'supplier_refund'::text)) AS refund
           FROM public.treasury_entries
          WHERE (treasury_entries.kind = ANY (ARRAY['supplier_payment'::text, 'supplier_refund'::text]))
          GROUP BY treasury_entries.supplier_id) p ON ((p.supplier_id = s.id)))
     LEFT JOIN ( SELECT e.supplier_id,
            sum(a.amount) AS alloc
           FROM (public.supplier_payment_allocations a
             JOIN public.treasury_entries e ON ((e.id = a.entry_id)))
          GROUP BY e.supplier_id) al ON ((al.supplier_id = s.id)));


--
-- Name: v_supplier_bills; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_supplier_bills WITH (security_invoker='true') AS
 SELECT b.id AS bill_id,
    b.supplier_id,
    s.name AS supplier_name,
    b.project_id,
    pr.project_number,
    b.bill_number,
    b.bill_date,
    b.description,
    b.amount,
    b.tax_treatment,
    (COALESCE(d.paid, (0)::numeric) + COALESCE(a.alloc, (0)::numeric)) AS paid,
    ((b.amount - COALESCE(d.paid, (0)::numeric)) - COALESCE(a.alloc, (0)::numeric)) AS remaining,
    b.purchase_order_id,
    COALESCE(a.alloc, (0)::numeric) AS advance_applied
   FROM ((((public.supplier_bills b
     JOIN public.suppliers s ON ((s.id = b.supplier_id)))
     LEFT JOIN public.projects pr ON ((pr.id = b.project_id)))
     LEFT JOIN ( SELECT treasury_entries.bill_id,
            sum(treasury_entries.amount) AS paid
           FROM public.treasury_entries
          WHERE ((treasury_entries.kind = 'supplier_payment'::text) AND (treasury_entries.bill_id IS NOT NULL))
          GROUP BY treasury_entries.bill_id) d ON ((d.bill_id = b.id)))
     LEFT JOIN ( SELECT supplier_payment_allocations.bill_id,
            sum(supplier_payment_allocations.amount) AS alloc
           FROM public.supplier_payment_allocations
          GROUP BY supplier_payment_allocations.bill_id) a ON ((a.bill_id = b.id)))
  WHERE (b.doc_type = 'invoice'::text);


--
-- Name: v_supplier_project_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_supplier_project_summary WITH (security_invoker='true') AS
 WITH c AS (
         SELECT b.supplier_id,
            b.project_id,
                CASE
                    WHEN (b.doc_type = 'invoice'::text) THEN b.amount
                    ELSE (- b.amount)
                END AS inv,
            (0)::numeric AS paid
           FROM public.supplier_bills b
        UNION ALL
         SELECT e.supplier_id,
            e.project_id,
            0,
                CASE
                    WHEN (e.kind = 'supplier_payment'::text) THEN e.amount
                    ELSE (- e.amount)
                END AS "case"
           FROM public.treasury_entries e
          WHERE ((e.kind = ANY (ARRAY['supplier_payment'::text, 'supplier_refund'::text])) AND (e.project_id IS NOT NULL) AND (e.supplier_id IS NOT NULL))
        UNION ALL
         SELECT e.supplier_id,
            b.project_id,
            0,
            e.amount
           FROM (public.treasury_entries e
             JOIN public.supplier_bills b ON ((b.id = e.bill_id)))
          WHERE ((e.kind = 'supplier_payment'::text) AND (e.project_id IS NULL))
        UNION ALL
         SELECT e.supplier_id,
            b.project_id,
            0,
            a.amount
           FROM ((public.supplier_payment_allocations a
             JOIN public.treasury_entries e ON ((e.id = a.entry_id)))
             JOIN public.supplier_bills b ON ((b.id = a.bill_id)))
          WHERE (e.project_id IS NULL)
        UNION ALL
         SELECT e.supplier_id,
            NULL::bigint AS int8,
            0,
            (e.amount - COALESCE(( SELECT sum(a.amount) AS sum
                   FROM public.supplier_payment_allocations a
                  WHERE (a.entry_id = e.id)), (0)::numeric))
           FROM public.treasury_entries e
          WHERE ((e.kind = 'supplier_payment'::text) AND (e.project_id IS NULL) AND (e.bill_id IS NULL) AND (e.supplier_id IS NOT NULL))
        UNION ALL
         SELECT e.supplier_id,
            NULL::bigint AS int8,
            0,
            (- e.amount)
           FROM public.treasury_entries e
          WHERE ((e.kind = 'supplier_refund'::text) AND (e.project_id IS NULL) AND (e.supplier_id IS NOT NULL))
        )
 SELECT c.supplier_id,
    c.project_id,
    pr.project_number,
    sum(c.inv) AS invoiced,
    sum(c.paid) AS paid,
    (sum(c.inv) - sum(c.paid)) AS balance
   FROM (c
     LEFT JOIN public.projects pr ON ((pr.id = c.project_id)))
  GROUP BY c.supplier_id, c.project_id, pr.project_number
 HAVING ((abs(sum(c.inv)) > 0.004) OR (abs(sum(c.paid)) > 0.004));


--
-- Name: v_supplier_statement; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_supplier_statement WITH (security_invoker='true') AS
 WITH r AS (
         SELECT b.supplier_id,
            b.bill_date AS doc_date,
                CASE
                    WHEN (b.doc_type = 'invoice'::text) THEN 1
                    ELSE 2
                END AS ord,
            b.doc_type AS doc_kind,
            b.id AS doc_id,
            COALESCE(b.bill_number, ('#'::text || b.id)) AS ref,
            b.description AS notes,
            b.project_id,
            b.purchase_order_id AS po_id,
            NULL::bigint AS account_id,
            NULL::bigint AS bill_id,
            b.amount,
                CASE
                    WHEN (b.doc_type = 'invoice'::text) THEN b.amount
                    ELSE (- b.amount)
                END AS effect
           FROM public.supplier_bills b
        UNION ALL
         SELECT e.supplier_id,
            e.entry_date,
                CASE
                    WHEN (e.kind = 'supplier_payment'::text) THEN 3
                    ELSE 4
                END AS "case",
            e.kind,
            e.id,
            e.reference,
            e.notes,
            e.project_id,
            e.purchase_order_id,
            e.account_id,
            e.bill_id,
            e.amount,
                CASE
                    WHEN (e.kind = 'supplier_payment'::text) THEN (- e.amount)
                    ELSE e.amount
                END AS amount
           FROM public.treasury_entries e
          WHERE ((e.kind = ANY (ARRAY['supplier_payment'::text, 'supplier_refund'::text])) AND (e.supplier_id IS NOT NULL))
        )
 SELECT r.supplier_id,
    r.doc_date,
    r.ord,
    r.doc_kind,
    r.doc_id,
    r.ref,
    r.notes,
    r.project_id,
    pr.project_number,
    r.po_id,
        CASE
            WHEN (r.po_id IS NULL) THEN NULL::text
            ELSE COALESCE(po.po_number, ('PO-'::text || lpad((po.id)::text, 4, '0'::text)))
        END AS po_number,
    r.account_id,
    ac.name AS account_name,
    r.bill_id,
    r.amount,
    r.effect,
        CASE
            WHEN (r.doc_kind = 'supplier_payment'::text) THEN
            CASE
                WHEN (r.bill_id IS NOT NULL) THEN r.amount
                ELSE COALESCE(( SELECT sum(a.amount) AS sum
                   FROM public.supplier_payment_allocations a
                  WHERE (a.entry_id = r.doc_id)), (0)::numeric)
            END
            ELSE NULL::numeric
        END AS applied,
        CASE
            WHEN (r.doc_kind = 'invoice'::text) THEN ( SELECT vb.paid
               FROM public.v_supplier_bills vb
              WHERE (vb.bill_id = r.doc_id))
            ELSE NULL::numeric
        END AS bill_paid,
    sum(r.effect) OVER (PARTITION BY r.supplier_id ORDER BY r.doc_date, r.ord, r.doc_id) AS running_balance
   FROM (((r
     LEFT JOIN public.projects pr ON ((pr.id = r.project_id)))
     LEFT JOIN public.purchase_orders po ON ((po.id = r.po_id)))
     LEFT JOIN public.treasury_accounts ac ON ((ac.id = r.account_id)));


--
-- Name: v_treasury_ledger; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_treasury_ledger WITH (security_invoker='true') AS
 SELECT e.id,
    e.entry_date,
    e.account_id,
    a.name AS account_name,
    a.kind AS account_kind,
    e.direction,
    e.amount,
    e.kind,
    e.method,
    e.reference,
    e.notes,
    e.project_id,
    pr.project_number,
    cu.name AS customer_name,
    e.supplier_id,
    s.name AS supplier_name,
    e.bill_id,
    e.transfer_group,
    e.created_at,
    (a.opening_balance + sum(
        CASE
            WHEN (e.direction = 'in'::text) THEN e.amount
            ELSE (- e.amount)
        END) OVER (PARTITION BY e.account_id ORDER BY e.entry_date, e.id)) AS running_balance,
    e.payment_group
   FROM ((((public.treasury_entries e
     JOIN public.treasury_accounts a ON ((a.id = e.account_id)))
     LEFT JOIN public.projects pr ON ((pr.id = e.project_id)))
     LEFT JOIN public.customers cu ON ((cu.id = pr.customer_id)))
     LEFT JOIN public.suppliers s ON ((s.id = e.supplier_id)))
  WHERE (e.entry_date >= a.opening_date);


--
-- Name: v_unassigned_receipts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_unassigned_receipts WITH (security_invoker='true') AS
 SELECT p.id AS payment_id,
    p.project_id,
    pr.project_number,
    cu.name AS customer_name,
    p.amount,
    p.payment_date,
    p.method,
    p.notes
   FROM ((public.payments p
     LEFT JOIN public.projects pr ON ((pr.id = p.project_id)))
     LEFT JOIN public.customers cu ON ((cu.id = pr.customer_id)))
  WHERE (NOT (EXISTS ( SELECT 1
           FROM public.treasury_entries e
          WHERE (e.payment_id = p.id))));


--
-- Name: v_vat_monthly; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_vat_monthly WITH (security_invoker='true') AS
 WITH s AS (
         SELECT (finance_settings.vat_rate / 100.0) AS vr
           FROM public.finance_settings
          WHERE (finance_settings.id = 1)
        ), outv AS (
         SELECT (date_trunc('month'::text, (p.payment_date)::timestamp without time zone))::date AS month,
            sum((p.amount - (p.amount / ((1)::numeric + s.vr)))) AS output_vat
           FROM (public.payments p
             CROSS JOIN s)
          GROUP BY ((date_trunc('month'::text, (p.payment_date)::timestamp without time zone))::date)
        ), inv_proj AS (
         SELECT (date_trunc('month'::text, (COALESCE(pc.cost_date, (pc.created_at)::date))::timestamp without time zone))::date AS month,
            sum((pc.amount - (pc.amount / ((1)::numeric + s.vr)))) AS input_vat
           FROM (public.project_costs pc
             CROSS JOIN s)
          WHERE (pc.tax_treatment = 'recoverable'::text)
          GROUP BY ((date_trunc('month'::text, (COALESCE(pc.cost_date, (pc.created_at)::date))::timestamp without time zone))::date)
        ), inv_exp AS (
         SELECT v_monthly_expenses.month,
            sum(v_monthly_expenses.input_vat) AS input_vat
           FROM public.v_monthly_expenses
          GROUP BY v_monthly_expenses.month
        ), months AS (
         SELECT outv.month
           FROM outv
        UNION
         SELECT inv_proj.month
           FROM inv_proj
        UNION
         SELECT inv_exp.month
           FROM inv_exp
        )
 SELECT m.month,
    round(COALESCE(o.output_vat, (0)::numeric), 2) AS output_vat,
    round((COALESCE(ip.input_vat, (0)::numeric) + COALESCE(ie.input_vat, (0)::numeric)), 2) AS input_vat,
    round(((COALESCE(o.output_vat, (0)::numeric) - COALESCE(ip.input_vat, (0)::numeric)) - COALESCE(ie.input_vat, (0)::numeric)), 2) AS net_vat_due
   FROM (((months m
     LEFT JOIN outv o ON ((o.month = m.month)))
     LEFT JOIN inv_proj ip ON ((ip.month = m.month)))
     LEFT JOIN inv_exp ie ON ((ie.month = m.month)));


--
-- Name: warranty_category_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_category_map (
    category text NOT NULL,
    warranty_class text NOT NULL,
    requires_serial boolean DEFAULT true NOT NULL
);


--
-- Name: warranty_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_certificates (
    id bigint NOT NULL,
    certificate_number text NOT NULL,
    invoice_id bigint NOT NULL,
    line_index integer NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    customer_id bigint NOT NULL,
    asset_id bigint,
    serial_normalized text,
    warranty_start date NOT NULL,
    warranty_end date NOT NULL,
    snapshot jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    voided_at timestamp with time zone,
    void_reason text,
    issued_by text NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT warranty_certificates_check CHECK ((warranty_end >= warranty_start)),
    CONSTRAINT warranty_certificates_line_index_check CHECK ((line_index >= 0)),
    CONSTRAINT warranty_certificates_status_check CHECK ((status = ANY (ARRAY['active'::text, 'void'::text])))
);


--
-- Name: warranty_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.warranty_certificates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.warranty_certificates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: warranty_print_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_print_log (
    id bigint NOT NULL,
    certificate_id bigint NOT NULL,
    printed_by text NOT NULL,
    printed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: warranty_print_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.warranty_print_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.warranty_print_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: warranty_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_rules (
    id bigint NOT NULL,
    catalog_category text NOT NULL,
    brand text NOT NULL,
    warranty_years numeric,
    performance_warranty_years numeric,
    notes text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT warranty_rules_check CHECK (((warranty_years IS NOT NULL) OR (performance_warranty_years IS NOT NULL))),
    CONSTRAINT warranty_rules_performance_warranty_years_check CHECK (((performance_warranty_years IS NULL) OR (performance_warranty_years >= (0)::numeric))),
    CONSTRAINT warranty_rules_warranty_years_check CHECK (((warranty_years IS NULL) OR (warranty_years >= (0)::numeric)))
);


--
-- Name: TABLE warranty_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.warranty_rules IS 'Brand-within-category warranty set by the admin. 0 = explicitly no warranty. Resolution: product override > rule > class default (crm_settings.standardWarranties).';


--
-- Name: warranty_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warranty_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warranty_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warranty_rules_id_seq OWNED BY public.warranty_rules.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: crm_interactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions ALTER COLUMN id SET DEFAULT nextval('public.crm_interactions_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: maintenance_contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts ALTER COLUMN id SET DEFAULT nextval('public.maintenance_contracts_id_seq'::regclass);


--
-- Name: opportunities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities ALTER COLUMN id SET DEFAULT nextval('public.opportunities_id_seq'::regclass);


--
-- Name: payment_milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones ALTER COLUMN id SET DEFAULT nextval('public.payment_milestones_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: project_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs ALTER COLUMN id SET DEFAULT nextval('public.project_costs_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: reps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps ALTER COLUMN id SET DEFAULT nextval('public.reps_id_seq'::regclass);


--
-- Name: service_tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets ALTER COLUMN id SET DEFAULT nextval('public.service_tickets_id_seq'::regclass);


--
-- Name: site_surveys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys ALTER COLUMN id SET DEFAULT nextval('public.site_surveys_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: technical_studies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies ALTER COLUMN id SET DEFAULT nextval('public.technical_studies_id_seq'::regclass);


--
-- Name: warranty_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_rules ALTER COLUMN id SET DEFAULT nextval('public.warranty_rules_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activities (id, opportunity_id, customer_id, activity_type, description, result, next_action, next_follow_up_date, rep_username, created_at) FROM stdin;
\.


--
-- Data for Name: admin_secret; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_secret (id, password_hash, updated_at, session_version) FROM stdin;
1	1ea0b5950b43151459d77019f50ecdc58d457635085dbc0032b74b476e2ee774	2026-07-18 19:51:38.291693+00	2
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (id, data, updated_at) FROM stdin;
1	{}	2026-07-06 13:07:02.426489+00
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, customer_id, site_id, opportunity_id, asset_type, manufacturer, model, serial_number, capacity, quantity, location_note, installation_date, warranty_start_date, warranty_end_date, status, notes, created_at, updated_at, warranty_years, performance_warranty_years, performance_warranty_end_date, warranty_years_requested, warranty_request_status, warranty_requested_by, warranty_approved_by, warranty_approved_at, warranty_number, is_legacy) FROM stdin;
11	26	\N	\N	other	VEICHI	REACTOR-160A	N/A	160A	1		2026-08-18	2026-08-18	2027-08-17	active		2026-08-18 20:21:45.627688+00	2026-09-01 11:41:14.218+00	1	\N	\N	\N	none	\N	\N	\N	GC-0554001217-1-AUG2026-2021	t
9	12	\N	\N	solar_panel	JA	JAM66D45-625LB		625W	112		2026-04-11	2026-04-11	2038-04-10	active		2026-08-16 15:52:30.279162+00	2026-09-01 11:38:19.087+00	12	30	2056-04-10	\N	none	\N	\N	\N	GC-0531133171-1-APR2026-1552	t
10	26	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669481	90KW	1		2026-08-18	2026-08-18	2027-08-17	active		2026-08-18 20:20:38.491167+00	2026-09-01 19:44:05.987+00	1	\N	\N	\N	none	\N	\N	\N	GC-0554001217-1-AUG2026	t
5	9	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669477	90	1		2026-08-17	2026-08-17	2027-08-16	active		2026-08-16 15:06:28.577562+00	2026-09-01 19:44:43.293+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026	t
6	9	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669466	90	1		2026-08-17	2026-08-17	2027-08-16	active		2026-08-16 15:08:49.382281+00	2026-09-01 19:45:01.961+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026-1508	t
1	12	\N	\N	inverter	VEICHI	SI23-T3-132G-A(H)	9130550192PC08474278	132kw	1		2026-08-01	2026-08-01	2027-07-31	active		2026-08-08 17:38:48.116516+00	2026-09-01 19:46:54.508+00	1	\N	\N	\N	none	\N	\N	\N	GC-0531133171-1-AUG2026	t
2	11	\N	\N	inverter	VEICHI	SI23-T3-200G-A(H)	9130550195Q208781854	200kw	1		2026-08-04	2026-07-08	2027-07-07	active		2026-08-10 16:28:52.19+00	2026-09-01 19:50:49.639+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115352-1-AUG2026	t
3	11	\N	\N	solar_panel	AIKO	MDE72DW-665W		665W	336		2026-08-08	2026-07-08	2038-07-07	active		2026-08-10 16:29:45.9101+00	2026-09-01 19:52:12.204+00	12	30	2056-07-07	\N	none	\N	\N	\N	GC-0555115352-1-AUG2026-1629	t
4	12	\N	\N	solar_panel	AIKO	MDE72DW-665W		665W	224		2026-08-01	2026-08-01	2038-07-31	active		2026-08-10 16:30:41.850884+00	2026-09-01 19:52:31.92+00	12	30	2056-07-31	\N	none	\N	\N	\N	GC-0531133171-1-AUG2026-1630	t
7	9	\N	\N	solar_panel	AIKO	MDE72DW-665W		665	285		2026-08-17	2026-08-17	2038-08-16	active		2026-08-16 15:12:04.963564+00	2026-09-01 19:52:50.518+00	12	30	2056-08-16	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026-1512	t
8	12	\N	\N	inverter	VEICHI	SI23-T3-055G-A(H)		60	1		2026-04-11	2026-04-11	2027-04-10	active		2026-08-16 15:50:54.919314+00	2026-09-01 19:54:32.651+00	1	\N	\N	\N	none	\N	\N	\N	GC-0531133171-1-APR2026	t
12	12	\N	\N	inverter	VEICHI	AC300-T3002G/030P-VA(H)	9210030076P506992492	22KW	1	الاستراحه	2026-09-23	2026-09-23	2027-09-22	active		2026-09-23 11:26:26.231327+00	2026-09-23 11:26:26.231327+00	1	\N	\N	\N	none	\N	\N	\N	GC-0531133171-1-SEP2026	t
13	12	\N	\N	solar_panel	JA	JAM66D46 LB		715W	32	الاستراحه	2026-09-18	2026-09-18	2038-09-17	active		2026-09-23 11:28:53.782439+00	2026-09-23 11:28:53.782439+00	12	30	2056-09-17	\N	none	\N	\N	\N	GC-0531133171-1-SEP2026-1128	t
14	12	\N	\N	solar_panel	JA	JAM66D46 LB		715W	32	الاستراحه	2026-09-18	2026-09-18	2038-09-17	active		2026-09-23 11:28:55.135296+00	2026-09-23 11:28:55.135296+00	12	30	2056-09-17	\N	none	\N	\N	\N	GC-0531133171-1-SEP2026-1128	t
15	9	\N	\N	solar_panel	JA	JAM66D46 LB		715W	97	مزرعه علي طريق سقيا - الرشاش الاربعات	2026-09-18	2026-09-18	2038-09-17	active		2026-09-23 11:30:19.415604+00	2026-09-23 11:30:19.415604+00	12	30	2056-09-17	\N	none	\N	\N	\N	GC-0555115688-1-SEP2026	t
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, actor, actor_role, action_type, entity_type, entity_id, entity_label, old_value, new_value, created_at) FROM stdin;
1	admin	admin	update	project	4	PRJ-2026-004	{"status": "pending", "contract_value": 95000}	{"status": "", "contract_value": 95000}	2026-08-16 15:13:40.764871+00
2	admin	admin	update	project	4	PRJ-2026-004	{"status": "", "contract_value": 95000}	{"status": "in_progress", "contract_value": 95000}	2026-08-16 15:15:40.948054+00
3	admin	admin	update	project	3	PRJ-2026-003	{"status": "pending", "contract_value": 50000}	{"status": "", "contract_value": 50000}	2026-08-16 15:16:47.768589+00
4	admin	admin	update	project	3	PRJ-2026-003	{"status": "", "contract_value": 50000}	{"status": "preparing", "contract_value": 55000}	2026-08-16 15:17:12.489008+00
5	admin	admin	update	project	3	PRJ-2026-003	{"status": "preparing", "contract_value": 55000}	{"status": "in_progress", "contract_value": 55000}	2026-08-16 15:18:12.842603+00
6	admin	admin	add_cost	project	2	other	\N	{"amount": 73000, "description": null}	2026-08-16 15:34:49.083111+00
7	admin	admin	add_cost	project	1	other	\N	{"amount": 173500, "description": null}	2026-08-16 15:36:07.527969+00
8	admin	admin	update	project	5	PRJ-2026-005	{"status": "pending", "contract_value": 175000}	{"status": "commissioned", "contract_value": 175000}	2026-08-16 15:57:45.404156+00
9	admin	admin	add_cost	project	5	other	\N	{"amount": 161000, "description": null}	2026-08-16 15:58:48.855923+00
10	admin	admin	delete	customer	27	شمس التل	\N	\N	2026-08-16 16:15:24.033099+00
11	admin	admin	stage_change	opportunity	7	صفقة - عرض 2026-08-16	{"stage": "new_lead"}	{"stage": "final_approval"}	2026-08-16 16:17:43.251172+00
12	admin	admin	stage_change	opportunity	7	صفقة - عرض 2026-08-16	{"stage": "final_approval"}	{"stage": "won"}	2026-08-16 16:20:07.605649+00
13	admin	admin	status_change	payment_milestone	2	مقدم	{"status": "pending"}	{"status": "paid"}	2026-08-16 16:21:22.625947+00
14	admin	admin	add_payment	project	6	\N	\N	{"amount": 5000, "payment_date": "2026-08-16"}	2026-08-16 16:22:06.035602+00
15	admin	admin	add_cost	project	6	materials	\N	{"amount": 10403, "description": null}	2026-08-16 16:22:58.457967+00
16	admin	admin	update	project	6	PRJ-2026-006	{"status": "pending", "contract_value": 10925}	{"status": "preparing", "contract_value": 10925}	2026-08-16 16:23:44.673738+00
17	admin	admin	update	project	6	PRJ-2026-006	{"status": "preparing", "contract_value": 10925}	{"status": "commissioned", "contract_value": 10925}	2026-08-18 20:15:39.288293+00
18	admin	admin	status_change	payment_milestone	5	عند الاستلام	{"status": "pending"}	{"status": "paid"}	2026-08-18 20:16:57.1369+00
19	admin	admin	add_payment	project	6	\N	\N	{"amount": 5706, "payment_date": "2026-08-18"}	2026-08-18 20:17:13.729881+00
20	admin	admin	add_cost	project	6	materials	\N	{"amount": 10400, "description": "افكار كو"}	2026-08-18 20:17:33.662177+00
21	admin	admin	delete_cost	project	6	materials	{"amount": 10400}	\N	2026-08-18 20:17:44.252316+00
22	admin	admin	add_cost	project	6	transportation	\N	{"amount": 50, "description": null}	2026-08-18 20:17:52.339503+00
23	admin	admin	update	project	4	PRJ-2026-004	{"status": "in_progress", "contract_value": 95000}	{"status": "commissioned", "contract_value": 95000}	2026-08-24 19:05:47.092482+00
24	admin	admin	create	invoice	1	INV-2026-001	\N	{"type": "simplified", "total": 230, "status": "paid"}	2026-08-28 08:56:04.072858+00
25	admin	admin	delete	invoice	1	INV-2026-001	\N	\N	2026-08-29 19:36:31.880527+00
26	admin	admin	create	invoice	2	HEWDS20260829-001	\N	{"type": "simplified", "total": 38138.6, "status": "paid", "approval": "approved"}	2026-08-29 19:46:05.563429+00
27	admin	admin	delete	invoice	2	HEWDS20260829-001	\N	\N	2026-08-29 19:47:12.221075+00
28	admin	admin	delete	customer	36	0	\N	\N	2026-08-29 20:01:43.965668+00
29	admin	admin	delete	customer	35	شمس التل	\N	\N	2026-09-01 11:46:50.521477+00
30	admin	admin	create	invoice	3	HEWDS20260905-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-05 23:26:26.585605+00
31	admin	admin	delete	invoice	3	HEWDS20260905-001	\N	\N	2026-09-05 23:27:28.5683+00
32	admin	admin	create	invoice	4	HEWDS20260906-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-06 09:14:18.499426+00
33	admin	admin	delete	invoice	4	HEWDS20260906-001	\N	\N	2026-09-06 09:22:21.900231+00
34	admin	admin	create	invoice	5	HEWDS20260906-001	\N	{"type": "simplified", "total": 899.3, "status": "paid", "approval": "approved"}	2026-09-06 09:22:44.498985+00
35	admin	admin	delete	invoice	5	HEWDS20260906-001	\N	\N	2026-09-06 09:32:48.744328+00
36	admin	admin	create	invoice	6	HEWDS20260906-001	\N	{"type": "simplified", "total": 38138.6, "status": "paid", "approval": "approved"}	2026-09-06 09:33:09.89261+00
37	admin	admin	delete	invoice	6	HEWDS20260906-001	\N	\N	2026-09-06 13:24:19.362354+00
38	admin	admin	create	invoice	7	HEWDS20260906-001	\N	{"type": "simplified", "total": 899.3, "status": "paid", "approval": "approved"}	2026-09-06 13:31:10.49473+00
39	admin	admin	delete	customer	39	عبدالرحمن منصور - الكرافيت	\N	\N	2026-09-06 15:37:55.005728+00
40	admin	admin	delete	invoice	7	HEWDS20260906-001	\N	\N	2026-09-07 08:36:22.615152+00
41	admin	admin	create	invoice	8	HEWDS20260922-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-21 22:30:28.040145+00
42	admin	admin	create	invoice	9	HEWDS20260922-002	\N	{"type": "simplified", "total": 422.8, "status": "paid", "approval": "approved"}	2026-09-21 22:47:55.09496+00
43	admin	admin	create	invoice	10	HEWDS20260922-003	\N	{"type": "simplified", "total": 435.91, "status": "paid", "approval": "approved"}	2026-09-22 09:03:22.709716+00
44	admin	admin	delete_trial	invoice	8	HEWDS20260922-001	\N	\N	2026-09-22 09:05:11.634274+00
45	admin	admin	delete_trial	invoice	9	HEWDS20260922-002	\N	\N	2026-09-22 09:05:17.502128+00
46	admin	admin	update	project	3	PROJ-0555115688-SUP-P-AUG2026	{"status": "in_progress", "contract_value": 55000}	{"status": "commissioned", "contract_value": 55000}	2026-09-22 22:47:33.761051+00
47	admin	admin	delete	customer	44	مبارك محمد ابو فاضل	\N	\N	2026-09-23 11:21:29.077077+00
48	admin	admin	stage_change	opportunity	8	صفقة - عرض 2026-09-23	{"stage": "new_lead"}	{"stage": "won"}	2026-09-23 11:52:50.029178+00
49	admin	admin	update	project	7	PROJ-0531133171-INS-P-SEP2026	{"status": "pending", "contract_value": 21000}	{"status": "preparing", "contract_value": 21000}	2026-09-23 11:55:40.444149+00
50	admin	admin	stage_change	opportunity	9	60HP UPGRADE TO 100HP	{"stage": "new_lead"}	{"stage": "won"}	2026-09-23 11:57:05.444884+00
51	admin	admin	update	project	8	PROJ-0555115688-LUM-OFG-SEP2026	{"status": "pending", "contract_value": 52000}	{"status": "commissioned", "contract_value": 52000}	2026-09-23 11:58:37.922734+00
52	admin	admin	status_change	payment_milestone	6	52000	{"status": "pending"}	{"status": "paid"}	2026-09-23 11:59:06.808618+00
53	admin	admin	add_cost	project	8	transportation	\N	{"amount": 1800, "description": null}	2026-09-23 11:59:47.075388+00
54	admin	admin	add_cost	project	8	cables	\N	{"amount": 1840, "description": null}	2026-09-23 12:00:22.906233+00
55	admin	admin	add_cost	project	8	materials	\N	{"amount": 45929.62, "description": "97 لوح طاقه من JA SOLAR 715 W + COMBINER BOX 8 LINE - اشراق"}	2026-09-23 12:01:49.618661+00
56	admin	admin	add_payment	project	8	\N	\N	{"amount": 52000, "payment_date": "2026-09-16"}	2026-09-23 12:02:47.36012+00
57	admin	admin	add_cost	project	7	materials	\N	{"amount": 14735, "description": "32 لوح طاقه من JA SOLAR 715 W  - اشراق"}	2026-09-23 12:05:39.191168+00
58	admin	admin	add_cost	project	7	transportation	\N	{"amount": 300, "description": null}	2026-09-23 12:06:54.292708+00
59	admin	admin	add_cost	project	7	materials	\N	{"amount": 3102.7, "description": "لوحة الانفرتر شامله الانفرتر و الحمايات"}	2026-09-23 12:08:13.64184+00
60	admin	admin	add_payment	project	7	\N	\N	{"amount": 5403, "payment_date": "2026-09-20"}	2026-09-23 12:09:19.047532+00
61	admin	admin	add_payment	project	7	\N	\N	{"amount": 14570, "payment_date": "2026-09-23"}	2026-09-23 12:11:04.145158+00
62	admin	admin	create	invoice	11	HEWDS20260926-001	\N	{"type": "simplified", "total": 21000, "status": "paid", "approval": "approved"}	2026-09-26 09:02:02.922059+00
63	admin	admin	credit_note	invoice	12	HEWCN20260926-001	{"invoice": "HEWDS20260926-001"}	{"total": 21000, "reason": "مرتجع"}	2026-09-26 09:05:36.03223+00
64	admin	admin	create	invoice	13	HEWDS20260927-001	\N	{"type": "simplified", "total": 19854.41, "status": "paid", "approval": "approved"}	2026-09-27 18:37:01.845697+00
65	admin	admin	create	invoice	14	HEWDS20260930-001	\N	{"type": "simplified", "total": 19854.41, "status": "paid", "approval": "approved"}	2026-09-29 22:48:23.269265+00
66	admin	admin	delete_trial	invoice	10	HEWDS20260922-003	\N	\N	2026-09-29 22:49:31.0652+00
67	admin	admin	delete_trial	invoice	11	HEWDS20260926-001	\N	\N	2026-09-29 22:49:32.938944+00
68	admin	admin	delete_trial	invoice	13	HEWDS20260927-001	\N	\N	2026-09-29 23:24:59.258784+00
69	admin	admin	delete_trial	invoice	14	HEWDS20260930-001	\N	\N	2026-09-29 23:24:59.242385+00
70	admin	admin	create	invoice	20	HEWDS-INV-202609-0001	\N	{"icv": 3, "type": "simplified", "total": 19854.41, "status": "paid", "approval": "approved"}	2026-09-29 23:40:37.710887+00
71	admin	admin	create	invoice	22	HEWDS-INV-202610-0001	\N	{"icv": 4, "type": "simplified", "total": 19854.41, "status": "paid", "approval": "approved", "supply_date": "2026-10-01"}	2026-09-30 21:38:56.942998+00
72	admin	admin	create	invoice	23	HEWDS-INV-202610-0002	\N	{"icv": 5, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-01"}	2026-10-01 12:09:30.064135+00
73	admin	admin	delete	customer	42	0	\N	\N	2026-10-03 22:21:35.648957+00
74	admin	admin	delete_trial	invoice	20	HEWDS-INV-202609-0001	\N	\N	2026-10-03 22:23:04.891288+00
75	admin	admin	delete_trial	invoice	22	HEWDS-INV-202610-0001	\N	\N	2026-10-03 22:23:09.408651+00
88	admin	admin	stage_change	opportunity	11	عرض سعر 200 حصان	{"stage": "quotation_sent"}	{"stage": "negotiation"}	2026-10-12 05:53:13.832361+00
89	admin	admin	update	project	7	PROJ-0531133171-INS-P-SEP2026	{"status": "preparing", "contract_value": 21000}	{"status": "in_progress", "contract_value": 21000}	2026-10-12 05:54:24.255797+00
99	admin	admin	create	invoice	32	HEWDS-INV-202610-0003	\N	{"icv": 6, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-15"}	2026-10-15 00:26:22.156923+00
100	admin	admin	create	invoice	33	HEWDS-INV-202610-0004	\N	{"icv": 7, "type": "simplified", "total": 21000, "status": "paid", "approval": "approved", "supply_date": "2026-10-15"}	2026-10-15 00:31:20.141758+00
101	claude-mcp	system	update	pricing_config	1	Reactor catalog cleanup (remove unreal 1% 560/1000/1250; set 4% prices)	{"reactor_rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 560A", "1%", "1539.00", "1769.85"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 1000A", "1%", "2529.00", "2908.35"], ["VEICHI Reactor 1250A", "1%", "2999.00", "3448.85"], ["VEICHI Reactor 560A", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A", "4%", "6299.00", "7243.85"]], "reactorPrices": {"50": 389, "80": 479, "100": 499, "160": 599, "315": 999, "450": 1374, "560": 1539, "1000": 2529}}	{"reactor_rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 560A 4%", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A 4%", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A 4%", "4%", "6299.00", "7243.85"]], "reactorPrices": {"50": 389, "80": 479, "100": 499, "160": 599, "315": 999, "450": 1374, "560": 4899, "1000": 5799}}	2026-10-17 23:59:13.085404+00
102	claude-mcp	system	update	pricing_config	1	Reactor names: remove " 4%" suffix from 560A/1000A/1250A	{"reactor_rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 560A 4%", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A 4%", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A 4%", "4%", "6299.00", "7243.85"]]}	{"reactor_rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 560A", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A", "4%", "6299.00", "7243.85"]]}	2026-10-18 00:01:52.076167+00
103	claude-mcp	system	update	pricing_config	1	Reactor productDetails re-keyed after row removal (fix of misaligned details)	{"productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "16 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 16 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "28 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 28 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "50 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 50 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "80 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 80 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "100 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 100 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "160 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 160 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "224 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 224 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "315 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 315 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "450 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 450 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "690 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 690 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "13": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "14": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "15": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}}}	{"productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "16 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 16 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "28 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 28 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "50 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 50 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "80 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 80 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "100 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 100 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "160 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 160 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "224 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 224 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "315 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 315 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "450 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 450 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "690 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 690 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}}}	2026-10-18 11:13:54.3711+00
104	claude-mcp	system	update	product	\N	PNL-00009 Jinko 645W	{"part_number": null, "catalog_name": "PANEL-Jinko-645W", "product_code": "PNL-00009", "warranty_years": null, "performance_warranty_years": null}	{"part_number": "66QL6-BDV", "warranty_years": 12, "performance_warranty_years": 30}	2026-10-18 11:53:22.168478+00
105	claude-mcp	system	update	product	\N	PNL-00010 JA 715W	{"part_number": null, "catalog_name": "PANEL-JA-715W", "product_code": "PNL-00010", "warranty_years": null, "performance_warranty_years": null}	{"part_number": "JAM66D46", "warranty_years": 12, "performance_warranty_years": 30}	2026-10-18 11:53:22.168478+00
106	claude-mcp	system	update	product	\N	PNL-00011 Aiko 660W	{"part_number": null, "catalog_name": "PANEL-Aiko-660W", "product_code": "PNL-00011", "warranty_years": null, "performance_warranty_years": null}	{"part_number": "MDE72DW", "warranty_years": 15, "performance_warranty_years": 30}	2026-10-18 11:53:22.168478+00
107	claude-mcp	system	update	product	\N	PNL-00012 Aiko 770W	{"part_number": null, "catalog_name": "PANEL-Aiko-770W", "product_code": "PNL-00012", "warranty_years": null, "performance_warranty_years": null}	{"part_number": "GRH78Dw", "warranty_years": 15, "performance_warranty_years": 30}	2026-10-18 11:53:22.168478+00
108	claude-mcp	system	update	pricing_config	1	VCLB-1.2K-100-Li price 749 -> 782 excl. VAT (899.30 incl.)	{"row": ["VCLB-1.2K-100-Li", "100A", "12.8V", "749", "861.35"]}	{"row": ["VCLB-1.2K-100-Li", "100A", "12.8V", "782", "899.30"]}	2026-10-18 22:02:50.674427+00
109	claude-mcp	system	update	pricing_config	1	Reactor supplier discount 0->1%; SISV 11KW kw 10.2->11; ready system 9 (الراعي) -> غير متوفر; reactor 560/1000/1250 product-level supplier discount 4%	{"sisv11": {"kw": 10.2, "model": "SISV 11KW (TWIN) MPPT", "priceExclVat": 2499}, "kit9_status": "متوفر", "reactor_discount": {"brand": "VEICHI", "category": "الريأكتور (Reactor)", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -20, "supplierDiscountPct": 0}}	{"sisv11": {"kw": 11, "model": "SISV 11KW (TWIN) MPPT", "priceExclVat": 2499}, "kit9_status": "غير متوفر", "products_4pct": ["VEICHI Reactor 560A", "VEICHI Reactor 1000A", "VEICHI Reactor 1250A"], "reactor_discount": {"brand": "VEICHI", "category": "الريأكتور (Reactor)", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -20, "supplierDiscountPct": 1}}	2026-10-18 22:10:59.051645+00
110	claude-mcp	system	update	crm_settings	\N	assetTypes += reactor, dc_protection (labels for new warranty classes)	[{"label": "لوح شمسي", "value": "solar_panel"}, {"label": "إنفرتر", "value": "inverter"}, {"label": "مضخة", "value": "pump"}, {"label": "موتور", "value": "motor"}, {"label": "VFD (محرك متغير التردد)", "value": "vfd"}, {"label": "لوحة تحكم", "value": "control_panel"}, {"label": "هيكل تركيب", "value": "structure"}, {"label": "نظام مراقبة", "value": "monitoring_system"}, {"label": "بطارية", "value": "battery"}, {"label": "كابلات", "value": "cables"}, {"label": "أخرى", "value": "other"}, {"label": "صندوق تجميع (Combiner Box)", "value": "combiner_box"}, {"label": "إنفرتر جهد عالي (HV)", "value": "hv_inverter"}, {"label": "بطارية جهد عالي (HV)", "value": "hv_battery"}]	[{"label": "لوح شمسي", "value": "solar_panel"}, {"label": "إنفرتر", "value": "inverter"}, {"label": "مضخة", "value": "pump"}, {"label": "موتور", "value": "motor"}, {"label": "VFD (محرك متغير التردد)", "value": "vfd"}, {"label": "لوحة تحكم", "value": "control_panel"}, {"label": "هيكل تركيب", "value": "structure"}, {"label": "نظام مراقبة", "value": "monitoring_system"}, {"label": "بطارية", "value": "battery"}, {"label": "كابلات", "value": "cables"}, {"label": "أخرى", "value": "other"}, {"label": "صندوق تجميع (Combiner Box)", "value": "combiner_box"}, {"label": "إنفرتر جهد عالي (HV)", "value": "hv_inverter"}, {"label": "بطارية جهد عالي (HV)", "value": "hv_battery"}, {"label": "ريأكتور (Reactor)", "value": "reactor"}, {"label": "قواطع وفيوزات DC", "value": "dc_protection"}]	2026-10-19 04:42:15.196403+00
111	admin	admin	create	invoice	34	HEWDS-INV-202610-0005	\N	{"icv": 8, "type": "simplified", "total": 21000, "status": "paid", "approval": "approved", "supply_date": "2026-10-19"}	2026-10-19 04:50:52.360985+00
112	admin	admin	create	invoice	35	HEWDS-INV-202610-0006	\N	{"icv": 9, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-19"}	2026-10-19 05:14:25.510225+00
113	admin	admin	create	invoice	36	HEWDS-INV-202610-0007	\N	{"icv": 10, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-19"}	2026-10-19 05:15:06.870309+00
114	admin	admin	delete_trial	invoice	36	HEWDS-INV-202610-0007	\N	\N	2026-10-19 05:16:23.632733+00
115	admin	admin	delete_trial	invoice	35	HEWDS-INV-202610-0006	\N	\N	2026-10-19 05:16:29.034114+00
116	admin	admin	delete_trial	invoice	32	HEWDS-INV-202610-0003	\N	\N	2026-10-19 05:16:32.792131+00
117	admin	admin	delete_trial	invoice	33	HEWDS-INV-202610-0004	\N	\N	2026-10-19 05:16:36.191131+00
118	admin	admin	delete_trial	invoice	34	HEWDS-INV-202610-0005	\N	\N	2026-10-19 05:16:39.196012+00
119	admin	admin	create	invoice	37	HEWDS-INV-202610-0008	\N	{"icv": 11, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-19"}	2026-10-19 05:20:46.494599+00
120	admin	admin	create	invoice	38	HEWDS-INV-202610-0009	\N	{"icv": 12, "type": "simplified", "total": 17055, "status": "paid", "approval": "approved", "supply_date": "2026-10-19"}	2026-10-19 11:56:38.911116+00
121	admin	admin	delete_trial	invoice	38	HEWDS-INV-202610-0009	\N	\N	2026-10-24 23:27:48.505593+00
122	admin	admin	delete_trial	invoice	37	HEWDS-INV-202610-0008	\N	\N	2026-10-24 23:27:51.861212+00
123	admin	admin	delete_trial	invoice	23	HEWDS-INV-202610-0002	\N	\N	2026-10-24 23:27:54.554438+00
124	admin	admin	update_partner	partner	1	محمود الحسيني	\N	{"name": "محمود الحسيني"}	2026-10-24 23:44:02.284368+00
125	admin	admin	update_partner	partner	2	مبارك محمد ابو فاضل	\N	{"name": "مبارك محمد ابو فاضل"}	2026-10-24 23:44:10.153319+00
126	admin	admin	save_shares	partner	\N	2026-10-24	\N	{"shares": [{"sharePct": 50, "partnerId": 1}, {"sharePct": 50, "partnerId": 2}], "effectiveFrom": "2026-10-24"}	2026-10-24 23:44:10.75084+00
127	admin	admin	update_settings	finance_settings	1	\N	{"id": 1, "vat_rate": 15, "updated_at": "2026-10-24T23:27:25.261471+00:00", "reserve_pct": 0, "completed_statuses": ["commissioned", "completed", "handed_over", "closed"]}	{"updated_at": "2026-10-24T23:53:32.987Z", "reserve_pct": 2.5}	2026-10-24 23:53:33.12461+00
128	admin	admin	add_recurring	recurring_expense	1	rent	\N	{"amount": 2200, "category": "rent", "description": null, "start_month": "2026-03-01", "tax_treatment": "none"}	2026-10-24 23:58:09.304537+00
129	admin	admin	generate_recurring	expense	\N	2026-10-01	\N	{"created": 1}	2026-10-24 23:58:22.150463+00
130	admin	admin	add_recurring	recurring_expense	2	salary	\N	{"amount": 5000, "category": "salary", "description": "محمود الحسيني ", "start_month": "2026-03-01", "tax_treatment": "none"}	2026-10-24 23:59:02.943425+00
131	admin	admin	generate_recurring	expense	\N	2026-10-01	\N	{"created": 1}	2026-10-24 23:59:08.909254+00
132	admin	admin	status_change	payment_milestone	8	دفعة قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-25 00:01:39.009804+00
133	admin	admin	status_change	payment_milestone	9	دفعة قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-25 00:01:59.982474+00
178	admin	admin	add_treasury_entry	treasury_entry	24	supplier_payment	\N	{"amount": 50000, "account_id": "2"}	2026-10-26 11:52:10.760439+00
134	system	system	auto_sync	project	5	PROJ-0531133171-LUM-P-AUG2026-1555	{"paid": 175000, "payment_status": "unpaid"}	{"paid": 175000, "payment_status": "paid"}	2026-10-25 00:03:50.342179+00
135	admin	admin	add_payment	project	5	\N	\N	{"amount": 175000, "payment_date": "2026-10-25"}	2026-10-25 00:03:50.413326+00
136	admin	admin	create_version	quotation	1	Q-2026-001 v1	\N	{"total": 196063.5, "status": "draft"}	2026-10-25 08:33:04.509837+00
137	admin	admin	stage_change	opportunity	19	صفقة - عرض 2026-10-25	{"stage": "new_lead"}	{"stage": "won"}	2026-10-25 08:33:40.514326+00
138	admin	admin	stage_change	opportunity	11	عرض سعر 200 حصان	{"stage": "negotiation"}	{"stage": "follow_up_later"}	2026-10-25 08:36:01.898859+00
139	admin	admin	status_change	quotation	1	Q-2026-001 v1	{"status": "draft"}	{"status": "accepted"}	2026-10-25 08:37:28.291876+00
140	admin	admin	status_change	payment_milestone	10	دفعة قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-25 08:40:18.289817+00
141	admin	admin	status_change	payment_milestone	11	قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-25 08:40:20.114404+00
142	system	system	auto_sync	project	10	PROJ-0555115688-SUP-P-OCT2026	{"paid": 70000, "payment_status": "unpaid"}	{"paid": 70000, "payment_status": "partial"}	2026-10-25 08:40:37.408538+00
143	admin	admin	add_payment	project	10	\N	\N	{"amount": 70000, "payment_date": "2026-10-25"}	2026-10-25 08:40:37.455828+00
144	admin	admin	add_payment	project	10	\N	\N	{"amount": 74000, "payment_date": "2026-10-25"}	2026-10-25 08:40:55.356043+00
145	admin	admin	status_change	payment_milestone	7	21000	{"status": "pending"}	{"status": "paid"}	2026-10-25 08:48:35.295642+00
146	admin	admin	add_supplier	supplier	2	افكار-AFKAR.Co	\N	\N	2026-10-25 09:53:35.210363+00
147	admin	admin	assign_payment	treasury_entry	5	\N	\N	{"account_id": "2", "payment_id": 11}	2026-10-25 09:59:34.642104+00
148	admin	admin	assign_payment	treasury_entry	6	\N	\N	{"account_id": "2", "payment_id": 10}	2026-10-25 09:59:44.521334+00
149	admin	admin	assign_payment	treasury_entry	10	\N	\N	{"account_id": "2", "payment_id": 1}	2026-10-25 16:48:33.389858+00
150	admin	admin	assign_payment	treasury_entry	11	\N	\N	{"account_id": "2", "payment_id": 2}	2026-10-25 16:48:40.467082+00
151	admin	admin	assign_payment	treasury_entry	12	\N	\N	{"account_id": "2", "payment_id": 3}	2026-10-25 16:48:55.726216+00
152	system	system	auto_sync	project	2	PROJ-0531133171-LUM-P-AUG2026	{"paid": 85000, "payment_status": "unpaid"}	{"paid": 85000, "payment_status": "paid"}	2026-10-25 16:51:49.629304+00
153	admin	admin	add_payment	project	2	\N	\N	{"amount": 85000, "payment_date": "2026-03-15"}	2026-10-25 16:51:49.706774+00
154	admin	admin	assign_payment	treasury_entry	13	\N	\N	{"account_id": "2", "payment_id": 9}	2026-10-25 16:52:56.93275+00
155	admin	admin	assign_payment	treasury_entry	14	\N	\N	{"account_id": "2", "payment_id": 5}	2026-10-25 16:53:07.031013+00
156	admin	admin	assign_payment	treasury_entry	15	\N	\N	{"account_id": "2", "payment_id": 6}	2026-10-25 16:53:11.673247+00
157	admin	admin	assign_payment	treasury_entry	16	\N	\N	{"account_id": "2", "payment_id": 13}	2026-10-25 16:53:18.563439+00
158	admin	admin	assign_payment	treasury_entry	17	\N	\N	{"account_id": "2", "payment_id": 4}	2026-10-25 16:56:33.95621+00
163	admin	admin	add_supplier	supplier	3	شركه اشراق للتجارة -Eshraq	\N	\N	2026-10-25 23:07:39.862884+00
164	admin	admin	update_account	treasury_account	2	ANB	\N	{"name": "ANB", "opening_date": "2026-03-08", "opening_balance": 0}	2026-10-25 23:14:06.897051+00
165	admin	admin	update_account	treasury_account	1	محمود الحسيني / بنك الراجحي	\N	{"name": "محمود الحسيني / بنك الراجحي", "opening_date": "2026-03-08", "opening_balance": 0}	2026-10-25 23:14:55.637454+00
166	system	system	auto_sync	project	3	PROJ-0555115688-SUP-P-AUG2026	{"paid": 55000, "payment_status": "unpaid"}	{"paid": 55000, "payment_status": "paid"}	2026-10-25 23:17:49.311599+00
167	admin	admin	add_payment	project	3	\N	\N	{"amount": 55000, "payment_date": "2026-08-12"}	2026-10-25 23:17:49.406739+00
168	system	system	auto_sync	project	4	PROJ-0555115688-SUP-P-AUG2026-1513	{"paid": 45000, "payment_status": "unpaid"}	{"paid": 45000, "payment_status": "partial"}	2026-10-25 23:19:00.036714+00
169	admin	admin	add_payment	project	4	\N	\N	{"amount": 45000, "payment_date": "2026-08-13"}	2026-10-25 23:19:00.089492+00
170	admin	admin	status_change	payment_milestone	13	دفعة قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-25 23:19:24.336503+00
171	admin	admin	assign_payment	treasury_entry	18	\N	\N	{"account_id": "2", "payment_id": 16}	2026-10-26 06:47:06.483338+00
172	admin	admin	edit_payment	project	5	التاريخ السابق خاطئ	{"amount": 175000, "project_id": 5, "payment_date": "2026-10-25"}	{"amount": 175000, "edit_id": 2, "payment_date": "2026-06-29"}	2026-10-26 06:52:37.172843+00
173	admin	admin	assign_payment	treasury_entry	19	\N	\N	{"account_id": "2", "payment_id": 15}	2026-10-26 06:53:26.330266+00
174	admin	admin	add_treasury_entry	treasury_entry	20	supplier_payment	\N	{"amount": 5403, "account_id": "1"}	2026-10-26 06:58:24.710939+00
175	admin	admin	delete	opportunity	11	عرض سعر 200 حصان	\N	\N	2026-10-26 11:48:58.788786+00
176	admin	admin	delete_treasury_entry	treasury_entry	20	supplier_payment	{"kind": "supplier_payment", "amount": 5403, "direction": "out", "account_id": 1, "entry_date": "2026-09-20"}	\N	2026-10-26 11:49:36.545196+00
177	admin	admin	add_treasury_entry	treasury_entry	23	supplier_payment	\N	{"amount": 50000, "account_id": "2"}	2026-10-26 11:50:22.86059+00
179	admin	admin	add_treasury_entry	treasury_entry	25	supplier_payment	\N	{"amount": 14625, "account_id": "2"}	2026-10-26 11:53:36.9098+00
180	admin	admin	add_treasury_entry	treasury_entry	26	supplier_payment	\N	{"amount": 100000, "account_id": "2"}	2026-10-26 11:54:37.618144+00
181	admin	admin	add_treasury_entry	treasury_entry	27	supplier_payment	\N	{"amount": 39300, "account_id": "2"}	2026-10-26 11:55:36.209719+00
182	admin	admin	add_treasury_entry	treasury_entry	28	supplier_payment	\N	{"amount": 100000, "account_id": "2"}	2026-10-26 11:56:36.325989+00
183	admin	admin	add_treasury_entry	treasury_entry	29	supplier_payment	\N	{"amount": 50000, "account_id": "2"}	2026-10-26 11:57:38.900169+00
184	admin	admin	add_treasury_entry	treasury_entry	30	supplier_payment	\N	{"amount": 95687, "account_id": "2"}	2026-10-26 11:58:19.252753+00
185	admin	admin	add_treasury_entry	treasury_entry	31	supplier_payment	\N	{"amount": 5000, "account_id": "1"}	2026-10-26 11:59:19.140682+00
186	admin	admin	add_treasury_entry	treasury_entry	32	supplier_payment	\N	{"amount": 5400, "account_id": "1"}	2026-10-26 12:00:00.304208+00
187	admin	admin	add_treasury_entry	treasury_entry	33	supplier_payment	\N	{"amount": 39300, "account_id": "2"}	2026-10-26 12:02:37.335167+00
188	admin	admin	delete_treasury_entry	treasury_entry	27	supplier_payment	{"kind": "supplier_payment", "amount": 39300, "direction": "out", "account_id": 2, "entry_date": "2026-10-26"}	\N	2026-10-26 12:02:48.580838+00
189	admin	admin	add_treasury_entry	treasury_entry	34	supplier_payment	\N	{"amount": 60500, "account_id": "2"}	2026-10-26 12:04:29.483925+00
190	admin	admin	add_treasury_entry	treasury_entry	35	supplier_payment	\N	{"amount": 165, "account_id": "1"}	2026-10-26 12:05:19.229082+00
191	admin	admin	add_bill	supplier_bill	5	0006-6891	\N	{"po_id": null, "amount": 45929.62, "project_id": null}	2026-10-26 12:08:56.417646+00
192	admin	admin	add_treasury_entry	treasury_entry	36	supplier_payment	\N	{"amount": 45929.62, "account_id": "2"}	2026-10-26 12:09:26.091725+00
193	ALHUSSEINI	rep	update	project	10	PROJ-0555115688-SUP-P-OCT2026	{"status": "preparing", "contract_value": 196064}	{"status": "preparing", "contract_value": 196000}	2026-10-26 13:14:45.662908+00
200	admin	admin	add_treasury_entry	treasury_entry	45	expense	\N	{"amount": 1372, "account_id": "2"}	2026-10-26 20:38:16.097394+00
201	admin	admin	add_treasury_entry	treasury_entry	46	expense	\N	{"amount": 1372, "account_id": "2"}	2026-10-26 20:38:16.845128+00
202	admin	admin	add_treasury_entry	treasury_entry	47	expense	\N	{"amount": 680, "account_id": "2"}	2026-10-26 20:38:54.35438+00
203	admin	admin	add_treasury_entry	treasury_entry	48	expense	\N	{"amount": 3835, "account_id": "2"}	2026-10-26 20:40:04.031517+00
204	admin	admin	delete_cost	project	2	other	{"amount": 73000}	\N	2026-10-26 20:40:38.448991+00
205	admin	admin	add_treasury_entry	treasury_entry	49	expense	\N	{"amount": 359, "account_id": "2"}	2026-10-26 20:41:21.292899+00
206	admin	admin	add_bill	supplier_bill	11	\N	\N	{"po_id": null, "amount": 64625, "project_id": "2"}	2026-10-26 20:43:05.195207+00
207	admin	admin	delete_treasury_entry	treasury_entry	45	expense	{"kind": "expense", "amount": 1372, "direction": "out", "account_id": 2, "entry_date": "2026-04-04"}	\N	2026-10-26 20:45:18.104198+00
208	admin	admin	add_treasury_entry	treasury_entry	50	expense	\N	{"amount": 2117.25, "account_id": "2"}	2026-10-26 20:46:01.795576+00
209	admin	admin	add_bill	supplier_bill	12	0006-6771	\N	{"po_id": null, "amount": 14734.72, "project_id": "7"}	2026-10-26 20:50:38.089262+00
210	admin	admin	delete_treasury_entry	treasury_entry	47	expense	{"kind": "expense", "amount": 680, "direction": "out", "account_id": 2, "entry_date": "2026-10-26"}	\N	2026-10-26 20:52:12.006532+00
211	admin	admin	add_treasury_entry	treasury_entry	51	expense	\N	{"amount": 680, "account_id": "2"}	2026-10-26 20:52:54.547833+00
212	admin	admin	delete_treasury_entry	treasury_entry	36	supplier_payment	{"kind": "supplier_payment", "amount": 45929.62, "direction": "out", "account_id": 2, "entry_date": "2026-09-20"}	\N	2026-10-26 21:29:10.881919+00
213	admin	admin	add_bill	supplier_bill	13	0006-6771	\N	{"po_id": null, "amount": 14734.72, "project_id": "7"}	2026-10-26 21:31:15.360962+00
214	admin	admin	delete_cost	project	7	materials	{"amount": 14735}	\N	2026-10-26 21:31:41.256916+00
215	admin	admin	delete_cost	project	7	materials	{"amount": 14734.72}	\N	2026-10-26 21:32:10.340535+00
216	admin	admin	add_bill	supplier_bill	14	0006-6891	\N	{"po_id": null, "amount": 45929.62, "project_id": "8"}	2026-10-26 21:37:18.121926+00
217	admin	admin	delete_bill	supplier_bill	5	\N	\N	\N	2026-10-26 21:37:27.744472+00
218	admin	admin	delete_cost	project	8	materials	{"amount": 45929.62}	\N	2026-10-26 21:37:52.449904+00
219	system	system	auto_sync	project	6	PROJ-0554001217-SUP-P-AUG2026	{"paid": 16412.00, "payment_status": "partial"}	{"paid": 16412.00, "payment_status": "paid"}	2026-10-26 21:43:25.904626+00
220	admin	admin	add_treasury_entry	treasury_entry	52	customer_receipt	\N	{"amount": 5706, "account_id": "1"}	2026-10-26 21:43:26.179455+00
221	system	system	auto_sync	project	6	PROJ-0554001217-SUP-P-AUG2026	{"paid": 10706.00, "payment_status": "paid"}	{"paid": 10706.00, "payment_status": "partial"}	2026-10-26 21:43:42.05632+00
222	admin	admin	delete_treasury_entry	treasury_entry	12	customer_receipt	{"kind": "customer_receipt", "amount": 5706, "direction": "in", "account_id": 2, "entry_date": "2026-08-18"}	\N	2026-10-26 21:43:42.215684+00
223	system	system	auto_sync	project	6	PROJ-0554001217-SUP-P-AUG2026	{"paid": 15706.00, "payment_status": "partial"}	{"paid": 15706.00, "payment_status": "paid"}	2026-10-26 21:44:22.959185+00
224	admin	admin	add_treasury_entry	treasury_entry	53	customer_receipt	\N	{"amount": 5000, "account_id": "1"}	2026-10-26 21:44:23.019809+00
225	system	system	auto_sync	project	6	PROJ-0554001217-SUP-P-AUG2026	{"paid": 10706.00, "payment_status": "paid"}	{"paid": 10706.00, "payment_status": "partial"}	2026-10-26 21:44:35.394499+00
226	admin	admin	delete_treasury_entry	treasury_entry	11	customer_receipt	{"kind": "customer_receipt", "amount": 5000, "direction": "in", "account_id": 2, "entry_date": "2026-08-16"}	\N	2026-10-26 21:44:35.425978+00
227	system	system	auto_sync	project	6	PROJ-0554001217-SUP-P-AUG2026	{"paid": 10706.00, "payment_status": "partial"}	{"paid": 10706.00, "payment_status": "paid"}	2026-10-26 21:46:29.630976+00
228	admin	admin	update	project	6	PROJ-0554001217-SUP-P-AUG2026	{"status": "commissioned", "contract_value": 10925}	{"status": "commissioned", "contract_value": 10706}	2026-10-26 21:46:29.700141+00
229	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 13}	\N	2026-10-27 02:16:03.236296+00
230	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:17:11.786875+00
231	admin	admin	link_supplier_entry	treasury_entry	34	\N	\N	{"po_id": null, "project_id": "8"}	2026-10-27 02:20:02.954661+00
232	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "14734.72", "bill_id": "13"}	2026-10-27 02:20:33.671539+00
233	admin	admin	link_supplier_entry	treasury_entry	34	\N	\N	{"po_id": null, "project_id": null}	2026-10-27 02:22:08.614216+00
234	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:33.686157+00
235	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:34.296933+00
236	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:34.48166+00
237	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:34.616445+00
238	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:34.655467+00
239	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-27 02:22:34.945014+00
240	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 13}	\N	2026-10-27 02:22:37.11721+00
241	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 14}	\N	2026-10-27 02:22:40.233051+00
242	admin	admin	delete_bill	supplier_bill	13	\N	\N	\N	2026-10-27 02:23:29.363223+00
243	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "45764.62", "bill_id": "14"}	2026-10-27 02:24:10.966284+00
244	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "14734.72", "bill_id": "12"}	2026-10-27 02:24:18.774619+00
245	admin	admin	add_rfq	rfq	4	QL-25Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	\N	{"items": 5, "supplier_id": "2"}	2026-10-27 02:27:53.577645+00
246	admin	admin	edit_treasury_entry	treasury_entry	23	اضافه اسم المشروع	\N	{"project_id": "10"}	2026-10-27 02:40:26.284453+00
247	admin	admin	add_treasury_entry	treasury_entry	57	customer_receipt	\N	{"amount": 40000, "account_id": "2"}	2026-10-27 11:17:12.814655+00
248	admin	admin	update	project	10	PROJ-0555115688-SUP-P-OCT2026	{"status": "preparing", "contract_value": 196000}	{"status": "preparing", "contract_value": 201000}	2026-10-27 11:19:26.122487+00
249	admin	admin	delete	quotation	1	Q-2026-001 v1	\N	\N	2026-10-27 11:43:30.737273+00
250	admin	admin	add_rfq	rfq	5	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	\N	{"items": 2, "supplier_id": "3"}	2026-10-27 11:54:30.921536+00
251	admin	admin	add_rfq	rfq	6	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	\N	{"items": 4, "supplier_id": "2"}	2026-10-27 11:55:24.260346+00
252	admin	admin	add_supplier	supplier	11	MAHMOUD ABO ZAID	\N	\N	2026-10-27 11:56:08.944343+00
253	admin	admin	add_rfq	rfq	7	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	\N	{"items": 1, "supplier_id": "11"}	2026-10-27 11:56:55.855817+00
254	admin	admin	delete_rfq	rfq	4	\N	\N	\N	2026-10-27 11:57:11.245478+00
255	admin	admin	rfq_quote	rfq	6	\N	\N	{"lines": 4, "vat_mode": "excl"}	2026-10-27 12:03:24.829504+00
256	admin	admin	rfq_quote	rfq	5	\N	\N	{"mode": "items", "lines": 1, "vat_mode": "excl", "lump_total": null}	2026-10-27 21:37:58.295442+00
257	admin	admin	rfq_quote	rfq	5	\N	\N	{"mode": "items", "lines": 1, "vat_mode": "excl", "lump_total": null}	2026-10-27 21:38:07.885438+00
258	admin	admin	accept_rfq	rfq	5	\N	\N	{"po_id": 6}	2026-10-27 21:38:36.302832+00
259	admin	admin	rfq_quote	rfq	6	\N	\N	{"mode": "items", "lines": 1, "vat_mode": "excl", "lump_total": null}	2026-10-27 21:39:49.250186+00
260	admin	admin	accept_rfq	rfq	6	\N	\N	{"po_id": 7}	2026-10-27 21:41:57.174887+00
261	admin	admin	rfq_quote	rfq	7	\N	\N	{"mode": "lump", "lines": 0, "vat_mode": "none", "lump_total": 1950}	2026-10-27 21:45:34.562781+00
262	admin	admin	accept_rfq	rfq	7	\N	\N	{"po_id": 8}	2026-10-27 21:45:49.547356+00
263	admin	admin	edit_treasury_entry	treasury_entry	24	ربط المشروع	\N	{"project_id": "2"}	2026-10-27 23:08:25.57874+00
264	admin	admin	edit_treasury_entry	treasury_entry	25	ربط المشروع	\N	{"project_id": "2"}	2026-10-27 23:08:59.636637+00
265	admin	admin	add_bill	supplier_bill	18	26-06088730	\N	{"po_id": null, "amount": 139001.65, "project_id": "5"}	2026-10-27 23:14:24.62315+00
266	admin	admin	delete_cost	project	5	materials	{"amount": 139001.65}	\N	2026-10-27 23:28:03.338134+00
267	admin	admin	rfq_quote	rfq	6	\N	\N	{"mode": "items", "lines": 4, "vat_mode": "excl", "lump_total": null}	2026-10-28 09:55:26.214403+00
268	system	system	auto_sync	project	10	PROJ-0555115688-SUP-P-OCT2026	{"paid": 201000.00, "payment_status": "partial"}	{"paid": 201000.00, "payment_status": "paid"}	2026-10-28 12:25:55.447362+00
269	admin	admin	add_treasury_entry	treasury_entry	58	customer_receipt	\N	{"amount": 17000, "account_id": "1"}	2026-10-28 12:25:55.624043+00
270	admin	admin	status_change	payment_milestone	12	قبل التوريد	{"status": "pending"}	{"status": "paid"}	2026-10-28 12:27:17.131586+00
271	admin	admin	status_change	payment_milestone	15	مجموعه اضافيه	{"status": "pending"}	{"status": "paid"}	2026-10-28 12:27:30.271779+00
272	admin	admin	status_change	payment_milestone	12	قبل التوريد	{"status": "paid"}	{"status": "pending"}	2026-10-28 12:28:43.370548+00
273	admin	admin	assign_payment	treasury_entry	59	\N	\N	{"account_id": "1", "payment_id": 25}	2026-10-28 12:30:03.649081+00
274	admin	admin	delete_treasury_entry	treasury_entry	59	customer_receipt	{"kind": "customer_receipt", "amount": 2000, "direction": "in", "account_id": 1, "entry_date": "2026-10-28"}	\N	2026-10-28 12:30:40.285555+00
275	admin	admin	edit_treasury_entry	treasury_entry	58	BANK TRANSFER	\N	{"method": "bank_transfer"}	2026-10-28 12:31:37.83378+00
276	admin	admin	edit_supplier_bill	supplier_bill	11	اضافه زقم الفاتوره	\N	{"bill_number": "26-03041025"}	2026-10-28 12:34:05.509076+00
277	admin	admin	add_bill	supplier_bill	19	26-07090705	\N	{"po_id": null, "amount": 172000, "project_id": "1"}	2026-10-28 12:36:26.04479+00
278	admin	admin	add_bill	supplier_bill	20	26-08112917	\N	{"po_id": null, "amount": 146791, "project_id": "5"}	2026-10-28 12:39:43.211477+00
279	admin	admin	add_bill	supplier_bill	21	26-09130322	\N	{"po_id": null, "amount": 3102.7, "project_id": "7"}	2026-10-28 12:42:40.495507+00
280	admin	admin	add_bill	supplier_bill	22	26-09129420	\N	{"po_id": null, "amount": 1840, "project_id": "8"}	2026-10-28 12:44:02.114385+00
281	admin	admin	add_bill	supplier_bill	23	26-08114318	\N	{"po_id": null, "amount": 9830.2, "project_id": "6"}	2026-10-28 12:45:10.801635+00
282	admin	admin	delete_cost	project	6	materials	{"amount": 10403}	\N	2026-10-28 12:50:17.302319+00
283	admin	admin	add_treasury_entry	treasury_entry	62	supplier_payment	\N	{"amount": 100000, "account_id": "2"}	2026-10-28 21:36:40.897393+00
284	admin	admin	add_bill	supplier_bill	26	\N	\N	{"po_id": null, "amount": 575, "project_id": null}	2026-10-28 21:44:22.964933+00
285	admin	admin	add_bill	supplier_bill	27	\N	\N	{"po_id": null, "amount": 575, "project_id": null}	2026-10-28 21:44:25.553789+00
286	admin	admin	edit_supplier_bill	supplier_bill	18	تحديث التاريخ	\N	{"bill_date": "2026-06-30"}	2026-10-28 21:45:24.086889+00
287	admin	admin	delete_bill	supplier_bill	27	\N	\N	\N	2026-10-28 21:46:08.40189+00
288	admin	admin	add_treasury_entry	treasury_entry	63	supplier_payment	\N	{"amount": 575, "account_id": "2"}	2026-10-28 21:53:17.558571+00
289	admin	admin	add_treasury_entry	treasury_entry	64	supplier_payment	\N	{"amount": 72000, "account_id": "2"}	2026-10-28 21:56:05.449512+00
290	admin	admin	delete_cost	project	7	materials	{"amount": 3102.7}	\N	2026-10-28 22:03:55.845117+00
291	admin	admin	edit_supplier_bill	supplier_bill	21	فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال	\N	{"description": "فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال"}	2026-10-28 22:05:59.542352+00
292	admin	admin	add_bill	supplier_bill	28	\N	\N	{"amount": 2300, "project_id": "7"}	2026-10-28 22:14:54.343824+00
293	admin	admin	add_treasury_entry	treasury_entry	65	supplier_payment	\N	{"amount": 5403, "account_id": "2"}	2026-10-28 22:17:00.128518+00
294	admin	admin	delete_bill	supplier_bill	28	\N	\N	\N	2026-10-28 22:19:00.567522+00
295	admin	admin	edit_supplier_bill	supplier_bill	20	اضافه الكسور	\N	{"amount": 146791.46}	2026-10-28 22:21:02.51414+00
296	admin	admin	delete_cost	project	1	other	{"amount": 173500}	\N	2026-10-28 22:26:54.881225+00
297	admin	admin	add_cost	project	1	transportation	\N	{"amount": 1500, "description": null}	2026-10-28 22:27:12.940103+00
298	admin	admin	delete_cost	project	1	materials	{"amount": 172000}	\N	2026-10-28 22:33:16.228408+00
299	admin	admin	edit_supplier_bill	supplier_bill	19	0	\N	{"amount": 175000}	2026-10-28 22:39:37.666859+00
300	system	system	auto_sync	project	1	PROJ-0555115352-SUP-P-AUG2026	{"paid": 0, "payment_status": "paid"}	{"paid": 0, "payment_status": "unpaid"}	2026-10-28 22:43:14.078737+00
301	admin	admin	delete_treasury_entry	treasury_entry	10	customer_receipt	{"kind": "customer_receipt", "amount": 175000, "direction": "in", "account_id": 2, "entry_date": "2026-08-01"}	\N	2026-10-28 22:43:14.142343+00
302	system	system	auto_sync	project	1	PROJ-0555115352-SUP-P-AUG2026	{"paid": 175000.00, "payment_status": "unpaid"}	{"paid": 175000.00, "payment_status": "paid"}	2026-10-28 22:44:13.088906+00
303	admin	admin	add_treasury_entry	treasury_entry	66	customer_receipt	\N	{"amount": 175000, "account_id": "2"}	2026-10-28 22:44:13.192075+00
304	admin	admin	unallocate_advance	treasury_entry	65	\N	{"bill_id": 21}	\N	2026-10-28 22:46:28.952476+00
305	admin	admin	unallocate_advance	treasury_entry	32	\N	{"bill_id": 20}	\N	2026-10-28 22:46:30.159534+00
306	admin	admin	unallocate_advance	treasury_entry	31	\N	{"bill_id": 20}	\N	2026-10-28 22:46:32.506458+00
307	admin	admin	unallocate_advance	treasury_entry	31	\N	{"bill_id": 20}	\N	2026-10-28 22:46:33.047027+00
308	admin	admin	unallocate_advance	treasury_entry	30	\N	{"bill_id": 19}	\N	2026-10-28 22:46:35.156061+00
309	admin	admin	unallocate_advance	treasury_entry	29	\N	{"bill_id": 19}	\N	2026-10-28 22:46:37.482234+00
310	admin	admin	unallocate_advance	treasury_entry	30	\N	{"bill_id": 20}	\N	2026-10-28 22:46:42.352701+00
311	admin	admin	unallocate_advance	treasury_entry	64	\N	{"bill_id": 19}	\N	2026-10-28 22:46:44.298338+00
312	admin	admin	unallocate_advance	treasury_entry	24	\N	{"bill_id": 11}	\N	2026-10-28 22:46:48.619328+00
313	admin	admin	unallocate_advance	treasury_entry	25	\N	{"bill_id": 11}	\N	2026-10-28 22:46:51.033934+00
314	admin	admin	unallocate_advance	treasury_entry	26	\N	{"bill_id": 18}	\N	2026-10-28 22:46:54.33095+00
315	admin	admin	unallocate_advance	treasury_entry	33	\N	{"bill_id": 19}	\N	2026-10-28 22:46:56.642576+00
316	admin	admin	unallocate_advance	treasury_entry	33	\N	{"bill_id": 18}	\N	2026-10-28 22:46:58.019055+00
317	admin	admin	unallocate_advance	treasury_entry	28	\N	{"bill_id": 19}	\N	2026-10-28 22:47:01.382548+00
318	admin	admin	edit_supplier_bill	supplier_bill	19	00	\N	{"amount": 172000}	2026-10-28 22:47:19.71114+00
319	admin	admin	allocate_advance	treasury_entry	24	\N	\N	{"amount": "50000", "bill_id": "11"}	2026-10-28 22:48:17.843115+00
320	admin	admin	allocate_advance	treasury_entry	25	\N	\N	{"amount": "14625", "bill_id": "11"}	2026-10-28 22:48:36.496814+00
321	admin	admin	allocate_advance	treasury_entry	26	\N	\N	{"amount": "100000", "bill_id": "18"}	2026-10-28 22:49:29.701284+00
322	admin	admin	allocate_advance	treasury_entry	33	\N	\N	{"amount": "39001.65", "bill_id": "18"}	2026-10-28 22:49:41.43422+00
323	admin	admin	allocate_advance	treasury_entry	28	\N	\N	{"amount": "100000", "bill_id": "19"}	2026-10-28 22:49:55.1871+00
324	admin	admin	allocate_advance	treasury_entry	64	\N	\N	{"amount": "72000", "bill_id": "19"}	2026-10-28 22:50:14.49652+00
325	admin	admin	allocate_advance	treasury_entry	29	\N	\N	{"amount": "50000", "bill_id": "20"}	2026-10-28 22:51:42.626666+00
326	admin	admin	allocate_advance	treasury_entry	30	\N	\N	{"amount": "95687", "bill_id": "20"}	2026-10-28 22:51:55.316853+00
327	admin	admin	allocate_advance	treasury_entry	31	\N	\N	{"amount": "1104.46", "bill_id": "20"}	2026-10-28 22:52:36.25422+00
328	admin	admin	allocate_advance	treasury_entry	31	\N	\N	{"amount": "3895.54", "bill_id": "23"}	2026-10-28 22:52:47.178337+00
329	admin	admin	allocate_advance	treasury_entry	32	\N	\N	{"amount": "5400", "bill_id": "23"}	2026-10-28 22:52:58.074277+00
330	admin	admin	allocate_advance	treasury_entry	65	\N	\N	{"amount": "534.66", "bill_id": "23"}	2026-10-28 22:53:09.099904+00
331	admin	admin	allocate_advance	treasury_entry	65	\N	\N	{"amount": "1840", "bill_id": "22"}	2026-10-28 22:53:23.645108+00
332	admin	admin	allocate_advance	treasury_entry	65	\N	\N	{"amount": "3028.34", "bill_id": "21"}	2026-10-28 22:53:37.686779+00
333	admin	admin	allocate_advance	treasury_entry	33	\N	\N	{"amount": "74.36", "bill_id": "21"}	2026-10-28 22:56:26.596241+00
334	admin	admin	edit_treasury_entry	treasury_entry	23	اضافة امر الشراء	\N	{"po_id": "7"}	2026-10-28 22:59:10.660779+00
335	admin	admin	link_supplier_entry	treasury_entry	23	\N	\N	{"po_id": "7", "project_id": "10"}	2026-10-28 23:00:42.50939+00
336	admin	admin	add_bill	supplier_bill	29	\N	\N	{"po_id": null, "amount": 1700, "project_id": "2"}	2026-10-28 23:03:13.212905+00
337	admin	admin	add_bill	supplier_bill	30	\N	\N	{"po_id": null, "amount": 2200, "project_id": "5"}	2026-10-28 23:04:18.370246+00
338	admin	admin	add_bill	supplier_bill	31	\N	\N	{"po_id": null, "amount": 1800, "project_id": "8"}	2026-10-28 23:06:22.379394+00
339	admin	admin	add_bill	supplier_bill	32	\N	\N	{"po_id": null, "amount": 300, "project_id": "7"}	2026-10-28 23:07:23.064274+00
340	admin	admin	add_bill	supplier_bill	33	\N	\N	{"po_id": null, "amount": 2000, "project_id": "4"}	2026-10-28 23:08:45.189045+00
341	admin	admin	delete_treasury_entry	treasury_entry	50	expense	{"kind": "expense", "amount": 2117.25, "direction": "out", "account_id": 2, "entry_date": "2026-04-04"}	\N	2026-10-28 23:10:42.590209+00
342	admin	admin	add_treasury_entry	treasury_entry	67	expense	\N	{"amount": 417.25, "account_id": "2"}	2026-10-28 23:12:51.735372+00
343	admin	admin	link_supplier_entry	treasury_entry	28	\N	\N	{"po_id": null, "project_id": "1"}	2026-10-28 23:15:52.141408+00
344	admin	admin	link_supplier_entry	treasury_entry	26	\N	\N	{"po_id": null, "project_id": "5"}	2026-10-28 23:18:14.057069+00
345	admin	admin	link_supplier_entry	treasury_entry	33	\N	\N	{"po_id": null, "project_id": "5"}	2026-10-28 23:18:38.578566+00
346	admin	admin	edit_treasury_entry	treasury_entry	31	PROJECT	\N	{"project_id": "6"}	2026-10-28 23:19:28.964928+00
347	admin	admin	edit_treasury_entry	treasury_entry	32	PROJECT	\N	{"project_id": "6"}	2026-10-28 23:19:52.306108+00
348	admin	admin	link_supplier_entry	treasury_entry	34	\N	\N	{"po_id": null, "project_id": "8"}	2026-10-28 23:21:19.908662+00
349	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 14}	\N	2026-10-28 23:22:33.855789+00
350	admin	admin	unallocate_advance	treasury_entry	35	\N	{"bill_id": 14}	\N	2026-10-28 23:22:36.687254+00
351	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "14734.72", "bill_id": "12"}	2026-10-28 23:23:12.479124+00
352	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "45765.28", "bill_id": "14"}	2026-10-28 23:23:22.226443+00
353	admin	admin	allocate_advance	treasury_entry	35	\N	\N	{"amount": "164.34", "bill_id": "14"}	2026-10-28 23:23:30.520794+00
354	admin	admin	link_supplier_entry	treasury_entry	35	\N	\N	{"po_id": null, "project_id": "7"}	2026-10-28 23:26:34.759936+00
355	admin	admin	allocate_advance	treasury_entry	35	\N	\N	{"amount": "164.34", "bill_id": "14"}	2026-10-28 23:27:12.871996+00
356	admin	admin	delete_cost	project	8	cables	{"amount": 1840}	\N	2026-10-28 23:28:12.489171+00
357	admin	admin	delete_cost	project	8	transportation	{"amount": 1800}	\N	2026-10-28 23:28:23.091551+00
358	admin	admin	delete_cost	project	7	transportation	{"amount": 300}	\N	2026-10-28 23:30:37.646205+00
359	admin	admin	unallocate_advance	treasury_entry	34	\N	{"bill_id": 12}	\N	2026-10-28 23:34:01.932794+00
360	admin	admin	allocate_advance	treasury_entry	35	\N	\N	{"amount": "0.66", "bill_id": "12"}	2026-10-28 23:34:26.869708+00
361	admin	admin	allocate_advance	treasury_entry	34	\N	\N	{"amount": "14734.06", "bill_id": "12"}	2026-10-28 23:35:06.188811+00
362	admin	admin	allocate_advance	treasury_entry	32	\N	\N	{"amount": "74.36", "bill_id": "21"}	2026-10-28 23:49:04.082212+00
363	admin	admin	allocate_advance	treasury_entry	32	\N	\N	{"amount": "806.11", "bill_id": "20"}	2026-10-28 23:49:13.102589+00
\.


--
-- Data for Name: catalog_category_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.catalog_category_map (catalog_category, family, sub_category, requires_serial) FROM stdin;
ألواح الطاقة الشمسية	PNL	solar_panel	f
شواحن/انفرترات هجين MPPT	INV	hybrid	t
انفرتر مضخات VEICHI	INV	pump	t
بطاريات ليثيوم	BAT	lithium_battery	t
صناديق التجميع (Combiner Box)	CMB	combiner_box	f
الريأكتور (Reactor)	RCT	reactor	f
قواطع وفيوزات DC	PRT	dc_protection	f
الكابلات والوصلات (MC4)	CBL	cables	f
\.


--
-- Data for Name: company_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_profile (id, name_ar, short_name_ar, name_en, vat_number, cr_number, commercial_reg, national_address_code, address, phone, whatsapp, email, website, logo_url, invoice_prefix, updated_at, updated_by) FROM stdin;
1	مؤسسة حلول الطاقة المتجددة والمقاولات	حلول الطاقة المتجددة والمقاولات	HoloulEnergy	311386341200003	7037810988	1010970687	RDMC8001	{"city": "الرياض", "street": "أحمد الكازروني", "country": "المملكة العربية السعودية", "district": "حي المهدية", "buildingNo": "8001", "postalCode": "13752", "additionalNo": "2343"}	966561274344+	966561274344	info@HoloulEnergy.com	\N	\N	HEWDS	2026-10-05 00:29:21.961738+00	\N
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, customer_id, name, "position", mobile, whatsapp, email, preferred_contact_method, decision_power, notes, created_at, updated_at) FROM stdin;
1	9	الشيخ حمود بن ناصر	555115688	\N	\N	\N	\N	\N	\N	2026-08-10 16:04:38.686701+00	2026-08-10 16:04:38.686701+00
\.


--
-- Data for Name: crm_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_interactions (id, customer_id, rep_username, interaction_type, note, outcome, status_after, created_at) FROM stdin;
1	10	admin	visit	مشكله ف الحساب البنكي الخاص بالمؤسسه الاسم غير متطابق مع الاسم المعلن و المستخدم في التسويق	موافق	\N	2026-08-08 08:13:54.084257+00
2	9	admin	visit	زياره للمزرعه بتاريخ 12082026 لمعرفه الطريق و حاله الموقع و الجاهزية لتسليم الخامات	\N	\N	2026-08-12 11:38:57.812387+00
\.


--
-- Data for Name: crm_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_settings (id, data, updated_at) FROM stdin;
1	{"regions": [{"label": "الوسطي - وادي الدواسر", "value": "الوسطي_-_وادي_الدواسر"}, {"label": "الوسطي - القصيم", "value": "الوسطي_-_القصيم"}, {"label": "الشمال - طبرجل", "value": "الشمال_-_طبرجل"}, {"label": "الشمال - تبوك و حائل", "value": "الشمال_-_تبوك_و_حائل"}, {"label": "الجنوب - خميس مشيط و جيزان", "value": "الجنوب_-_خميس_مشيط_و_جيزان"}, {"label": "الجنوب - نجران", "value": "الجنوب_-_نجران"}], "statuses": [{"color": "#5b8ef2", "label": "عميل جديد", "value": "new"}, {"color": "#f0c14b", "label": "تم التواصل", "value": "contacted"}, {"color": "#e8a33d", "label": "بيتفاوض", "value": "negotiating"}, {"color": "#0fa98d", "label": "تم الاتفاق", "value": "won"}, {"color": "#e0553f", "label": "اتفقد", "value": "lost"}, {"color": "#93a89c", "label": "مؤجل", "value": "on_hold"}], "costTypes": [{"label": "خامات", "value": "materials"}, {"label": "عمالة", "value": "labor"}, {"label": "نقل", "value": "transportation"}, {"label": "تركيب", "value": "installation"}, {"label": "أعمال خرسانية", "value": "concrete"}, {"label": "هيكل", "value": "structure"}, {"label": "كابلات", "value": "cables"}, {"label": "أعمال هندسية", "value": "engineering"}, {"label": "مصاريف أخرى", "value": "other"}], "assetTypes": [{"label": "لوح شمسي", "value": "solar_panel"}, {"label": "إنفرتر", "value": "inverter"}, {"label": "مضخة", "value": "pump"}, {"label": "موتور", "value": "motor"}, {"label": "VFD (محرك متغير التردد)", "value": "vfd"}, {"label": "لوحة تحكم", "value": "control_panel"}, {"label": "هيكل تركيب", "value": "structure"}, {"label": "نظام مراقبة", "value": "monitoring_system"}, {"label": "بطارية", "value": "battery"}, {"label": "كابلات", "value": "cables"}, {"label": "أخرى", "value": "other"}, {"label": "صندوق تجميع (Combiner Box)", "value": "combiner_box"}, {"label": "إنفرتر جهد عالي (HV)", "value": "hv_inverter"}, {"label": "بطارية جهد عالي (HV)", "value": "hv_battery"}, {"label": "ريأكتور (Reactor)", "value": "reactor"}, {"label": "قواطع وفيوزات DC", "value": "dc_protection"}], "priorities": [{"label": "ساخن 🔥", "value": "hot"}, {"label": "دافئ", "value": "warm"}, {"label": "بارد", "value": "cold"}], "leadSources": [{"label": "الموقع الإلكتروني", "value": "website"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "مكالمة مباشرة", "value": "phone"}, {"label": "توصية عميل", "value": "referral"}, {"label": "عميل حالي (مشروع جديد)", "value": "existing_customer"}, {"label": "زيارة ميدانية", "value": "site_visit"}, {"label": "سوشيال ميديا", "value": "social_media"}, {"label": "معرض", "value": "exhibition"}, {"label": "شريك/وسيط", "value": "partner"}, {"label": "حملة تسويقية", "value": "marketing_campaign"}, {"label": "أخرى", "value": "other"}], "idScopeTypes": [{"code": "INS", "label": "تركيب فقط (Installation Only)", "value": "installation"}, {"code": "SUP", "label": "توريد فقط (Supply Only)", "value": "supply"}, {"code": "LUM", "label": "مقطوعية (Lump Sum)", "value": "lumpsum"}], "projectTypes": [{"label": "طاقة شمسية لمضخات الري", "value": "solar_pumping"}, {"label": "محطة طاقة شمسية", "value": "solar_power_plant"}, {"label": "هجين شمسي/ديزل", "value": "solar_diesel_hybrid"}, {"label": "شمسي مربوط بالشبكة", "value": "solar_grid"}, {"label": "تخزين بطاريات", "value": "battery_storage"}, {"label": "طاقة شمسية تجارية", "value": "commercial_solar"}, {"label": "طاقة شمسية صناعية", "value": "industrial_solar"}, {"label": "طاقة شمسية زراعية", "value": "agricultural_solar"}, {"label": "EPC", "value": "epc"}, {"label": "مقاولات كهربائية", "value": "electrical_contracting"}, {"label": "مقاولات عامة", "value": "general_contracting"}, {"label": "صيانة", "value": "maintenance"}, {"label": "توسعة", "value": "expansion"}, {"label": "أخرى", "value": "other"}], "activityTypes": [{"label": "مكالمة تليفون", "value": "call"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "إيميل", "value": "email"}, {"label": "اجتماع", "value": "meeting"}, {"label": "زيارة مزرعة", "value": "site_visit"}, {"label": "اجتماع فني", "value": "technical_meeting"}, {"label": "إرسال عرض سعر", "value": "quotation"}, {"label": "متابعة", "value": "follow_up"}, {"label": "شكوى", "value": "complaint"}, {"label": "تانى", "value": "other"}], "assetStatuses": [{"color": "#0fa98d", "label": "شغال", "value": "active"}, {"color": "#e0553f", "label": "فيه عطل", "value": "faulty"}, {"color": "#93a89c", "label": "اتستبدل", "value": "replaced"}, {"color": "#63736f", "label": "اتشال", "value": "removed"}], "customerTypes": [{"label": "فرد", "value": "individual"}, {"label": "مؤسسة", "value": "institution"}, {"label": "شركة", "value": "company"}], "energySources": [{"label": "ديزيل", "value": "ديزيل"}, {"label": "كهرباء", "value": "كهرباء"}], "idSystemTypes": [{"code": "P", "label": "مضخة (Pump)", "value": "pump"}, {"code": "OG", "label": "أون-جريد (On-Grid)", "value": "ongrid"}, {"code": "OFG", "label": "أوف-جريد (Off-Grid)", "value": "offgrid"}, {"code": "H", "label": "هايبرد (Hybrid)", "value": "hybrid"}], "priceFeedback": [{"label": "السعر مناسب", "value": "acceptable"}, {"label": "غالي شوية", "value": "slightly_high"}, {"label": "غالي جدًا", "value": "too_high"}, {"label": "محتاج خصم", "value": "needs_discount"}, {"label": "مش معروف", "value": "unknown"}], "blockerReasons": [{"label": "السعر غالي", "value": "price_too_high"}, {"label": "مفيش ميزانية دلوقتي", "value": "no_budget"}, {"label": "بيقارن بعروض تانية", "value": "comparing_offers"}, {"label": "مخاوف فنية", "value": "technical_concerns"}, {"label": "مش متأكد من الشركة", "value": "trust_company"}, {"label": "مش وقته دلوقتي (موسم/حصاد)", "value": "timing_not_ready"}, {"label": "مبيردش / اختفى", "value": "no_response"}, {"label": "غيّر رأيه", "value": "changed_mind"}, {"label": "سبب تاني", "value": "other"}, {"label": "مفيش مشكلة", "value": "none"}], "contactMethods": [{"label": "اتصال هاتفي", "value": "اتصال_هاتفي"}, {"label": "واتس اب", "value": "واتس_اب"}], "paymentMethods": [{"label": "كاش", "value": "cash"}, {"label": "تحويل بنكي", "value": "bank_transfer"}, {"label": "شيك", "value": "cheque"}, {"label": "ماكينات ال POS", "value": "other"}, {"label": "أخرى", "value": "أخرى"}], "ticketStatuses": [{"color": "#5b8ef2", "label": "مفتوحة", "value": "open"}, {"color": "#e7ac12", "label": "معيّنة لمهندس", "value": "assigned"}, {"color": "#f3cb56", "label": "جاري العمل", "value": "in_progress"}, {"color": "#93a89c", "label": "في انتظار العميل", "value": "waiting_customer"}, {"color": "#0fa98d", "label": "اتحلت", "value": "resolved"}, {"color": "#63736f", "label": "مقفولة", "value": "closed"}], "classifications": [{"label": "صغير (1-5)", "value": "صغير_1-5"}, {"label": "متوسط( 5-20)", "value": "متوسط_5-20"}, {"label": "كبير (20- 100)", "value": "كبير_20-_100"}], "invoiceStatuses": [{"color": "#93a89c", "label": "مسودة", "value": "draft"}, {"color": "#5b8ef2", "label": "اتبعتت للعميل", "value": "sent"}, {"color": "#0FA98D", "label": "اتسددت", "value": "paid"}, {"color": "#e0553f", "label": "متأخرة عن السداد", "value": "overdue"}, {"color": "#63736F", "label": "ملغاة", "value": "cancelled"}], "projectStatuses": [{"color": "#E7AC12", "label": "جاري التجهيز", "value": "preparing"}, {"color": "#155E85", "label": "قيد التنفيذ", "value": "in_progress"}, {"color": "#0FA98D", "label": "تم الاستلام من المخزن", "value": "commissioned"}, {"color": "#e0553f", "label": "ملغي", "value": "cancelled"}], "interactionTypes": [{"label": "مكالمة", "value": "call"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "زيارة مزرعة", "value": "visit"}, {"label": "اجتماع", "value": "meeting"}, {"label": "تانى", "value": "other"}], "ticketPriorities": [{"color": "#e0553f", "label": "حرجة", "value": "critical"}, {"color": "#e7ac12", "label": "عالية", "value": "high"}, {"color": "#5b8ef2", "label": "متوسطة", "value": "medium"}, {"color": "#93a89c", "label": "منخفضة", "value": "low"}], "milestoneStatuses": [{"color": "#93a89c", "label": "لسه مستحقة", "value": "pending"}, {"color": "#E7AC12", "label": "مستحقة دلوقتي", "value": "due"}, {"color": "#0FA98D", "label": "اتسددت", "value": "paid"}], "opportunityStages": [{"color": "#5b8ef2", "label": "عميل جديد", "value": "new_lead"}, {"color": "#7c9dd6", "label": "مؤهّل", "value": "qualified"}, {"color": "#0fa98d", "label": "تواصل أولي", "value": "initial_contact"}, {"color": "#0b7a66", "label": "محتاج مسح ميداني", "value": "survey_required"}, {"color": "#0b7a66", "label": "المسح الميداني تم", "value": "survey_completed"}, {"color": "#155e85", "label": "دراسة فنية", "value": "technical_study"}, {"color": "#e7ac12", "label": "تم إرسال العرض", "value": "quotation_sent"}, {"color": "#e8a33d", "label": "تفاوض", "value": "negotiation"}, {"color": "#f3cb56", "label": "موافقة نهائية", "value": "final_approval"}, {"color": "#0fa98d", "label": "اتكسبت", "value": "won"}, {"color": "#e0553f", "label": "اتفقدت", "value": "lost"}, {"color": "#93a89c", "label": "متابعة لاحقًا", "value": "follow_up_later"}], "projectScopeTypes": [{"label": "توريد فقط", "value": "supply_only"}, {"label": "تركيب فقط", "value": "install_only"}, {"label": "توريد وتركيب", "value": "supply_and_install"}, {"label": "صيانة فقط", "value": "maintenance_only"}], "quotationStatuses": [{"color": "#93a89c", "label": "مسودة", "value": "draft"}, {"color": "#5b8ef2", "label": "اتبعت للعميل", "value": "sent"}, {"color": "#0fa98d", "label": "اتقبلت", "value": "accepted"}, {"color": "#e0553f", "label": "اترفضت", "value": "rejected"}, {"color": "#63736f", "label": "منتهية الصلاحية", "value": "expired"}], "standardWarranties": {"inverter": {"defectYears": 1}, "hv_battery": {"defectYears": 10}, "hv_inverter": {"defectYears": 5}, "solar_panel": {"defectYears": 12, "performanceYears": 30}, "combiner_box": {"defectYears": 1}}, "decisionPowerLevels": [{"label": "المدير", "value": "المدير"}, {"label": "وسيط", "value": "وسيط"}, {"label": "العامل", "value": "العامل"}], "opportunityLostReasons": [{"label": "السعر", "value": "price"}, {"label": "منافس", "value": "competitor"}, {"label": "الميزانية", "value": "budget"}, {"label": "تأخر القرار", "value": "delayed"}, {"label": "العميل غيّر خطته", "value": "customer_changed_plan"}, {"label": "التمويل", "value": "financing"}, {"label": "مشكلة فنية", "value": "technical_issue"}, {"label": "المشروع اتلغى", "value": "project_cancelled"}, {"label": "سبب تاني", "value": "other"}], "maintenanceContractStatuses": [{"color": "#0fa98d", "label": "سارٍ", "value": "active"}, {"color": "#e0553f", "label": "منتهي", "value": "expired"}, {"color": "#63736f", "label": "ملغي", "value": "cancelled"}]}	2026-10-11 12:32:05.618786+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, rep_username, quotes_count, first_quote_at, last_quote_at, created_at, updated_at, status, price_feedback, blocker_reason, blocker_notes, next_follow_up_date, last_contact_at, assigned_rep, priority, lost_reason_detail, city, crm_created_at, customer_type, classification, commercial_registration, vat_number, unified_number, region, lead_source) FROM stdin;
8	عبدالرحمن ناصر محمد القحطاني	0567712263	ALHUSSEINI	2	2026-08-02 19:23:16.163+00	2026-08-02 19:24:06.021+00	2026-08-02 19:23:16.237128+00	2026-08-10 16:21:05.425+00	contacted	slightly_high	no_budget		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	\N	\N				\N	\N
3	الشيخ علوش بن محسن بن قويد	0504101359	ALHUSSEINI	1	2026-07-12 11:16:46.288822+00	2026-07-12 11:16:46.288822+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:22:28.177+00	contacted	acceptable	no_budget		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	فرد	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
5	عبدالعزيز محمد الدوسري	0599909493	ALHUSSEINI	3	2026-07-17 11:23:01.30727+00	2026-07-17 11:24:59.253852+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:22:52.896+00	contacted	slightly_high	no_budget	اقساط 50% مقدم و الباقي ع سنه	\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	فرد	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
4	محمد الحارثي	0509837564	ALHUSSEINI	4	2026-07-19 14:43:42.332633+00	2026-07-19 15:06:16.741853+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:23:34.098+00	contacted	unknown	no_response		\N	\N	م محمود الحسيني	warm	\N		2026-08-07 14:47:36.15421+00	فرد	متوسط_5-20				الوسطي_-_وادي_الدواسر	\N
15	مهدي مؤسسه الوسائل المتطورة	0549307344	\N	0	\N	\N	2026-08-10 16:18:57.461629+00	2026-08-10 16:24:14.248+00	negotiating	needs_discount	no_response		\N	\N	م محمود الحسيني	warm	\N	السليل	2026-08-10 16:18:57.461629+00	فرد	متوسط_5-20				الوسطي_-_وادي_الدواسر	site_visit
7	عبدالله محمد الدوسري	0531457772	ALHUSSEINI	3	2026-08-01 10:00:47.279+00	2026-08-01 10:02:53.839+00	2026-08-01 10:00:47.374387+00	2026-08-10 16:24:42.697+00	new	\N	\N		\N	\N		warm	\N		2026-08-07 14:47:36.15421+00	\N	\N				\N	\N
32	احمد حامد السوداني	0565480579	ALHUSSEINI	6	2026-08-22 05:47:52.505+00	2026-08-24 11:31:51.022+00	2026-08-22 05:47:52.57721+00	2026-09-04 11:54:03.160175+00	contacted	acceptable	\N		\N	\N	م محمود الحسيني	hot	\N	Wae	2026-08-22 05:47:52.57721+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	site_visit
31	عادل ماسه الوادي	0550900968	ALHUSSEINI	10	2026-08-20 11:48:22.336+00	2026-08-24 11:20:01.524+00	2026-08-20 11:48:22.570641+00	2026-09-04 11:54:03.160175+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-08-20 11:48:22.570641+00	individual	\N	\N	\N	\N	\N	\N
54	علاء - الاحساء 	0568651110	ALHUSSEINI	5	2026-10-19 05:35:21.328+00	2026-10-19 06:21:02.171+00	2026-10-19 05:35:21.406928+00	2026-10-19 06:21:02.171+00	contacted	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-10-19 05:35:21.406928+00	individual	\N	\N	\N	\N	\N	\N
9	حمود بن ناصر 	0555115688	ALHUSSEINI	9	2026-08-03 06:55:44.126+00	2026-10-27 11:39:56.66+00	2026-08-03 06:55:44.172335+00	2026-10-27 11:39:56.66+00	won	slightly_high	\N		\N	2026-08-12 11:38:57.852+00	م محمود الحسيني	warm	\N	Wae	2026-08-07 14:47:36.15421+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	referral
12	مبارك محمد ابو فاضل	0531133171	ALHUSSEINI	3	2026-09-23 08:13:09.121286+00	2026-10-01 12:08:11.216+00	2026-08-08 08:18:25.624249+00	2026-10-01 12:08:11.216+00	won	acceptable	\N	تم الانتهاء من تنفيذ المنظومة	\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-08 08:18:25.624249+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
24	ظافر مسعود اليامي الرشدان	0505116132	\N	0	\N	\N	2026-08-11 08:57:29.852052+00	2026-08-11 08:58:50.133+00	contacted	\N	technical_concerns		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 08:57:29.852052+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	phone
10	محمد جبران	0557761677	ALHUSSEINI	1	2026-08-08 07:44:04.718+00	2026-08-08 07:44:04.718+00	2026-08-08 07:44:04.773132+00	2026-08-12 11:34:39.99+00	lost	acceptable	trust_company	نفذ بالواح جينكو 590 وات من مورد منافس	\N	2026-08-08 08:13:54.168+00		warm	\N		2026-08-08 07:44:04.773132+00	\N	\N				\N	\N
14	مبارك الخنين	0567043616	\N	0	\N	\N	2026-08-10 16:18:18.514212+00	2026-08-16 16:01:57.911+00	contacted	\N	timing_not_ready		\N	\N	م محمود الحسيني	cold	\N	wae	2026-08-10 16:18:18.514212+00	institution	متوسط_5-20				الوسطي_-_وادي_الدواسر	phone
26	شمس التل	0554001217	\N	1	2026-08-16 14:25:58.2+00	2026-08-16 14:25:58.2+00	2026-08-16 14:25:58.289442+00	2026-08-16 16:16:59.649+00	won	acceptable	\N		\N	\N	م محمود الحسيني	hot	\N	Wae	2026-08-16 14:25:58.289442+00	institution	متوسط_5-20	7050598759	313102440300003		الوسطي_-_وادي_الدواسر	site_visit
18	مصابيح بن قويد	0505115222	\N	0	\N	\N	2026-08-11 07:37:17.204705+00	2026-08-18 05:53:58.103+00	contacted	too_high	no_budget		\N	\N	م محمود الحسيني	cold	\N	wae	2026-08-11 07:37:17.204705+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
28	أبو ماجد	0509927849	ALHUSSEINI	1	2026-08-18 05:24:05.117+00	2026-08-18 05:24:05.117+00	2026-08-18 05:24:05.151716+00	2026-08-18 05:52:59.906+00	contacted	\N	\N		\N	\N		cold	\N		2026-08-18 05:24:05.151716+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
16	ماجد سلامه أبو عبدالهادي الدوسري امن الطرق	0531209995	\N	0	\N	\N	2026-08-11 07:34:35.062176+00	2026-08-18 05:54:10.268+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:34:35.062176+00	individual	\N				\N	\N
29	عادل ديماس الجوف	0560595743	ALHUSSEINI	1	2026-08-18 05:26:22.984+00	2026-08-18 05:26:22.984+00	2026-08-18 05:26:23.043012+00	2026-08-18 05:53:12.593+00	contacted	acceptable	\N		\N	\N		hot	\N	Wae	2026-08-18 05:26:23.043012+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
23	يحي مزرعه الجيلا	0502319478	\N	0	\N	\N	2026-08-11 07:43:54.460404+00	2026-08-18 05:54:38.873+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:43:54.460404+00	individual	\N				\N	\N
17	محمد بن ناصر بن صقر	0555532122	\N	0	\N	\N	2026-08-11 07:35:48.393292+00	2026-08-18 05:54:52.888+00	lost	acceptable	no_response		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-11 07:35:48.393292+00	institution	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
20	شجاع محمد السنبله	0555116727	\N	0	\N	\N	2026-08-11 07:39:20.275483+00	2026-08-18 05:55:05.089+00	contacted	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:39:20.275483+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	site_visit
22	حسن الشهري أبو محمد شركه الانماء	0505702103	\N	0	\N	\N	2026-08-11 07:43:03.840453+00	2026-08-18 05:55:35.069+00	contacted	unknown	trust_company		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:43:03.840453+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	referral
13	محماس مجدل	0504196915	\N	0	\N	\N	2026-08-10 16:17:23.261703+00	2026-08-10 16:20:28.168+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-10 16:17:23.261703+00	\N	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
19	مبارك مخاريم الدوسري	0505943588	\N	0	\N	\N	2026-08-11 07:38:22.709247+00	2026-08-24 06:43:41.808+00	contacted	unknown	timing_not_ready		2026-10-17	\N	م محمود الحسيني	cold	\N	wae	2026-08-11 07:38:22.709247+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	site_visit
30	الشيخه الاميره	0506222121	ALHUSSEINI	1	2026-08-18 05:49:27.436+00	2026-08-18 05:49:27.436+00	2026-08-18 05:49:27.501345+00	2026-08-24 06:44:21.657+00	contacted	acceptable	no_budget		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-18 05:49:27.501345+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
53	عبدالله - وادي الدواسر	0597544148	ALHUSSEINI	3	2026-10-16 13:30:55.458+00	2026-10-16 13:32:14.058+00	2026-10-16 13:30:55.532833+00	2026-10-16 13:32:14.058+00	contacted	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-10-16 13:30:55.532833+00	individual	\N	\N	\N	\N	\N	\N
51	0562258078	0562258078	ALHUSSEINI	4	2026-10-13 15:46:19.556+00	2026-10-18 09:14:02.139+00	2026-10-13 15:46:19.703362+00	2026-10-18 09:14:02.139+00	contacted	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-10-13 15:46:19.703362+00	individual	\N	\N	\N	\N	\N	\N
11	حاظر مشلح ابو مسفر	0555115352	\N	0	\N	\N	2026-08-08 08:17:12.516939+00	2026-09-01 11:48:41.472+00	won	needs_discount	\N	تم التنفيذ	\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-08 08:17:12.516939+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
33	فألح مفرج الطويله	0551833823	ALHUSSEINI	1	2026-08-23 08:05:24.442+00	2026-08-23 08:05:24.442+00	2026-08-23 08:05:24.477599+00	2026-09-04 11:54:03.160175+00	contacted	acceptable	comparing_offers		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-23 08:05:24.477599+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
37	فيحان محمد فيحان ذعار الرجبان سمك في دوسر	0501111713	\N	0	\N	\N	2026-08-29 20:01:04.991004+00	2026-09-04 11:54:03.160175+00	new	\N	\N	\N	\N	\N	م محمود الحسيني	warm	\N	Wae	2026-08-29 20:01:04.991004+00	individual	\N	\N	\N	\N	\N	\N
38	عبدالرحمن منصور - الكرافيت	0551411010	ALHUSSEINI	2	2026-09-05 09:05:21.034+00	2026-09-05 09:06:12.445+00	2026-09-05 09:05:21.091554+00	2026-09-05 17:44:55.408+00	new	\N	\N		\N	\N		warm	\N		2026-09-05 09:05:21.091554+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
41	سالم مرزوق - الكرافيت	0555115510	ALHUSSEINI	1	2026-09-16 16:31:44.327+00	2026-09-16 16:31:44.327+00	2026-09-16 16:31:44.861294+00	2026-09-23 12:12:58.741+00	new	\N	\N		\N	\N		warm	\N		2026-09-16 16:31:44.861294+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
40	ابو مهدي جار العقيد	0556635456	ALHUSSEINI	1	2026-09-11 16:59:43.425+00	2026-09-11 16:59:43.425+00	2026-09-11 16:59:43.67111+00	2026-09-23 12:15:36.863+00	new	\N	\N		\N	\N		warm	\N		2026-09-11 16:59:43.67111+00	individual	صغير_1-5				\N	\N
45	محمد مبارك	0557315456	ALHUSSEINI	3	2026-09-23 11:15:26.964+00	2026-09-23 11:20:34.117+00	2026-09-23 11:15:27.221077+00	2026-10-03 22:21:01.609+00	new	\N	\N		\N	\N		warm	\N		2026-09-23 11:15:27.221077+00	individual	\N				\N	\N
48	0	0	ALHUSSEINI	2	2026-10-05 07:20:06.761+00	2026-10-06 07:10:37.517+00	2026-10-05 07:20:06.901658+00	2026-10-06 07:10:37.517+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-10-05 07:20:06.901658+00	individual	\N	\N	\N	\N	\N	\N
46	مبارك مبخوت	0551119244	ALHUSSEINI	1	2026-10-02 11:43:19.215+00	2026-10-02 11:43:19.215+00	2026-10-02 11:43:19.283521+00	2026-10-12 17:46:47.675+00	lost	slightly_high	no_response		2026-10-04	\N	م محمود الحسيني	hot	\N	WAE	2026-10-02 11:43:19.283521+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
47	مطلق الدوسري - الافلاج	0555247459	ALHUSSEINI	3	2026-10-04 12:58:35.262+00	2026-10-13 10:33:33.618+00	2026-10-04 12:58:35.493537+00	2026-10-13 10:33:33.618+00	won	\N	\N		2026-10-11	\N		hot	\N		2026-10-04 12:58:35.493537+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
52	محمود عظوم	0541206995	ALHUSSEINI	2	2026-10-15 10:44:39.528+00	2026-10-15 10:45:17.943+00	2026-10-15 10:44:39.638049+00	2026-10-15 10:45:17.943+00	contacted	\N	\N	\N	\N	\N	\N	hot	\N	\N	2026-10-15 10:44:39.638049+00	individual	\N	\N	\N	\N	\N	\N
50	0509406999	0509406999	ALHUSSEINI	3	2026-10-12 17:43:19.033+00	2026-10-15 14:55:12.703+00	2026-10-12 17:43:19.320284+00	2026-10-15 14:55:12.703+00	contacted	\N	\N	\N	\N	\N		warm	\N		2026-10-12 17:43:19.320284+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
\.


--
-- Data for Name: einvoice_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.einvoice_config (id, trial_mode) FROM stdin;
1	t
\.


--
-- Data for Name: einvoice_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.einvoice_counters (id, last_icv) FROM stdin;
1	12
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, expense_date, category, description, amount, tax_treatment, recurring_id, created_by, created_at) FROM stdin;
1	2026-10-01	rent	\N	2200.00	none	1	recurring	2026-10-24 23:58:22.087822+00
3	2026-10-01	salary	محمود الحسيني 	5000.00	none	2	recurring	2026-10-24 23:59:08.876309+00
6	2026-07-28	other	مشتريات من افكار-AFKAR.Co	575.00	recoverable	\N	treasury	2026-10-28 21:44:22.878787+00
8	2026-09-17	other	فاتورة 0006-6771 (اتشالت من المشروع)	14734.72	recoverable	\N	treasury	2026-10-28 23:56:31.023056+00
9	2026-06-30	other	فاتورة 26-06088730 (اتشالت من المشروع)	139001.65	recoverable	\N	treasury	2026-10-28 23:56:31.023056+00
\.


--
-- Data for Name: finance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_settings (id, vat_rate, reserve_pct, completed_statuses, updated_at) FROM stdin;
1	15	2.5	{commissioned,completed,handed_over,closed}	2026-10-24 23:53:32.987+00
\.


--
-- Data for Name: invoice_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_counters (counter_key, last_value) FROM stdin;
HEWDS20260922	3
HEWDS20260926	1
HEWCN20260926	1
HEWDS20260927	1
HEWDS20260930	1
HEWDS-INV-202609	1
HEWDS-INV-202610	9
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, project_id, customer_id, milestone_id, invoice_number, invoice_date, due_date, customer_name, customer_phone, customer_vat_number, customer_cr_number, items, discount_total, vat_percent, subtotal, vat_amount, total, status, notes, created_by, created_at, updated_at, invoice_type, rep_username, payment_method, paid_at, qr_base64, approval_status, approved_by, approved_at, customer_address, source_quotation_id, issued_at, document_type, related_invoice_id, reason, source_calc_quote_id, icv, uuid, invoice_hash, previous_invoice_hash, supply_date, seller_snapshot) FROM stdin;
\.


--
-- Data for Name: maintenance_contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_contracts (id, customer_id, project_id, contract_number, start_date, end_date, contract_value, visits_per_year, next_visit_date, responsible_engineer, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opportunities (id, customer_id, site_id, contact_id, name, project_type, stage, stage_changed_at, estimated_capacity, estimated_value, expected_cost, probability, expected_closing_date, sales_person, competitor_name, competitor_price, lost_reason, next_action, next_follow_up_date, notes, created_at, updated_at, segment) FROM stdin;
13	50	\N	\N	عرض سعر 20 حصان	solar_pumping	quotation_sent	2026-10-12 17:43:19.525224+00	20	27638	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-15	أُنشئت تلقائيًا من عرض السعر QL-202610-0007	2026-10-12 17:43:19.525224+00	2026-10-12 17:43:19.525224+00	medium
14	47	\N	\N	عرض سعر 40 حصان	solar_pumping	quotation_sent	2026-10-13 09:51:55.208547+00	40	51679	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-16	أُنشئت تلقائيًا من عرض السعر QL-202610-0009	2026-10-13 09:51:55.208547+00	2026-10-13 09:51:55.208547+00	medium
15	51	\N	\N	عرض سعر 10 حصان	solar_pumping	quotation_sent	2026-10-13 15:46:19.758044+00	10	9822	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-16	أُنشئت تلقائيًا من عرض السعر QL-202610-0010	2026-10-13 15:46:19.758044+00	2026-10-13 15:46:19.758044+00	small
2	11	\N	\N	مزرعه حاظر ابو مشلح علي طريق مجدل	solar_pumping	won	2026-08-12 06:19:27.819+00	200	175000	174000	100	\N	م محمود الحسيني	\N	\N	\N		\N		2026-08-10 16:27:57.139902+00	2026-08-12 06:19:27.819+00	medium
3	9	\N	\N	صفقة - عرض 2026-08-03	solar_pumping	won	2026-08-12 06:27:16.295+00	100	95000	\N	\N	\N		\N	\N	\N		\N		2026-08-12 06:26:19.314255+00	2026-08-12 06:27:16.295+00	medium
4	9	\N	\N	الشيخ حمود بن ناصر 50 حصان	solar_pumping	won	2026-08-12 11:30:37.981+00	50	50000	\N	100	\N	م محمود الحسيني	\N	\N	\N		\N		2026-08-12 11:30:23.072797+00	2026-08-12 11:30:37.981+00	medium
1	12	\N	\N	مبارك ابو فاضل الدوسري 125hp	solar_pumping	won	2026-08-10 16:25:41.013+00	125	175000	161000	100	2026-08-01	م محمود الحسيني	\N	\N	\N		\N		2026-08-08 17:43:49.848416+00	2026-08-12 11:31:40.753+00	medium
5	12	\N	\N	مبارك ابو فاضل الدوسري 60hp	solar_pumping	won	2026-08-12 11:33:14.581+00	60	85000	\N	100	2026-04-11	م محمود الحسيني	\N	\N	\N		\N		2026-08-12 11:32:41.454325+00	2026-08-12 11:45:13.875+00	medium
7	26	\N	\N	صفقة - عرض 2026-08-16	solar_pumping	won	2026-08-16 16:20:07.568+00		10925	10402	100	2026-08-16	م محمود الحسيني	\N	\N	\N		2026-08-18		2026-08-16 16:17:08.743423+00	2026-08-16 16:20:07.568+00	\N
8	12	\N	\N	صفقة - عرض 2026-09-23	solar_pumping	won	2026-09-23 11:52:49.768+00	20	21000	\N	100	2026-10-15	م  محمود الحسيني	\N	\N	\N		\N		2026-09-23 11:52:04.236887+00	2026-09-23 11:52:49.768+00	medium
9	9	\N	\N	60HP UPGRADE TO 100HP	solar_pumping	won	2026-09-23 11:57:05.198+00	60	52000	\N	100	2026-09-18	م  محمود الحسيني	\N	\N	\N		\N		2026-09-23 11:56:42.603889+00	2026-09-23 11:57:05.198+00	medium
16	52	\N	\N	عرض سعر 500 حصان	solar_pumping	quotation_sent	2026-10-15 10:44:39.707939+00	500	500137	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-17	أُنشئت تلقائيًا من عرض السعر QL-202610-0012	2026-10-15 10:44:39.707939+00	2026-10-15 10:44:39.707939+00	large
17	53	\N	\N	عرض سعر 100 حصان	solar_pumping	quotation_sent	2026-10-16 13:30:55.598392+00	100	97135	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-19	أُنشئت تلقائيًا من عرض السعر QL-202610-0014	2026-10-16 13:30:55.598392+00	2026-10-16 13:30:55.598392+00	medium
18	54	\N	\N	عرض سعر 60 حصان	solar_pumping	quotation_sent	2026-10-19 05:35:21.479757+00	60	55117	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-22	أُنشئت تلقائيًا من عرض السعر QL-202610-0015	2026-10-19 05:35:21.479757+00	2026-10-19 05:35:21.479757+00	medium
19	9	\N	\N	صفقة - عرض 2026-10-25	solar_pumping	won	2026-10-25 08:33:40.445+00	200	201000	\N	100	2026-10-26	م محمود الحسيني	\N	\N	\N		\N		2026-10-25 08:31:15.137147+00	2026-10-27 11:19:01.513+00	medium
20	9	\N	\N	عرض سعر 200 حصان	solar_pumping	quotation_sent	2026-10-27 11:39:56.81135+00	200	201000	\N	\N	\N	م محمود الحسيني	\N	\N	\N	متابعة العرض مع العميل	2026-10-30	أُنشئت تلقائيًا من عرض السعر QL-202610-0006-R4	2026-10-27 11:39:56.81135+00	2026-10-27 11:42:15.109+00	medium
\.


--
-- Data for Name: partner_distributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partner_distributions (id, partner_id, amount, distribution_date, kind, notes, created_at) FROM stdin;
\.


--
-- Data for Name: partner_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partner_shares (id, partner_id, share_pct, effective_from, effective_to, created_at) FROM stdin;
1	1	50	2000-01-01	2026-10-23	2026-10-24 23:27:25.261471+00
3	1	50	2026-10-24	\N	2026-10-24 23:44:10.66567+00
2	2	50	2000-01-01	2026-10-23	2026-10-24 23:27:25.261471+00
4	2	50	2026-10-24	\N	2026-10-24 23:44:10.71661+00
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partners (id, name, active, notes, created_at) FROM stdin;
1	محمود الحسيني	t	\N	2026-10-24 23:27:25.261471+00
2	مبارك محمد ابو فاضل	t	\N	2026-10-24 23:27:25.261471+00
\.


--
-- Data for Name: payment_edits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_edits (id, payment_id, project_id, old_amount, new_amount, old_date, new_date, reason, edited_by, edited_at) FROM stdin;
2	9	5	175000.00	175000.00	2026-10-25	2026-06-29	التاريخ السابق خاطئ	admin	2026-10-26 06:52:37.040826+00
\.


--
-- Data for Name: payment_milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_milestones (id, project_id, title, percentage, amount, due_date, status, notes, created_at, updated_at) FROM stdin;
6	8	52000	100	52000	2026-09-16	paid	\N	2026-09-23 11:58:59.756319+00	2026-09-23 11:59:06.566+00
8	2	دفعة قبل التوريد	100	85000	\N	paid	\N	2026-10-25 00:01:29.680407+00	2026-10-25 00:01:38.968+00
9	5	دفعة قبل التوريد	100	175000	\N	paid	\N	2026-10-25 00:01:56.032907+00	2026-10-25 00:01:59.953+00
10	10	دفعة قبل التوريد	35.7	70000	\N	paid	\N	2026-10-25 08:38:21.006602+00	2026-10-25 08:40:18.225+00
11	10	قبل التوريد	\N	74000	\N	paid	\N	2026-10-25 08:39:16.147835+00	2026-10-25 08:40:20.001+00
7	7	21000	100	21000	2026-09-16	paid	\N	2026-09-23 12:04:47.4122+00	2026-10-25 08:48:35.231+00
13	4	دفعة قبل التوريد	47.37	45000	\N	paid	\N	2026-10-25 23:19:15.73049+00	2026-10-25 23:19:24.278+00
14	4	سند لأمر	\N	50000	2026-11-01	pending	\N	2026-10-25 23:20:10.796019+00	2026-10-25 23:20:10.796019+00
5	6	عند الاستلام	\N	5706	2026-08-18	pending	\N	2026-08-18 20:16:50.348887+00	2026-10-26 21:43:42.05632+00
2	6	مقدم	\N	5000	2026-08-16	pending	\N	2026-08-16 16:21:16.232064+00	2026-10-26 21:44:35.394499+00
16	1	دفعة قبل التوريد	57.14	100000	\N	pending	\N	2026-10-28 22:42:00.545627+00	2026-10-28 22:42:00.545627+00
17	1	0	\N	75000	\N	pending	\N	2026-10-28 22:42:22.725667+00	2026-10-28 22:42:22.725667+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, project_id, amount, payment_date, method, notes, created_at, milestone_id, auto_created) FROM stdin;
5	7	5403	2026-09-20	\N	تحويل الي فيتشي	2026-09-23 12:09:18.87058+00	\N	f
6	7	14570	2026-09-23	bank_transfer	مباشر الي اشراق	2026-09-23 12:11:03.976001+00	\N	f
15	3	55000	2026-08-12	bank_transfer	\N	2026-10-25 23:17:49.311599+00	\N	f
13	2	85000	2026-03-15	bank_transfer	\N	2026-10-25 16:51:49.629304+00	8	f
16	4	45000	2026-08-13	bank_transfer	\N	2026-10-25 23:19:00.036714+00	13	f
9	5	175000.00	2026-06-29	bank_transfer	\N	2026-10-25 00:03:50.342179+00	9	f
4	8	52000	2026-09-16	bank_transfer	\N	2026-09-23 12:02:47.185466+00	6	f
10	10	70000	2026-10-25	bank_transfer	\N	2026-10-25 08:40:37.408538+00	10	f
11	10	74000	2026-10-25	bank_transfer	\N	2026-10-25 08:40:55.323812+00	11	f
21	6	5706.00	2026-08-18	bank_transfer	\N	2026-10-26 21:43:25.904626+00	\N	f
22	6	5000.00	2026-08-16	bank_transfer	\N	2026-10-26 21:44:22.959185+00	\N	f
23	10	40000.00	2026-10-27	bank_transfer	\N	2026-10-27 11:17:12.565262+00	\N	f
24	10	17000.00	2026-10-28	bank_transfer	\N	2026-10-28 12:25:55.447362+00	\N	f
26	1	175000.00	2026-08-01	bank_transfer	\N	2026-10-28 22:44:13.088906+00	\N	f
\.


--
-- Data for Name: pricing_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pricing_config (id, data, updated_at) FROM stdin;
1	{"vat": 0.15, "feas": {"psh": 5.5, "years": 30, "gridPrice": 0.22, "dieselPrice": 1.79, "gridEscalationPct": 8, "solarOMPctOfCapex": 1, "co2FactorKgPerLiter": 2.68, "dieselEscalationPct": 5, "panelDegradationPct": 0.65, "dieselConsumptionPerKWh": 0.25}, "ongrid": {"panelIdx": 0, "sunHours": 5.5, "tariffRate": 0.18, "cablingFixedCost": 700, "cablingFixedSell": 1200, "installPerKwCost": 250, "installPerKwSell": 450, "performanceRatio": 0.8, "inverterMarkupPct": 20, "netMeteringFeeCost": 500, "netMeteringFeeSell": 900, "structurePerPanelCost": 110, "structurePerPanelSell": 170}, "panels": [{"isc": 15.45, "voc": 55.2, "iimp": 14.75, "vimp": 45.09, "brand": "Aiko", "image": "https://aikosolar.com/wp-content/uploads/2025/12/Stellar-3Nplus72-1272-514.jpg", "power": 665, "specs": {"Imp (STC)": "14.75 أمبير", "Isc (STC)": "15.45 أمبير", "Vmp (STC)": "45.09 فولت", "Voc (STC)": "55.20 فولت", "النوع": "ثنائي الوجه (Bifacial)", "الوزن": "32.2 كجم", "الإطار": "ألومنيوم أنودايز", "الزجاج": "مزدوج 2.0+2.0مم شبه مقسّى", "الوصلة": "MC4 Compatible / MC4-EVO2A", "الأبعاد": "2382×1134×30 مم", "نوع الخلية": "N-Type ABC (Back Contact)", "الكفاءة (STC)": "24.6%", "ضمان المنتج": "15 سنة", "عدد الخلايا": "144 (6×24)", "معامل حرارة Pmax": "-0.26%/°م", "أقصى جهد للنظام": "DC 1500V", "ضمان الأداء الخطي": "30 سنة", "درجة حرارة التشغيل": "-40°م إلى +70°م"}, "priceW": 0.55, "visible": false, "description": "لوح Aiko Stellar 3N+72 ثنائي الزجاج وثنائي الوجه (Bifacial)، تقنية N-Type ABC (Back Contact)، من عائلة موديلات 650-685 واط — بكفاءة تصل حتى 24.6%، وضمان منتج 15 سنة وضمان أداء خطي 30 سنة.", "datasheetUrl": "https://aikosolar.com/wp-content/uploads/2026/06/Stellar-3NPlus72-AIKO-A-MDE72Dw_650-685W-2382%C3%971134%C3%9730_202603_V2.1_EN.pdf", "internalNote": "AIKO-A665-MDE72Dw — القيم الكهربائية مطابقة للداتا شيت الرسمي (إصدار 202603_V2.1_EN). خط منتج مختلف عن Stellar 1N+ (635-660W): هذا Bifacial ومدى حرارة تشغيله أضيق (-40° إلى +70°م بدل -40° إلى +85°م). للاستخدام الداخلي فقط — لا يظهر للمناديب أو العملاء."}, {"isc": 15.06, "voc": 54, "iimp": 14.35, "vimp": 45.3, "brand": "Aiko", "image": "https://aikosolar.com/wp-content/uploads/2024/03/Stellar-series-1Nplus_Polaris-detail.jpg", "power": 650, "priceW": 0, "visible": false, "datasheetUrl": "https://aikosolar.com/wp-content/uploads/2025/10/Stellar-1N_192.5-AIKO-G-MCH72Dw-635-660W_2382x1134x30mm_V4.1_202510_DsDr_EN.pdf"}, {"isc": 16.15, "voc": 48.7, "iimp": 15.45, "vimp": 40.45, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 595, "priceW": 0, "visible": false, "datasheetUrl": "https://jasolar.com/uploadfile/fujian/2024/1120/eafad230aca62a5.pdf"}, {"isc": 13.99, "voc": 52.58, "iimp": 13.333, "vimp": 44.64, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 620, "priceW": 0.55, "visible": false, "datasheetUrl": "https://www.enfsolar.com/pv/panel-datasheet/crystalline/66270"}, {"isc": 13.99, "voc": 52.58, "iimp": 13.333, "vimp": 44.64, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 630, "priceW": 0, "visible": false, "datasheetUrl": "https://www.enfsolar.com/pv/panel-datasheet/crystalline/66270"}, {"isc": 16.14, "voc": 48.09, "iimp": 15.33, "vimp": 39.79, "brand": "TRINA", "image": "https://www-cdn.trinasolar.com/wwwstorage/sites/17/635W-TSM-NEG19RC20.png", "power": 610, "priceW": 0.49, "visible": false, "datasheetUrl": "http://static.trinasolar.com/sites/default/files/Vertex_NEG19RC.20_EN_2023_APAC_B_web.pdf"}, {"isc": 16.05, "voc": 48.78, "iimp": 15.16, "vimp": 40.91, "brand": "Longi", "image": "https://static.longi.com/Hi_MO_9_8f7fb3dbfe.png", "power": 620, "priceW": 0.5, "visible": false, "datasheetUrl": "https://static.longi.com/2_LR_7_72_HGD_585_620_M_V2_30_30_and_15_V05_EN_c6514bcafc.pdf"}, {"isc": 18.55, "voc": 49.28, "iimp": 17.55, "vimp": 41.03, "brand": "TW", "power": 720, "priceW": 0.55, "visible": false}, {"isc": 16.04, "voc": 50.44, "iimp": 15.34, "vimp": 42.7, "brand": "Jinko", "power": 645, "priceW": 0.56, "visible": false}, {"isc": 18.55, "voc": 48.8, "iimp": 17.44, "vimp": 41, "brand": "JA", "power": 715, "priceW": 0.56, "visible": false}, {"isc": 15.39, "voc": 55.1, "iimp": 14.68, "vimp": 45.09, "brand": "Aiko", "power": 660, "priceW": 0.56, "visible": false}, {"isc": 16.64, "voc": 58.72, "iimp": 15.79, "vimp": 48.77, "brand": "Aiko", "power": 770, "priceW": 0.6, "visible": true}, {"isc": 18.67, "voc": 49.4, "iimp": 17.56, "vimp": 41.58, "brand": "JA", "power": 730, "priceW": 0.56, "visible": true}, {"isc": 18.81, "voc": 49.36, "iimp": 17.79, "vimp": 41.11, "brand": "Jinko", "power": 730, "priceW": 0.56, "visible": true}], "offgrid": {"panelIdx": 0, "sunHours": 6, "batteryDoD": 0.8, "cartExtras": {"elec": {"mode": "variable", "unit": "panel", "price": 30, "repEdit": false}, "civil": {"mode": "variable", "unit": "panel", "price": 40, "repEdit": false}, "transport": {"mode": "variable", "unit": "trip", "price": 200, "minimum": 2000, "repEdit": false, "kwPerTrip": 20}}, "appliancePresets": [{"name": "لمبة إضاءة LED", "watts": 10, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "DVR / NVR", "watts": 25, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "راوتر / شاحن", "watts": 15, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "كاميرا مراقبة", "watts": 10, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "لابتوب", "watts": 65, "dayHours": 6, "nightHours": 0, "surgeMultiplier": 1}, {"name": "مروحة", "watts": 70, "dayHours": 4, "nightHours": 6, "surgeMultiplier": 3}, {"name": "شفاط مطبخ", "watts": 75, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 3}, {"name": "تلفاز LCD / كاميرات CCTV", "watts": 60, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "تلفاز LCD", "watts": 80, "dayHours": 3, "nightHours": 3, "surgeMultiplier": 1}, {"name": "ثلاجة", "watts": 150, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 5}, {"name": "كشاف إنارة", "watts": 200, "dayHours": 0, "nightHours": 12, "surgeMultiplier": 1}, {"name": "فريزر", "watts": 200, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 5}, {"name": "موتور 1 حصان", "watts": 740, "dayHours": 0.25, "nightHours": 2, "surgeMultiplier": 5}, {"name": "ميكروويف", "watts": 1000, "dayHours": 1, "nightHours": 1, "surgeMultiplier": 1}, {"name": "موتور 1.5 حصان / غاطس", "watts": 1100, "dayHours": 2, "nightHours": 0.5, "surgeMultiplier": 5}, {"name": "تكييف 1.5 حصان", "watts": 1100, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "غسالة", "watts": 1500, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 3}, {"name": "تكييف 2.5 حصان", "watts": 1800, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "تكييف 3 حصان", "watts": 2200, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "هيتر مياه", "watts": 9000, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 1}], "batteryMarkupPct": 10, "cablingFixedCost": 800, "cablingFixedSell": 1400, "installPerKwCost": 300, "installPerKwSell": 500, "systemEfficiency": 0.85, "applianceDefaults": [{"qty": 1, "name": "ثلاجة", "watts": 150, "dayHours": 4, "nightHours": 4}, {"qty": 10, "name": "إضاءة LED", "watts": 10, "dayHours": 0, "nightHours": 6}, {"qty": 1, "name": "تلفزيون", "watts": 120, "dayHours": 2, "nightHours": 3}, {"qty": 1, "name": "مروحة/تكييف نافذة", "watts": 900, "dayHours": 3, "nightHours": 3}, {"qty": 1, "name": "مضخة مياه منزلية", "watts": 750, "dayHours": 1, "nightHours": 0}], "inverterMarkupPct": 10, "inverterSurgeRatio": 2, "defaultAutonomyDays": 0, "structurePerPanelCost": 120, "structurePerPanelSell": 180, "nightLoadRatioFallback": 0.5, "inductiveSurgeMultiplier": 3}, "cbLadder": [32, 63, 80, 100, 125, 160, 200, 250], "discounts": [{"brand": "VEICHI", "category": "شواحن/انفرترات هجين MPPT", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "SINOBOLY", "category": "بطاريات ليثيوم", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "بطاريات ليثيوم", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "الريأكتور (Reactor)", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -20, "supplierDiscountPct": 1}, {"brand": "VEICHI", "category": "صناديق التجميع (Combiner Box)", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "الكابلات والوصلات (MC4)", "promoActive": true, "sellDiscountPct": -30, "promoDiscountPct": -30, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "قواطع وفيوزات DC", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "انفرتر مضخات VEICHI", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": 0, "supplierDiscountPct": 10}, {"brand": "Aiko", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -10, "supplierDiscountPct": 0}, {"brand": "Jinko", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -10, "supplierDiscountPct": 0}, {"brand": "JA", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -10, "supplierDiscountPct": 0}, {"brand": "TW", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -10, "supplierDiscountPct": 0}], "portfolio": {"hero": {"image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/2a2d2198-8f86-4314-9578-e07ca96e2fc6.jpg", "title": "بورتفوليو حلول الطاقة", "description": "حلول EPC متخصصة في أنظمة الري الزراعي بالطاقة الشمسية داخل المملكة، مبنية على خبرة هندسية في مصر ومشاريع منفذة في وادي الدواسر."}, "kpis": [{"l": "مشاريع منفذة في السعودية", "v": "5"}, {"l": "نطاق قدرات الري المنفذة", "v": "60-500 HP"}, {"l": "هندسة، توريد، تنفيذ، تشغيل", "v": "EPC"}, {"l": "تشغيل داخل المملكة", "v": "2026"}], "partners": [{"img": "assets/portfolio/partner-sunarabia.png", "name": "SUNARABIA"}, {"img": "assets/portfolio/partner-afkarco.png", "name": "AFKARCO"}, {"img": "assets/portfolio/partner-veichi.png", "name": "VEICHI"}, {"img": "assets/portfolio/partner-risen.png", "name": "RISEN"}, {"img": "assets/portfolio/partner-ja-solar.png", "name": "JA Solar"}, {"img": "assets/portfolio/partner-leader.png", "name": "LEADER"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/4f8a3bb0-65a5-4a0d-be0c-b4d62a0dadc8.webp", "name": "SUNGROW"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a0170a92-5a2c-41d5-a1c5-37f0df8df7aa.jpg", "name": "HUAWEI"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/52f9727d-ce5b-4d72-ad68-6a61026bf413.webp", "name": "AIKO"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ac49468e-2a0d-4683-8e56-525dff5440d7.png", "name": "KAYAL"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/2b736448-1519-4a9e-a2d2-b51a46e6a65a.webp", "name": "TONGWEI"}], "projects": [{"hp": "500 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/d21592fc-8ad7-4cab-b173-c2523c14ea44.jpg", "desc": "مشروع عالي القدرة لتقليل تكلفة تشغيل مضخات الديزل وتحسين استقرار التشغيل.", "tags": ["استثمار 720000 ريال", "استرداد تقريبي 10 أشهر"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "200 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/27a05e2f-2e03-4bd5-a02b-38159daa5f68.jpg", "desc": "تصميم وتنفيذ منظومة ضخ شمسي بقدرة متوسطة لخدمة احتياج ري يومي مستمر.", "tags": ["EPC", "تشغيل زراعي"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "125 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fbfce0c4-66f4-4858-bf4e-febfbf5210e9.jpg", "desc": "حل هندسي موجه للمزارع التي تحتاج تكلفة طاقة يمكن التنبؤ بها على المدى الطويل.", "tags": ["تصميم", "توريد وتركيب"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "60 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a4d90276-6b7b-46ed-b9b4-c2581fa59248.jpg", "desc": "حالة أعمال حققت تخفيضًا ملموسًا في تكلفة الوقود الشهرية للمزرعة.", "tags": ["استثمار 85000 ريال", "استرداد تقريبي 9 أشهر"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "60 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/0e75273a-34c4-46c1-914c-532316ff70f9.jpg", "desc": "تنفيذ منظومة شمسية للري مع اختبار وتشغيل وتسليم فني للموقع.", "tags": ["اختبار وتشغيل", "دعم فني"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}], "roiCases": [{"l": "تكلفة ديزل شهرية 10-12 ألف ريال، استرداد تقريبي 9 أشهر.", "v": "60 HP"}, {"l": "تكلفة ديزل شهرية تقارب 75 ألف ريال، استرداد تقريبي 10 أشهر.", "v": "500 HP"}, {"l": "تكلفة ديزل شهرية 30 ألف ريال، استرداد تقريبي 10 أشهر.", "v": "200 HP"}, {"l": "تكلفة ديزل شهرية 20 ألف ريال، استرداد تقريبي 9 أشهر.", "v": "125 HP"}], "timeline": [{"desc": "تنفيذ مشاريع ري شمسي، Off-grid، ومشاريع تجارية وصناعية.", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/5ce39b7c-6394-4f45-9871-171479f81b06.jpg", "label": "الأصل", "title": "Alasl Solar - Egypt"}, {"desc": "تركيز عميق على أنظمة الضخ والري من 30 HP إلى 500 HP.", "image": null, "label": "النمو", "title": "تخصص زراعي"}, {"desc": "تأسيس وتشغيل في المملكة مع مشاريع منفذة في وادي الدواسر.", "image": null, "label": "2026", "title": "Holoul Energy KSA"}], "panelNote": "نقيس نجاح المشروع بالعائد الذي يحققه للعميل، وليس بعدد الألواح فقط. هدفنا تقليل تكلفة التشغيل، رفع الاعتمادية، وبناء أصل طويل الأجل للمزرعة.", "panelTitle": "Engineering Value Beyond Solar", "projectsTag": "وادي الدواسر - 2026", "businessCases": [{"hp": "60 HP", "place": "وادي الدواسر — ري زراعي — 2026", "title": "منظومة ري زراعي بالطاقة الشمسية", "diesel": "10,000–12,000 ريال", "payback": "≈ 9 أشهر", "results": ["التخلص من معظم تكلفة الديزل الشهرية", "تقليل احتياجات الصيانة ومخاطر التوقف", "إزالة التعرض لارتفاع أسعار الديزل مستقبلًا", "تحقيق فترة استرداد خلال ٩ أشهر تقريبًا"], "investment": "85,000 ريال"}, {"hp": "500 HP", "place": "وادي الدواسر — ري زراعي — 2026", "title": "منظومة ري زراعي بالطاقة الشمسية", "diesel": "≈ 75,000 ريال", "payback": "≈ 10 أشهر", "results": ["خفض ملموس في تكلفة التشغيل الشهرية", "انخفاض عبء الصيانة على أسطول المضخات", "تقليل المخاطر التشغيلية المرتبطة بتوريد الديزل", "استرداد رأس المال خلال ١٠ أشهر تقريبًا"], "investment": "720,000 ريال"}], "projectsTitle": "مشاريع منفذة في المملكة", "capabilitySteps": [{"l": "Survey ودراسة الموقع", "v": "01"}, {"l": "تصميم هندسي وتحجيم النظام", "v": "02"}, {"l": "توريد من شركاء موثوقين", "v": "03"}, {"l": "تركيب واختبارات حماية", "v": "04"}, {"l": "Commissioning وتسليم", "v": "05"}, {"l": "دعم فني وتشغيل وصيانة", "v": "06"}]}, "mc4PerUnit": 5, "cableMarkup": 1.3, "cablePerMeter": 4, "combinerBoxes": [[4, 749], [8, 949], [10, 1149], [16, 1649], [22, 2649], [30, 3849], [34, 4598], [38, 4798], [40, 4998], [46, 5498], [50, 6147], [56, 6647], [60, 7698], [64, 8447], [68, 8647], [70, 8847], [76, 9347], [90, 11547]], "discountTiers": [{"label": "بدون خصم", "factor": 0}, {"label": "خصم عميل مزرعة", "factor": 0.2}, {"label": "خصم عميل مشروع زراعي", "factor": 0.4}, {"label": "خصم عميل شركات", "factor": 0.6}, {"label": "خصم خاص", "factor": 0.8}], "reactorLadder": [50, 80, 100, 160, 315, 450, 560, 1000], "reactorPrices": {"50": 389, "80": 479, "100": 499, "160": 599, "315": 999, "450": 1374, "560": 4899, "1000": 5799}, "stringsAdjust": 0, "batteryCatalog": [{"model": "VCLB-1.2K-100-Li", "voltage": "12.8V", "capacityWh": 1280, "priceExclVat": 782}, {"model": "VCLB-2.5K-200-Li", "voltage": "12.8V", "capacityWh": 2560, "priceExclVat": 1100}, {"model": "VCLB-2.5K-100-Li", "voltage": "25.6V", "capacityWh": 2560, "priceExclVat": 1100}, {"model": "VCLB-5.1K-200-Li", "voltage": "25.6V", "capacityWh": 5120, "priceExclVat": 2100}, {"model": "VCLB-5k-w01", "voltage": "51.2V", "capacityWh": 5120, "priceExclVat": 2609}, {"model": "VCLB-10k-w02", "voltage": "51.2V", "capacityWh": 10240, "priceExclVat": 4500}, {"model": "VCLB-15k-BC", "voltage": "51.2V", "capacityWh": 14336, "priceExclVat": 5652}], "productCatalog": [{"rows": [["VCLB-1.2K-100-Li", "100A", "12.8V", "782", "899.30"], ["VCLB-2.5K-200-Li", "200A", "12.8V", "1100.00", "1265.00"], ["VCLB-2.5K-100-Li", "100A", "25.6V", "1100.00", "1265.00"], ["VCLB-5.1K-200-Li", "200A", "25.6V", "2100.00", "2415.00"], ["VCLB-5k-w01", "100A", "51.2V", "2609.00", "3000.35"], ["VCLB-10k-w02", "200A", "51.2V", "4500.00", "5175.00"], ["VCLB-15k-BC", "280A", "51.2V", "5652.00", "6499.80"], ["Sinoboly-200A-25.1Vs", "200A", "25.1", "2600", "2847.62"], ["Sinoboly-200A-51V", "200A", "51", "4500", "5175"], ["Sinoboly-628A-51V", "628A", "51", "10500", "12075"]], "columns": ["الموديل", "التيار", "الفولت", "السعر", "السعر شامل الضريبة"], "category": "بطاريات ليثيوم", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/f3d8a8eb-d1a4-4f20-b564-7ce7aa006144.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "7.5 كجم", "أقصى جهد شحن": "14.6 فولت", "الجهد الاسمي": "12.8 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "100A", "السعة الاسمية": "100Ah (1280Wh)", "الأبعاد (ط×ع×ا)": "260×168×211 مم", "جهد قطع التفريغ": "10.8 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "100A", "ذروة تيار التفريغ": "200A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "50A"}, "available": true, "description": "بطارية ليثيوم حديد فوسفات (LiFePO4) بجهد 12.8 فولت، بتصميم خفيف الوزن (ثلث وزن بطارية الرصاص الحمضية المكافئة) وسعة استخدام كاملة 100%، مناسبة للتطبيقات البحرية والمقطورات (RV) والأنظمة المنفصلة عن الشبكة.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "22 كجم", "أقصى جهد شحن": "14.6 فولت", "الجهد الاسمي": "12.8 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "200A", "السعة الاسمية": "200Ah (2560Wh)", "الأبعاد (ط×ع×ا)": "484×168×240 مم", "جهد قطع التفريغ": "10.8 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "200A", "ذروة تيار التفريغ": "400A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 12.8 فولت وسعة أعلى (200Ah)، من نفس عائلة VCLB خفيفة الوزن، مناسبة للتطبيقات البحرية والمقطورات والأنظمة المنفصلة عن الشبكة التي تحتاج طاقة تخزين أكبر.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "22 كجم", "أقصى جهد شحن": "29.2 فولت", "الجهد الاسمي": "25.6 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "100A", "السعة الاسمية": "100Ah (2560Wh)", "الأبعاد (ط×ع×ا)": "484×168×240 مم", "جهد قطع التفريغ": "21.6 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "100A", "ذروة تيار التفريغ": "200A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "50A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 25.6 فولت (24 فولت اسمي)، بنفس مزايا عائلة VCLB — وزن خفيف وسعة استخدام كاملة، مناسبة لأنظمة 24 فولت المنفصلة عن الشبكة.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "37 كجم", "أقصى جهد شحن": "29.2 فولت", "الجهد الاسمي": "25.6 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "200A", "السعة الاسمية": "200Ah (5120Wh)", "الأبعاد (ط×ع×ا)": "520×267×220 مم", "جهد قطع التفريغ": "21.6 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "200A", "ذروة تيار التفريغ": "400A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 25.6 فولت وسعة أعلى (200Ah)، مناسبة لأنظمة 24 فولت المنفصلة عن الشبكة التي تحتاج طاقة تخزين أكبر.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/086a486b-8d0e-4b73-a891-0aa9aa01ec26.jpg", "specs": {"الوزن": "47.2 كجم", "الأبعاد": "520×470×141.5 مم", "الاتصال": "RS232 / CAN / RS485", "التوازي": "حتى 15 وحدة", "عمر الدورة": "6000 دورة عند 80% عمق تفريغ", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "جهد قطع الشحن": "56.16 فولت", "السعة الاسمية": "100Ah (5120Wh)", "جهد قطع التفريغ": "45.6 فولت", "تيار الشحن الموصى به": "50A (0.5C)", "أقصى تيار تفريغ مستمر": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت (48 فولت اسمي) بتصميم تركيب حائطي جديد، تدعم توصيل حتى 15 وحدة على التوازي لزيادة السعة، مزودة بشاشة LED لحالة الشحن، ومناسبة لأنظمة التخزين المنزلية والتجارية الصغيرة.", "datasheetUrl": "https://www.veichi.com/product/vclb-5k-w01-rechargeable-lithium-ion-battery.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/e1f16aac-3a5f-428b-83cc-aec4d5923a61.jpg", "specs": {"الوزن": "96.5 كجم", "الأبعاد": "800×590×142 مم", "الاتصال": "RS232 / CAN / RS485", "التوازي": "حتى 15 وحدة", "عمر الدورة": "6000 دورة عند 80% عمق تفريغ", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "جهد قطع الشحن": "56.16 فولت", "السعة الاسمية": "200Ah (10240Wh)", "جهد قطع التفريغ": "45.6 فولت", "تيار الشحن الموصى به": "100A (0.5C)", "أقصى تيار تفريغ مستمر": "200A", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "VCLB-10K-W01"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت وسعة أعلى (200Ah)، بنفس تصميم التركيب الحائطي وشاشة LED، تدعم حتى 15 وحدة على التوازي.", "datasheetUrl": "https://www.veichi.com/product/vclb-10k-w01-rechargeable-lithium-ion-battery.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/f8caafa9-9421-4542-afd0-be488f3b4bd0.jpg", "specs": {"الوزن": "128.9 كجم", "الأبعاد": "800×500×227 مم", "الاتصال": "CAN / RS485 / RS232", "التوازي": "حتى 16 وحدة (حتى 229 كيلوواط/ساعة)", "ذروة تفريغ": "250A لمدة 10 دقائق", "عمر الدورة": "6000 دورة عند 25°م", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "كثافة الطاقة": "حتى 166 واط/ساعة لكل كجم", "السعة الاسمية": "280Ah (14,336Wh)", "مدى جهد التشغيل": "46.4–57.6 فولت", "أقصى ارتفاع تشغيل": "3000 متر", "أقصى تيار شحن/تفريغ": "200A", "التيار الاسمي للشحن/التفريغ": "140A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت وسعة 280Ah، بخلايا من درجة EVE A+ ونظام حماية متعدد المستويات، تدعم التوازي حتى 16 وحدة (سعة إجمالية حتى 229 كيلوواط/ساعة)، ومتوافقة مع كل انفرترات 48 فولت التي تدعم بطاريات LFP.", "datasheetUrl": "https://www.veichi.com/product/vclb-15-bc-high-voltage-lithium-battery.html"}, "7": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "specs": {}, "available": true, "description": ""}, "8": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "available": true}, "9": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "available": true}}}, {"rows": [["SIS4-12V 1KW MPPT", "40A", "150 VDC", "449", "516.35"], ["SIS4-12V 2KW MPPT", "80A", "400 VDC", "699", "803.85"], ["SIS-24V 3KW MPPT", "100A", "450 VDC", "999", "1148.85"], ["SISV-24V 4.2KW (TWIN) MPPT", "120A", "500 VDC", "1049", "1206.35"], ["SIS 5KW-S MPPT", "100A", "500 VDC", "1149", "1321.35"], ["SISV 6.2KW (TWIN) MPPT", "120A", "500 VDC", "1199", "1378.85"], ["SISV 8KW (TWIN) MPPT", "120A", "500 VDC", "2299", "2643.85"], ["SISV 11KW (TWIN) MPPT", "150A", "500 VDC", "2499", "2873.85"], ["VLT 10KW 3P IP65", "220A", "800 VDC", "5899", "6783.85"], ["VLT 12KW 3P IP65", "250A", "800 VDC", "6399", "7358.85"], ["VLT 15KW 3P IP65", "290A", "800 VDC", "7499", "8623.85"], ["VHT 20KW IP65", "40A", "1000 VDC", "8499", "9773.85"], ["VHT 30KW IP65", "100A", "1000 VDC", "15499", "17823.85"], ["VHT 50KW IP65", "100A", "1000 VDC", "19499", "22423.85"], ["VCHB-61.4K-STF High Voltage Rack", "1C", "-", "43999", "50598.85"]], "columns": ["الموديل", "التيار (A)", "أقصى جهد DC", "السعر", "السعر شامل الضريبة"], "category": "شواحن/انفرترات هجين MPPT", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/0a14eac4-e583-4ff9-8522-e1ed8d054842.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "20–150 VDC", "الوزن الصافي": "3.5 كجم", "أقصى تيار شحن AC": "40A", "الأبعاد (ط×ع×ا)": "290×240×91 مم", "القدرة المقننة": "1000W / 1000VA", "أقصى تيار شحن شمسي": "40A", "زمن التحويل (Transfer Time)": "10ms", "أقصى قدرة ألواح مسموحة": "600W", "الاسم الرسمي عند فيتشي": "SIS4-1K-12-S", "ذروة الكفاءة (شمسي → خرج)": "98%", "ذروة الكفاءة (بطارية → خرج)": "94%"}, "available": true, "description": "شاحن/انفرتر MPPT مدمج لأنظمة التخزين المنزلية بجهد بطارية 12 فولت، بمخرج موجة جيبية نقية (Pure Sine Wave) وشاشة LCD ملونة، ويدعم التحكم عن بعد عبر تطبيق الجوال (واي فاي/GPRS).", "datasheetUrl": "https://www.veichi.com/product/off-grid-inverter/"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "30–400 VDC", "الوزن الصافي": "4.6 كجم", "منافذ الاتصال": "RS232 / GPRS / WIFI", "أقصى تيار شحن AC": "60A", "الأبعاد (ط×ع×ا)": "357×273×95 مم", "القدرة المقننة": "2000W / 1600W", "أقصى تيار شحن شمسي": "80A", "زمن التحويل (Transfer Time)": "10ms (كمبيوتر) / 20ms (أجهزة منزلية)", "أقصى قدرة ألواح مسموحة": "3000W", "الاسم الرسمي عند فيتشي": "SIS4-2K-12-S", "ذروة الكفاءة (شمسي → خرج)": "98%", "ذروة الكفاءة (بطارية → خرج)": "94%"}, "available": true, "description": "نفس عائلة SIS4 بقدرة أعلى (2 كيلوواط) وجهد دخول شمسي أوسع يصل حتى 400 فولت، مناسب لأنظمة تخزين منزلية أكبر تحتاج قدرة ألواح إضافية.", "datasheetUrl": "https://www.veichi.com/product/off-grid-inverter/"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "120–430 VDC", "التوازي (Parallel)": "حتى 9 وحدات", "أقصى تيار خرج AC": "13A", "القدرة المقننة": "3000W", "أقصى تيار دخول DC": "13A", "أقصى كفاءة تحويل (ربط شبكة)": "95%", "كفاءة (بطارية → تيار متردد)": "93%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SIS-3K-H"}, "available": true, "description": "انفرتر هجين (Hybrid) بقدرة 3 كيلوواط يدعم التوازي حتى 9 وحدات وإخراج موجة جيبية نقية، مناسب لأنظمة التخزين المنزلية متوسطة الحجم.", "datasheetUrl": "https://www.veichi.com/product/sis-hybrid-solar-inverter.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "18.2A", "أقصى تيار شحن AC": "100A", "القدرة المقننة": "4200W", "أقصى تيار دخول DC": "18A", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "120A", "جهد البطارية الاسمي": "24 / 48 فولت", "الاسم الرسمي عند فيتشي": "SISV-4.2K-H(TWIN)", "كفاءة (بطارية → تيار متردد)": "94%", "أقصى حمل ثانوي (وضع البطارية)": "1400W"}, "available": true, "description": "انفرتر هجين بمخرجين مستقلين (TWIN) يسمح بتغذية حملين مختلفين في نفس الوقت مع أولويات وجدولة يومية قابلة للبرمجة، ويعمل بجهد بطارية 24 أو 48 فولت.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6a9bbf1f-fee4-42f9-beb7-765129edebd4.jpg", "specs": {"مدى جهد MPPT": "120–430 VDC", "أقصى تيار شحن": "100A", "التوازي (Parallel)": "حتى 9 وحدات", "أقصى تيار خرج AC": "21.7A", "القدرة المقننة": "5000W", "أقصى تيار دخول DC": "27A", "جهد البطارية الاسمي": "48 فولت", "الاسم الرسمي عند فيتشي": "SIS-5K-H", "أقصى كفاءة تحويل (ربط شبكة)": "95%", "كفاءة (بطارية → تيار متردد)": "93%"}, "available": true, "description": "انفرتر هجين بقدرة 5 كيلوواط من نفس عائلة SIS، يدعم التوازي حتى 9 وحدات، مناسب للمنازل ذات الاستهلاك الأعلى.", "datasheetUrl": "https://www.veichi.com/product/sis-hybrid-solar-inverter.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "27A", "أقصى تيار شحن AC": "100–140A", "القدرة المقننة": "6200W", "أقصى تيار دخول DC": "22A", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "140A", "جهد البطارية الاسمي": "24 / 48 فولت", "الاسم الرسمي عند فيتشي": "SISV-6.2K-H(TWIN)", "كفاءة (بطارية → تيار متردد)": "94%"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN) بقدرة أعلى (6.2 كيلوواط)، مناسب لأحمال منزلية أكبر مع نفس مزايا الأولويات والجدولة القابلة للبرمجة.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "عدد متتبعات MPPT": "2", "أقصى تيار خرج AC": "35.6A", "أقصى تيار شحن AC": "100–140A", "القدرة المقننة": "8200W", "أقصى تيار دخول DC": "2×18A (متتبعين MPPT، 18A لكل متتبع)", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "140A", "جهد البطارية الاسمي": "24 / 48 فولت", "كفاءة (بطارية → تيار متردد)": "94%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SISV-8.2K-H(TWIN)"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN)، الطراز الرسمي المنشور بقدرة 8.2 كيلوواط (كتالوجك يذكره تقريبًا كـ 8 كيلوواط).", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "44.3A", "أقصى تيار شحن AC": "140A", "القدرة المقننة": "10200W", "أقصى تيار دخول DC": "2×18A (ثنائي تتبع MPPT)", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "160A", "جهد البطارية الاسمي": "24 / 48 فولت", "كفاءة (بطارية → تيار متردد)": "94%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SISV-10.2K-H(TWIN)"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN)، بأعلى قدرة في هذه السلسلة.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"اتصال": "واي فاي مدمج للمراقبة عن بُعد", "التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "عدد متتبعات MPPT": "2", "جهد بطارية اسمي": "40–62 VDC (وحدة نمطية)", "عدد أطوار الخرج": "3 أطوار (230VAC فاز-تعادل / 400VAC فاز-فاز)", "أقرب عائلة رسمية عند فيتشي": "VLT-12K-H/VLT-15K-H (نفس المنصة)", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "أقصى تيار خرج AC (طوارئ شبكة)": "40A", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65 (يعمل داخليًا وخارجيًا)، بمخرجين مستقلين قابلين للبرمجة وتوازي حتى 6 وحدات.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "9": {"brand": "VEICHI", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "القدرة المقننة": "12000W", "الجهد الاسمي للخرج": "230VAC (فاز-تعادل) / 400VAC (فاز-فاز)", "دعم عدم توازن الحمل": "150%", "التيار المقنن للخرج": "17.4A / 21.7A لكل طور", "أقصى تيار شحن بطارية": "حتى 250–300A", "أقصى تيار دخول AC (شبكة)": "40A", "الاسم الرسمي عند فيتشي": "VLT-12K-H", "عدد متتبعات MPPT / أقصى تيار": "2 متتبع، 27A لكل متتبع", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65، بمخرجين مستقلين لتغذية نظامين مختلفين في نفس الوقت، ويدعم عدم توازن حمل حتى 150% بين الأطوار.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "10": {"brand": "VEICHI", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "القدرة المقننة": "15000W", "الجهد الاسمي للخرج": "230VAC (فاز-تعادل) / 400VAC (فاز-فاز)", "دعم عدم توازن الحمل": "150%", "التيار المقنن للخرج": "17.4A / 21.7A لكل طور", "أقصى تيار شحن بطارية": "حتى 250–300A", "أقصى تيار دخول AC (شبكة)": "40A", "الاسم الرسمي عند فيتشي": "VLT-15K-H", "عدد متتبعات MPPT / أقصى تيار": "2 متتبع، 27A لكل متتبع", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "نفس عائلة VLT ثلاثية الطور، بأعلى قدرة في هذه السلسلة (15 كيلوواط)، مناسب للفلل والمنشآت التجارية الصغيرة.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–950 VDC", "أقصى كفاءة": "98.4%", "عدد متتبعات MPPT": "2", "أقصى تيار خرج AC": "33.5A لكل طور", "القدرة المقننة": "20000W", "الكفاءة الأوروبية": "97.5%", "أقصى تيار دخول شمسي": "30A لكل متتبع (إجمالي 60A)", "أقصى تيار شحن/تفريغ": "40A / 40A", "الاسم الرسمي عند فيتشي": "VHT-20K-40-H", "زمن التحويل للطوارئ (UPS)": "أقل من 10ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "30 كيلوواط"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65، مزوّد بشاشة LCD ملونة وتحكم عن بعد عبر التطبيق، مع تيار شحن/تفريغ يصل حتى 40A ومدى جهد بطارية واسع يناسب أنظمة الليثيوم الكبيرة.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-3.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–850 VDC", "أقصى كفاءة": "98.8%", "عدد متتبعات MPPT": "4", "يدعم مولد ديزل": "نعم", "أقصى تيار خرج AC": "50A لكل طور", "القدرة المقننة": "30000W", "الكفاءة الأوروبية": "98.3%", "أقصى تيار شحن/تفريغ": "100A / 100A", "الاسم الرسمي عند فيتشي": "VHT-30K-100-H", "التوازي (ربط شبكة / عزل)": "حتى 10 وحدات (ربط شبكة) / 4 وحدات (معزول)", "زمن التحويل للطوارئ (UPS)": "أقل من 20ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "45 كيلوواط"}, "available": true, "description": "انفرتر هجين ثلاثي الطور للمنشآت التجارية والصناعية الصغيرة، بتيار شحن/تفريغ مرتفع (100A) ودعم مولدات الديزل كمصدر طاقة احتياطي.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-4.html"}, "13": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–950 VDC", "أقصى كفاءة": "98.8%", "عدد متتبعات MPPT": "4", "يدعم مولد ديزل": "نعم", "أقصى تيار خرج AC": "83A لكل طور", "القدرة المقننة": "50000W", "الكفاءة الأوروبية": "98.3%", "أقصى تيار شحن/تفريغ": "100A / 100A", "الاسم الرسمي عند فيتشي": "VHT-50K-100-H", "التوازي (ربط شبكة / عزل)": "حتى 10 وحدات (ربط شبكة) / 4 وحدات (معزول)", "زمن التحويل للطوارئ (UPS)": "أقل من 20ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "75 كيلوواط"}, "available": true, "description": "نفس عائلة VHT للمنشآت التجارية، بأعلى قدرة في هذه السلسلة (50 كيلوواط)، مناسب للمشاريع التجارية والصناعية متوسطة الحجم.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-4.html"}, "14": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/b363e3e7-36c3-41cc-bc02-4c654939ac27.jpg", "specs": {"الوزن": "586 كجم", "الاتصال": "CAN / RS485، واي فاي مدمج", "التصنيف": "IP20 (تركيب داخلي)", "التوافق": "يعمل مع أغلب الانفرترات (فيتشي، Ingeteam، Solis، GoodWe، Growatt، Solplanet، SAJ، Deye، Hoymiles وغيرها)", "عمر الدورة": "≥8000 دورة / 10 سنوات", "نوع الخلية": "ليثيوم حديد فوسفات LiFePO4", "الجهد/السعة": "614.3V / 100Ah", "الأبعاد (ع×ق×ا)": "590×390×1829 مم", "عمق التفريغ (DoD)": "95%", "مدى جهد التشغيل": "535.2–691.2 VDC", "نظام إطفاء الحريق": "إطفاء بالإيروسول، يكتشف ويطفئ خلال 5 ثوانٍ", "أقصى تيار شحن/تفريغ": "100A (1C)", "الاسم الرسمي عند فيتشي": "VCHB-61.4K-STF (تهيئة 12 طبقة)", "عدد الطبقات (وحدات نمطية)": "12 طبقة", "الطاقة الإجمالية (لهذه التهيئة)": "61.44 كيلوواط/ساعة", "ذروة تيار تفريغ (لمدة دقيقتين، 25°م)": "125A (1.25C)"}, "available": true, "description": "بطارية ليثيوم عالية الجهد (LiFePO4) بتصميم \\"بدون رف\\" (Rackless) قابل للتكديس المباشر (Plug & Play)، تُركّب الوحدة الواحدة خلال 30 دقيقة تقريبًا. تدعم توصيل حتى 12 حزمة على التوازي (حتى 921 كيلوواط/ساعة إجمالاً)، ومزودة بنظام إطفاء حريق ذكي يكتشف ويطفئ الحريق خلال 5 ثوانٍ. متوافقة مع أغلب الانفرترات المعروفة (فيتشي، جروات، جودوي، ديي، هويملز، وغيرها).", "datasheetUrl": "https://www.veichi.com/product/vchb-614k-stf-rechargeable-lithium-ion-battery.html"}}}, {"rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 560A", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A", "4%", "6299.00", "7243.85"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "الريأكتور (Reactor)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/bd48f50d-b084-4c5e-b11f-fc36d68c8cc7.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "16 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 16 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "28 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 28 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "50 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 50 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "80 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 80 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "100 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 100 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "160 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 160 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "224 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 224 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "315 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 315 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "450 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 450 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "690 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 690 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}}}, {"rows": [["VEICHI Combiner BOX 04", "4+4 Input", "749.00", "861.35"], ["VEICHI Combiner BOX 08", "8+8 Input", "949.00", "1091.35"], ["VEICHI Combiner BOX 10", "10+10 Input", "1149.00", "1321.35"], ["VEICHI Combiner BOX 16", "16+16 Input", "1649.00", "1896.35"], ["VEICHI Combiner BOX 22", "22+22 Input", "2649.00", "3046.35"], ["VEICHI Combiner BOX 30", "30+30 Input", "3849.00", "4426.35"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "صناديق التجميع (Combiner Box)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/5890dc85-20e8-410a-9973-48b6cbfc2a08.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "4+4 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 4 سلسلة من الألواح الشمسية (4 موجب + 4 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "8+8 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 8 سلسلة من الألواح الشمسية (8 موجب + 8 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "10+10 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 10 سلسلة من الألواح الشمسية (10 موجب + 10 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "16+16 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 16 سلسلة من الألواح الشمسية (16 موجب + 16 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "22+22 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 22 سلسلة من الألواح الشمسية (22 موجب + 22 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "30+30 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 30 سلسلة من الألواح الشمسية (30 موجب + 30 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}}}, {"rows": [["VEICHI MC4 Single", "1500 VDC", "4.00", "4.60"], ["VEICHI MC4 Dual Core 1000V", "1000 VDC", "18.00", "20.70"], ["VEICHI MC4 Dual Core 1500V", "1500 VDC", "22.00", "25.30"], ["كابل", "6 mm", "4", "4.6"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "الكابلات والوصلات (MC4)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/3e6da5a3-1c5c-42dd-8c11-c40508378c21.webp", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/d8697bb3-25cc-4d51-a17e-1d49cc109c3d.jpg", "specs": {"مادة العزل": "PV40Z", "درجة الحماية": "IP68", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1500 فولت DC", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس الكابل المتوافق": "2.5 / 4 / 6 مم²", "معيار التنفيذ والاعتماد": "IEC 62852:2014 / TÜV"}, "available": true, "description": "موصل MC4 قياسي من سلسلة SI-PV005، بجهد تشغيل أقصى 1500 فولت DC وتيار مقنن 30 أمبير. درجة حماية IP68 (أعلى فئة، يتحمل الغمر المؤقت في الماء) ومقاومة تماس منخفضة جدًا (≤0.5 مللي أوم) تقلل الفقد والحرارة عند نقاط التوصيل. جسم العزل من مادة PV40Z المقاومة للأشعة فوق البنفسجية والحرارة، مناسب لتوصيل كابلات الألواح الشمسية بمقاس 2.5/4/6 مم² في الأنظمة عالية الجهد (1500V).", "datasheetUrl": "https://www.veichi.com/product/si-photovoltaic-dc-cable.html"}, "1": {"brand": "VEICHI", "specs": {"مادة العزل": "PC EXL9330 / XLPO", "درجة الحماية": "IP67", "شهادة المنتج": "CE", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1000 فولت DC", "الموصل المتوافق": "SI-PV004 / SI-PV005", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس كابل الدخل/الخرج": "1×4 مم² (متوفر أيضًا 6 مم²)"}, "available": true, "description": "وصلة Y من سلسلة SI-PV004-2T1 تجمع فرعين (2 إلى 1) من سلاسل الألواح الشمسية في كابل رئيسي واحد، بجهد تشغيل أقصى 1000 فولت DC وتيار مقنن 30 أمبير. تقلل عدد الكابلات الواصلة لصندوق التجميع أو الانفرتر، ودرجة حماية IP67 تجعلها مناسبة للتركيب الخارجي المستمر.", "datasheetUrl": "https://www.veichi.com/product/photovoltaic-dc-cable/"}, "2": {"brand": "VEICHI", "specs": {"مادة العزل": "PV40Z / XLPO", "درجة الحماية": "IP68", "شهادة المنتج": "CE", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1500 فولت DC", "الموصل المتوافق": "SI-PV004 / SI-PV005", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس كابل الدخل/الخرج": "1×4 مم² (النسخة 4-إلى-1 تدعم 6 مم²)"}, "available": true, "description": "وصلة Y من سلسلة SI-PV005-2T1 تجمع فرعين (2 إلى 1) من سلاسل الألواح الشمسية في كابل رئيسي واحد، بجهد تشغيل أقصى 1500 فولت DC وتيار مقنن 30 أمبير. درجة حماية IP68 تجعلها مناسبة للأنظمة عالية الجهد والتركيب الخارجي طويل الأمد.", "datasheetUrl": "https://www.veichi.com/product/photovoltaic-dc-cable/"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/528adffc-faa3-4659-acd4-7111a52c5f66.jpeg", "specs": {"الموصل": "نحاس مجدول مطلي بالقصدير (84×0.285 مم)", "شهادة المنتج": "TÜV SÜD EN50618:2014 CPR B2ca-s1a,d1,a1 (متوافق أيضًا مع TÜV Rheinland 2PfG 1169)", "المقطع العرضي": "6 مم²", "مدى درجة الحرارة": "-40°م إلى +90°م (تحمل قصير حتى 200°م لمدة 5 ثوانٍ)", "مقاومة الموصل (DC)": "3.39 أوم/كم", "درجة مقاومة اللهب": "عالية (Low Smoke, Halogen Free)", "جهد التشغيل المقنن": "AC 1.0/1.0 كيلوفولت — DC 1.5 كيلوفولت", "مادة العزل والغلاف": "بولي أوليفين متشابك كيميائيًا منخفض الدخان خالٍ من الهالوجين (XLPO/XLPE)", "القطر الخارجي للكابل": "6.3 مم", "التيار الأقصى عند 60°م": "57 أمبير", "اختبار العزل (Withstand Test)": "AC 6.5 كيلوفولت/5 دقائق — DC 15 كيلوفولت/5 دقائق", "مقاومة الأشعة فوق البنفسجية": "نعم"}, "available": true, "maxSolarKw": null, "description": "كابل شمسي أحادي القطب مقاس 6 مم² من طراز SI-H1Z2Z2-K، مصمم خصيصًا لتوصيل الألواح الشمسية بالانفرتر. العزل والغلاف من مادة XLPO/XLPE متشابكة كيميائيًا (Cross-linked)، منخفضة الدخان وخالية من الهالوجين، مقاومة للأشعة فوق البنفسجية والعوامل الجوية، ومناسبة للتركيب الخارجي طويل الأمد وفي درجات الحرارة العالية والمنخفضة. حاصل على اعتماد TÜV SÜD EN50618:2014 مع تصنيف مقاومة الحريق CPR B2ca-s1a,d1,a1، وهو ذات مواصفات متوافقة أيضًا مع معيار TÜV Rheinland 2PfG 1169 الأكثر شيوعًا عالميًا لكابلات الطاقة الشمسية.", "datasheetUrl": "https://www.veichi.com/product/si-photovoltaic-dc-cable.html"}}}, {"rows": [["MCCB DC 100A", "1000 VDC", "139.00", "159.85"], ["MCCB DC 125A", "1000 VDC", "149.00", "171.35"], ["MCCB DC 160A", "1000 VDC", "169.00", "194.35"], ["MCCB DC 200A", "1000 VDC", "189.00", "217.35"], ["MCCB DC 250A", "1000 VDC", "239.00", "274.85"], ["MCCB DC 280A", "1000 VDC", "369.00", "424.35"], ["MCCB DC 400A", "1000 VDC", "799.00", "918.85"], ["MCCB DC 500A", "1000 VDC", "899.00", "1033.85"], ["MCCB DC 630A", "1000 VDC", "1099.00", "1263.85"], ["FUSE 20A", "1000 VDC", "9.00", "10.35"], ["FUSE 25A", "1000 VDC", "11.00", "12.65"], ["FUSE 32A", "1000 VDC", "14.00", "16.10"], ["Holder 32A", "1000 VDC", "12.00", "13.80"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "قواطع وفيوزات DC", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a12efd80-a33d-4748-bffd-e52578a2c303.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "100 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 100 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "125 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 125 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "160 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 160 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "200 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 200 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "250 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 250 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "280 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 280 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "400 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 400 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "500 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 500 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "630 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 630 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "20 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 20 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "25 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 25 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "32 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 32 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "تركيب وتثبيت الفيوز بشكل آمن وقابل للاستبدال", "التيار المقنن": "32 أمبير"}, "available": true, "description": "حامل فيوز (Fuse Holder) بتيار مقنن 32 أمبير، يُستخدم لتركيب وتثبيت الفيوزات داخل صندوق التجميع بشكل آمن وقابل للاستبدال بسهولة عند الحاجة.", "datasheetUrl": null}}}, {"rows": [["VEICHI Pump Inverter 0.75KW", "850V", "3.0A", "", ""], ["VEICHI Pump Inverter 1.5KW", "850V", "4.0A", "", ""], ["VEICHI Pump Inverter 2.2KW", "850V", "6A", "610.00", "701.50"], ["VEICHI Pump Inverter 4KW", "850V", "10A", "", ""], ["VEICHI Pump Inverter 5.5KW", "850V", "13A", "720.00", "828.00"], ["VEICHI Pump Inverter 7.5KW", "850V", "17A", "999.00", "1148.85"], ["VEICHI Pump Inverter 11KW", "850V", "25A", "1133.00", "1302.95"], ["VEICHI Pump Inverter 15KW", "850V", "32A", "", ""], ["VEICHI Pump Inverter 18.5KW", "850V", "38A", "1799.00", "2068.85"], ["VEICHI Pump Inverter 22KW", "850V", "45A", "2111.00", "2427.65"], ["VEICHI Pump Inverter 30KW", "850V", "60A", "2777.00", "3193.55"], ["VEICHI Pump Inverter 37KW", "850V", "75A", "3333.00", "3832.95"], ["VEICHI Pump Inverter 45KW", "850V", "90A", "", ""], ["VEICHI Pump Inverter 55KW", "850V", "110A", "4999.00", "5748.85"], ["VEICHI Pump Inverter 75KW", "850V", "150A", "5777.00", "6643.55"], ["VEICHI Pump Inverter 90KW", "850V", "180A", "7222.00", "8305.30"], ["VEICHI Pump Inverter 110KW", "850V", "210A", "8333.00", "9582.95"], ["VEICHI Pump Inverter 132KW", "850V", "250A", "11222.00", "12905.30"], ["VEICHI Pump Inverter 160KW", "850V", "310A", "12333.00", "14182.95"], ["VEICHI Pump Inverter 185KW", "850V", "340A", "", ""], ["VEICHI Pump Inverter 200KW", "850V", "380A", "17444.00", "20060.60"], ["VEICHI Pump Inverter 220KW", "850V", "415A", "", ""], ["VEICHI Pump Inverter 250KW", "850V", "470A", "21111.00", "24277.65"], ["VEICHI Pump Inverter 280KW", "850V", "510A", "", ""], ["VEICHI Pump Inverter 315KW", "850V", "600A", "22999.00", "26448.85"], ["VEICHI Pump Inverter 355KW", "850V", "670A", "36666.00", "42165.90"], ["VEICHI Pump Inverter 400KW", "850V", "750A", "43333.00", "49832.95"], ["VEICHI Pump Inverter 450KW", "850V", "810A", "", ""], ["VEICHI Pump Inverter 500KW", "850V", "860A", "49999.00", "57498.85"], ["VEICHI Pump Inverter 560KW", "850V", "990A", "53333.00", "61332.95"], ["VEICHI Pump Inverter 630KW", "850V", "1100A", "73333.00", "84332.95"], ["VEICHI Pump Inverter 710KW", "850V", "1260A", "79999.00", "91998.85"]], "columns": ["الموديل", "أقصى جهد DC", "التيار المقنن", "السعر", "السعر شامل الضريبة"], "category": "انفرتر مضخات VEICHI", "categoryInfo": "عائلة انفرترات الطاقة الشمسية لمضخات المياه من VEICHI (سلسلة SI) — تحوّل التيار المستمر القادم من الألواح الشمسية مباشرة إلى تيار متردد لتشغيل مضخات المياه (طرد مركزي، آبار عميقة، ري)، بتقنية MPPT مدمجة لاستخلاص أقصى طاقة ممكنة من الألواح. تدعم أيضًا التغذية من كهرباء الشبكة كمصدر احتياطي عند غياب الشمس. تُستخدم على نطاق واسع في الري الزراعي وتوريد المياه بالمناطق النائية، وتغطي نطاق قدرات من 2.2 كيلوواط حتى 710 كيلوواط بثلاث فئات: فئة اقتصادية 220 فولت، فئة IP65 للتركيب الخارجي المباشر بجانب المضخة، وفئة صناعية للقدرات الكبيرة.", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6a4c88ec-be0a-4f6e-a40b-ce438416cec2.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 1, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "1": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 2.2, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "2": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 3.3, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "3": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 5.6, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "4": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 8, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "5": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 10, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "6": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 14.3, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "7": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 19.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "8": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 23.4, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "9": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 28.6, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "10": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 39, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "11": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 48.1, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "12": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 58.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "13": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 71.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "14": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 97.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "15": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 121.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "16": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 148.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "17": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 178.2, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "18": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 216, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "19": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 249.75, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "20": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 270, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "21": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 297, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "22": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 337.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "23": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 378, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "24": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 425.25, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "25": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 479.25, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "26": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 540, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "27": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 607.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "28": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 675, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "29": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 756, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "30": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si30/si30-1.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 850.5, "description": "موديلات بتصنيف حماية IP65 مقاومة للماء والغبار، تُركّب مباشرة بجانب المضخة في الهواء الطلق بدون الحاجة لكابينة — مناسبة لمشاريع الري الزراعي في المزارع والمناطق النائية (4 حتى 22 كيلوواط).", "datasheetUrl": "https://d.veichi.com/datasheet/si30-solar-pump-inverter-datasheet.pdf"}, "31": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si30/si30-1.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 958.5, "description": "موديلات بتصنيف حماية IP65 مقاومة للماء والغبار، تُركّب مباشرة بجانب المضخة في الهواء الطلق بدون الحاجة لكابينة — مناسبة لمشاريع الري الزراعي في المزارع والمناطق النائية (4 حتى 22 كيلوواط).", "datasheetUrl": "https://d.veichi.com/datasheet/si30-solar-pump-inverter-datasheet.pdf"}}}], "concretePerUnit": 230, "defaultPanelKey": "Aiko|770", "earthingPerUnit": 2500, "flexTubePerUnit": 50, "hpCapacityRatio": 1.15, "leadsWebhookUrl": "https://script.google.com/macros/s/AKfycbx6McxQSAcXLC84nBQDkd6KSHYx2tUVU-81yCJP4WgiatFpw0FJQ5jXCieBIXpfPhhh/exec", "steelPanelPerHP": 16, "combinerHeadroom": 1.1, "maxStringVoltage": 720, "reactorMarkupPct": 20, "transportMinimum": 2000, "transportPerTrip": 200, "cableLowMultiplier": 45, "defaultDiscountIdx": 0, "panelMarginPerWatt": 0.02, "cableHighMultiplier": 90, "elecInstallPerPanel": 30, "mechInstallPerPanel": 40, "readyOffgridSystems": [{"id": 1, "name": "ديوانية الدوري", "notes": "أُعيد تسعيرها بمعدات فيتشي (توريد خامات فقط، بدون تركيب/شاسيه). السعر القديم كان 27,370 بمعدات هويمايلز.", "acType": "سبيلت", "cables": "60 كيبل 6ML 6م، 4 توصيلات MC4-1، 8 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 28534, "lampCount": 20, "lampHours": 12, "acCountDay": 2, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 18, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 2, "acHoursNight": 6, "batteryCount": 3, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "شاشة تلفزيون 100 واط - 4 ساعات", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 8KW (TWIN) MPPT", "inverterPowerW": 8000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 2, "name": "مجلس المقناص", "notes": "أُعيد تسعيرها بمعدات فيتشي (توريد خامات فقط). السعر القديم كان 22,345.", "acType": "سبيلت", "cables": "60 كيبل 6ML 6م، 4 توصيلات MC4-1، 6 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 23100, "lampCount": 10, "lampHours": 12, "acCountDay": 2, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 18, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 2, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 8KW (TWIN) MPPT", "inverterPowerW": 8000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 3, "name": "غرفة السكن", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 14,285.", "acType": "سبيلت", "cables": "40 كيبل 6ML 6م، 2 توصيلات MC4-1، 8م كيبل 35مل أحمر وأسود", "status": "متوفر", "priceSar": 16868, "lampCount": 15, "lampHours": 8, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 10, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 3, "batteryModel": "VCLB-5k-w01", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 6.2KW (TWIN) MPPT", "inverterPowerW": 6200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 4, "name": "غرفة المشراق", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 10,900. مصحّحة سابقًا: جهازا تبريد مختلفان (سبيلت نهارًا / صحراوي أضعف ليلاً).", "acType": "سبيلت نهارًا + صحراوي ليلاً", "cables": "30 كيبل 6ML 6م، 2 توصيلات MC4-1، 6 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 11979, "lampCount": 10, "lampHours": 12, "acCountDay": 1, "acHoursDay": 6, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 8, "acPowerDayW": 1000, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 7, "batteryCount": 1, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 100, "inverterBrand": "فيتشي", "inverterModel": "SISV 6.2KW (TWIN) MPPT", "inverterPowerW": 6200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 5, "name": "كرفان المدهال", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول تقني من بطارية جافة (200Ah) لليثيوم — السعر القديم كان 7,210 بفرق +61%. افتراض: البطارية الجافة القديمة كانت 12V.", "acType": "سبيلت (نهارًا فقط)", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 10564, "lampCount": 10, "lampHours": 6, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 6, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 2, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SISV-24V 4.2KW (TWIN) MPPT", "inverterPowerW": 4200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 6, "name": "المخيم الاقتصادي", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول من بطارية جافة لليثيوم — السعر القديم كان 6,200 بفرق +80%. افتراض: البطارية الجافة القديمة كانت 12V. 15 لمبة × 10 واط = 150 واط، مؤكَّد من العميل سابقًا.", "acType": "صحراوي", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 10067, "lampCount": 15, "lampHours": 6, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 5, "acPowerDayW": 100, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 2, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 100, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 7, "name": "المخيم الصغير", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 5,145 بفرق +58%. افتراض: البطارية الجافة القديمة كانت 12V.", "acType": "صحراوي (نهارًا فقط)", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 7532, "lampCount": 10, "lampHours": 8, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 5, "acPowerDayW": 200, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 8, "name": "مكشات", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 4,315 بفرق +79%. لا يوجد مكيف في هذه المنظومة إطلاقًا - غير مناسبة لعميل محتاج تبريد.", "acType": "لا يوجد", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 7096, "lampCount": 10, "lampHours": 8, "acCountDay": 0, "acHoursDay": 0, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 4, "acPowerDayW": 0, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 9, "name": "الراعي", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول من بطارية جافة لليثيوم — السعر القديم كان 1,453 بفرق +117%. لا يوجد إنفرتر أصلاً (منظم شحن فقط)، فرق السعر بالكامل من البطارية.", "acType": "لا يوجد", "cables": "10 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "غير متوفر", "priceSar": 2990, "lampCount": 1, "lampHours": 8, "acCountDay": 0, "acHoursDay": 0, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 1, "acPowerDayW": 0, "batteryType": "ليثيوم", "fridgeCount": 0, "fridgeHours": 0, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-1.2K-100-Li", "fridgePowerW": 0, "otherDevices": "شاحن جوال (بدون تفاصيل قدرة)", "acPowerNightW": 0, "inverterBrand": "لا يوجد (منظم شحن 20A فقط)", "inverterModel": null, "inverterPowerW": 0, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 1.28}], "structurePriceFixed": 1499, "hybridInverterCatalog": [{"kw": 1, "model": "SIS4-12V 1KW MPPT", "priceExclVat": 449}, {"kw": 2, "model": "SIS4-12V 2KW MPPT", "priceExclVat": 699}, {"kw": 3, "model": "SIS-24V 3KW MPPT", "priceExclVat": 999}, {"kw": 4.2, "model": "SISV-24V 4.2KW (TWIN) MPPT", "priceExclVat": 1049}, {"kw": 5, "model": "SIS 5KW-S MPPT", "priceExclVat": 1149}, {"kw": 6.2, "model": "SISV 6.2KW (TWIN) MPPT", "priceExclVat": 1199}, {"kw": 8, "model": "SISV 8KW (TWIN) MPPT", "priceExclVat": 2299}, {"kw": 11, "model": "SISV 11KW (TWIN) MPPT", "priceExclVat": 2499}, {"kw": 10, "model": "VLT 10KW 3P IP65", "priceExclVat": 5899}, {"kw": 12, "model": "VLT 12KW 3P IP65", "priceExclVat": 6399}, {"kw": 15, "model": "VLT 15KW 3P IP65", "priceExclVat": 7499}, {"kw": 20, "model": "VHT 20KW IP65", "priceExclVat": 8499}, {"kw": 30, "model": "VHT 30KW IP65", "priceExclVat": 15499}, {"kw": 50, "model": "VHT 50KW IP65", "priceExclVat": 19499}], "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0, "combinerMinSpareStrings": 0, "structurePriceRotational": 1499}	2026-10-26 12:41:11.054+00
\.


--
-- Data for Name: product_families; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_families (prefix, name_ar, name_en, next_seq, created_at) FROM stdin;
KIT	أنظمة جاهزة	Ready systems	1	2026-10-18 11:20:18.407342+00
PNL	ألواح الطاقة الشمسية	Solar panels	15	2026-10-18 11:20:18.407342+00
INV	انفرترات	Inverters	48	2026-10-18 11:20:18.407342+00
BAT	بطاريات	Batteries	11	2026-10-18 11:20:18.407342+00
CMB	صناديق التجميع	Combiner boxes	7	2026-10-18 11:20:18.407342+00
RCT	Reactor	Reactors	14	2026-10-18 11:20:18.407342+00
PRT	قواطع وفيوزات DC	DC protection	14	2026-10-18 11:20:18.407342+00
CBL	كابلات ووصلات	Cables and connectors	5	2026-10-18 11:20:18.407342+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_code, family, category, catalog_category, catalog_name, brand, name_ar, part_number, warranty_years, performance_warranty_years, requires_serial, status, admin_notes, created_at, updated_at, supplier_discount_pct) FROM stdin;
1	PNL-00001	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Aiko-665W	Aiko	Aiko 665W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
2	PNL-00002	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Aiko-650W	Aiko	Aiko 650W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
3	PNL-00003	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-JA-595W	JA	JA 595W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
4	PNL-00004	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-JA-620W	JA	JA 620W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
5	PNL-00005	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-JA-630W	JA	JA 630W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
6	PNL-00006	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-TRINA-610W	TRINA	TRINA 610W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
7	PNL-00007	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Longi-620W	Longi	Longi 620W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
13	INV-00001	INV	hybrid	شواحن/انفرترات هجين MPPT	SIS4-12V 1KW MPPT	VEICHI	SIS4-12V 1KW MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
14	INV-00002	INV	hybrid	شواحن/انفرترات هجين MPPT	SIS4-12V 2KW MPPT	VEICHI	SIS4-12V 2KW MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
15	INV-00003	INV	hybrid	شواحن/انفرترات هجين MPPT	SIS-24V 3KW MPPT	VEICHI	SIS-24V 3KW MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
16	INV-00004	INV	hybrid	شواحن/انفرترات هجين MPPT	SISV-24V 4.2KW (TWIN) MPPT	VEICHI	SISV-24V 4.2KW (TWIN) MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
17	INV-00005	INV	hybrid	شواحن/انفرترات هجين MPPT	SIS 5KW-S MPPT	VEICHI	SIS 5KW-S MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
18	INV-00006	INV	hybrid	شواحن/انفرترات هجين MPPT	SISV 6.2KW (TWIN) MPPT	VEICHI	SISV 6.2KW (TWIN) MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
19	INV-00007	INV	hybrid	شواحن/انفرترات هجين MPPT	SISV 8KW (TWIN) MPPT	VEICHI	SISV 8KW (TWIN) MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
20	INV-00008	INV	hybrid	شواحن/انفرترات هجين MPPT	SISV 11KW (TWIN) MPPT	VEICHI	SISV 11KW (TWIN) MPPT	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
21	INV-00009	INV	hybrid	شواحن/انفرترات هجين MPPT	VLT 10KW 3P IP65	VEICHI	VLT 10KW 3P IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
22	INV-00010	INV	hybrid	شواحن/انفرترات هجين MPPT	VLT 12KW 3P IP65	VEICHI	VLT 12KW 3P IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
23	INV-00011	INV	hybrid	شواحن/انفرترات هجين MPPT	VLT 15KW 3P IP65	VEICHI	VLT 15KW 3P IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
24	INV-00012	INV	hybrid	شواحن/انفرترات هجين MPPT	VHT 20KW IP65	VEICHI	VHT 20KW IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
25	INV-00013	INV	hybrid	شواحن/انفرترات هجين MPPT	VHT 30KW IP65	VEICHI	VHT 30KW IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
26	INV-00014	INV	hybrid	شواحن/انفرترات هجين MPPT	VHT 50KW IP65	VEICHI	VHT 50KW IP65	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
27	INV-00015	INV	hybrid	شواحن/انفرترات هجين MPPT	VCHB-61.4K-STF High Voltage Rack	VEICHI	VCHB-61.4K-STF High Voltage Rack	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
28	INV-00016	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 0.75KW	VEICHI	VEICHI Pump Inverter 0.75KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
29	INV-00017	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 1.5KW	VEICHI	VEICHI Pump Inverter 1.5KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
30	INV-00018	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 2.2KW	VEICHI	VEICHI Pump Inverter 2.2KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
31	INV-00019	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 4KW	VEICHI	VEICHI Pump Inverter 4KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
32	INV-00020	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 5.5KW	VEICHI	VEICHI Pump Inverter 5.5KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
33	INV-00021	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 7.5KW	VEICHI	VEICHI Pump Inverter 7.5KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
34	INV-00022	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 11KW	VEICHI	VEICHI Pump Inverter 11KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
35	INV-00023	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 15KW	VEICHI	VEICHI Pump Inverter 15KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
36	INV-00024	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 18.5KW	VEICHI	VEICHI Pump Inverter 18.5KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
37	INV-00025	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 22KW	VEICHI	VEICHI Pump Inverter 22KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
38	INV-00026	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 30KW	VEICHI	VEICHI Pump Inverter 30KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
39	INV-00027	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 37KW	VEICHI	VEICHI Pump Inverter 37KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
40	INV-00028	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 45KW	VEICHI	VEICHI Pump Inverter 45KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
41	INV-00029	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 55KW	VEICHI	VEICHI Pump Inverter 55KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
42	INV-00030	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 75KW	VEICHI	VEICHI Pump Inverter 75KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
43	INV-00031	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 90KW	VEICHI	VEICHI Pump Inverter 90KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
44	INV-00032	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 110KW	VEICHI	VEICHI Pump Inverter 110KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
8	PNL-00008	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-TW-720W	TW	TW 720W	\N	\N	\N	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 22:27:24.794068+00	\N
45	INV-00033	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 132KW	VEICHI	VEICHI Pump Inverter 132KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
46	INV-00034	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 160KW	VEICHI	VEICHI Pump Inverter 160KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
47	INV-00035	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 185KW	VEICHI	VEICHI Pump Inverter 185KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
48	INV-00036	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 200KW	VEICHI	VEICHI Pump Inverter 200KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
49	INV-00037	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 220KW	VEICHI	VEICHI Pump Inverter 220KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
50	INV-00038	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 250KW	VEICHI	VEICHI Pump Inverter 250KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
51	INV-00039	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 280KW	VEICHI	VEICHI Pump Inverter 280KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
52	INV-00040	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 315KW	VEICHI	VEICHI Pump Inverter 315KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
53	INV-00041	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 355KW	VEICHI	VEICHI Pump Inverter 355KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
54	INV-00042	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 400KW	VEICHI	VEICHI Pump Inverter 400KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
55	INV-00043	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 450KW	VEICHI	VEICHI Pump Inverter 450KW	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
56	INV-00044	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 500KW	VEICHI	VEICHI Pump Inverter 500KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
57	INV-00045	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 560KW	VEICHI	VEICHI Pump Inverter 560KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
58	INV-00046	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 630KW	VEICHI	VEICHI Pump Inverter 630KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
59	INV-00047	INV	pump	انفرتر مضخات VEICHI	VEICHI Pump Inverter 710KW	VEICHI	VEICHI Pump Inverter 710KW	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
60	BAT-00001	BAT	lithium_battery	بطاريات ليثيوم	VCLB-1.2K-100-Li	VEICHI	VCLB-1.2K-100-Li	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
61	BAT-00002	BAT	lithium_battery	بطاريات ليثيوم	VCLB-2.5K-200-Li	VEICHI	VCLB-2.5K-200-Li	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
62	BAT-00003	BAT	lithium_battery	بطاريات ليثيوم	VCLB-2.5K-100-Li	VEICHI	VCLB-2.5K-100-Li	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
63	BAT-00004	BAT	lithium_battery	بطاريات ليثيوم	VCLB-5.1K-200-Li	VEICHI	VCLB-5.1K-200-Li	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
64	BAT-00005	BAT	lithium_battery	بطاريات ليثيوم	VCLB-5k-w01	VEICHI	VCLB-5k-w01	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
65	BAT-00006	BAT	lithium_battery	بطاريات ليثيوم	VCLB-10k-w02	VEICHI	VCLB-10k-w02	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
66	BAT-00007	BAT	lithium_battery	بطاريات ليثيوم	VCLB-15k-BC	VEICHI	VCLB-15k-BC	\N	\N	\N	t	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
67	BAT-00008	BAT	lithium_battery	بطاريات ليثيوم	Sinoboly-200A-25.1Vs	SINOBOLY	Sinoboly-200A-25.1Vs	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
68	BAT-00009	BAT	lithium_battery	بطاريات ليثيوم	Sinoboly-200A-51V	SINOBOLY	Sinoboly-200A-51V	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
69	BAT-00010	BAT	lithium_battery	بطاريات ليثيوم	Sinoboly-628A-51V	SINOBOLY	Sinoboly-628A-51V	\N	\N	\N	t	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
70	CMB-00001	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 04	VEICHI	VEICHI Combiner BOX 04	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
71	CMB-00002	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 08	VEICHI	VEICHI Combiner BOX 08	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
72	CMB-00003	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 10	VEICHI	VEICHI Combiner BOX 10	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
73	CMB-00004	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 16	VEICHI	VEICHI Combiner BOX 16	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
74	CMB-00005	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 22	VEICHI	VEICHI Combiner BOX 22	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
75	CMB-00006	CMB	combiner_box	صناديق التجميع (Combiner Box)	VEICHI Combiner BOX 30	VEICHI	VEICHI Combiner BOX 30	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
76	RCT-00001	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 16A	VEICHI	VEICHI Reactor 16A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
77	RCT-00002	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 28A	VEICHI	VEICHI Reactor 28A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
78	RCT-00003	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 50A	VEICHI	VEICHI Reactor 50A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
79	RCT-00004	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 80A	VEICHI	VEICHI Reactor 80A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
80	RCT-00005	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 100A	VEICHI	VEICHI Reactor 100A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
81	RCT-00006	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 160A	VEICHI	VEICHI Reactor 160A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
82	RCT-00007	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 224A	VEICHI	VEICHI Reactor 224A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
83	RCT-00008	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 315A	VEICHI	VEICHI Reactor 315A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
84	RCT-00009	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 450A	VEICHI	VEICHI Reactor 450A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
85	RCT-00010	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 690A	VEICHI	VEICHI Reactor 690A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
89	PRT-00001	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 100A	VEICHI	MCCB DC 100A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
90	PRT-00002	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 125A	VEICHI	MCCB DC 125A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
91	PRT-00003	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 160A	VEICHI	MCCB DC 160A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
92	PRT-00004	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 200A	VEICHI	MCCB DC 200A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
93	PRT-00005	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 250A	VEICHI	MCCB DC 250A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
94	PRT-00006	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 280A	VEICHI	MCCB DC 280A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
95	PRT-00007	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 400A	VEICHI	MCCB DC 400A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
96	PRT-00008	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 500A	VEICHI	MCCB DC 500A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
97	PRT-00009	PRT	dc_protection	قواطع وفيوزات DC	MCCB DC 630A	VEICHI	MCCB DC 630A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
98	PRT-00010	PRT	dc_protection	قواطع وفيوزات DC	FUSE 20A	VEICHI	FUSE 20A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
99	PRT-00011	PRT	dc_protection	قواطع وفيوزات DC	FUSE 25A	VEICHI	FUSE 25A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
100	PRT-00012	PRT	dc_protection	قواطع وفيوزات DC	FUSE 32A	VEICHI	FUSE 32A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
101	PRT-00013	PRT	dc_protection	قواطع وفيوزات DC	Holder 32A	VEICHI	Holder 32A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
102	CBL-00001	CBL	cables	الكابلات والوصلات (MC4)	VEICHI MC4 Single	VEICHI	VEICHI MC4 Single	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
103	CBL-00002	CBL	cables	الكابلات والوصلات (MC4)	VEICHI MC4 Dual Core 1000V	VEICHI	VEICHI MC4 Dual Core 1000V	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
104	CBL-00003	CBL	cables	الكابلات والوصلات (MC4)	VEICHI MC4 Dual Core 1500V	VEICHI	VEICHI MC4 Dual Core 1500V	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
105	CBL-00004	CBL	cables	الكابلات والوصلات (MC4)	كابل	VEICHI	VEICHI Cable DC 6mm	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:20:18.407342+00	\N
11	PNL-00011	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Aiko-660W	Aiko	Aiko 660W	MDE72DW	15	30	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:53:22.168478+00	\N
12	PNL-00012	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Aiko-770W	Aiko	Aiko 770W	GRH78Dw	15	30	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 11:53:22.168478+00	\N
86	RCT-00011	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 560A	VEICHI	VEICHI Reactor 560A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 22:10:59.051645+00	4
87	RCT-00012	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 1000A	VEICHI	VEICHI Reactor 1000A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 22:10:59.051645+00	4
88	RCT-00013	RCT	reactor	الريأكتور (Reactor)	VEICHI Reactor 1250A	VEICHI	VEICHI Reactor 1250A	\N	\N	\N	f	active	{}	2026-10-18 11:20:18.407342+00	2026-10-18 22:10:59.051645+00	4
108	PNL-00013	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-JA-730W	JA	JA 730W	\N	\N	\N	f	active	{}	2026-10-26 12:25:55.146015+00	2026-10-26 12:25:55.146015+00	\N
10	PNL-00010	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-JA-715W	JA	JA 715W	JAM66D46	12	30	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-26 12:25:55.146015+00	\N
109	PNL-00014	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Jinko-730W	Jinko	Jinko 730W	\N	\N	\N	f	active	{}	2026-10-26 12:39:49.884674+00	2026-10-26 12:39:49.884674+00	\N
9	PNL-00009	PNL	solar_panel	ألواح الطاقة الشمسية	PANEL-Jinko-645W	Jinko	Jinko 645W	66QL6-BDV	12	30	f	inactive	{}	2026-10-18 11:20:18.407342+00	2026-10-26 12:41:11.11582+00	\N
\.


--
-- Data for Name: project_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_costs (id, project_id, cost_type, description, amount, created_at, cost_date, supplier, tax_treatment) FROM stdin;
3	5	other	\N	161000	2026-08-16 15:58:48.810602+00	\N	\N	recoverable
6	6	transportation	\N	50	2026-08-18 20:17:52.31716+00	\N	\N	recoverable
25	2	labor	MANPOWER	1372.00	2026-10-26 20:38:16.75535+00	2026-04-04	\N	none
27	2	materials	CONCRETE	3835.00	2026-10-26 20:40:03.960797+00	2026-04-04	\N	recoverable
28	2	other	accessories 	359.00	2026-10-26 20:41:21.23731+00	2026-04-04	\N	recoverable
32	2	other	fasilities 	680.00	2026-10-26 20:52:54.501731+00	2026-04-04	\N	none
34	8	materials	فاتورة 0006-6891	45929.62	2026-10-26 21:37:18.027957+00	2026-10-26	شركه اشراق للتجارة -Eshraq	recoverable
29	2	materials	فاتورة 26-03041025	64625.00	2026-10-26 20:43:05.128052+00	2026-04-04	افكار-AFKAR.Co	recoverable
42	8	materials	فاتورة 26-09129420	1840.00	2026-10-28 12:44:02.046925+00	2026-09-20	افكار-AFKAR.Co	recoverable
43	6	materials	فاتورة 26-08114318	9830.20	2026-10-28 12:45:10.725903+00	2026-08-18	افكار-AFKAR.Co	recoverable
41	7	materials	فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال	3102.70	2026-10-28 12:42:40.407872+00	2026-09-22	افكار-AFKAR.Co	recoverable
40	5	materials	فاتورة 26-08112917	146791.46	2026-10-28 12:39:43.138811+00	2026-08-17	افكار-AFKAR.Co	recoverable
47	1	transportation	\N	1500	2026-10-28 22:27:12.91092+00	\N	\N	recoverable
48	2	transportation	RAJHI	1700.00	2026-10-28 23:03:13.128246+00	2026-03-19	MAHMOUD ABO ZAID	none
49	5	transportation	فاتورة 	2200.00	2026-10-28 23:04:18.237323+00	2026-07-11	MAHMOUD ABO ZAID	none
50	8	transportation	فاتورة 	1800.00	2026-10-28 23:06:22.30172+00	2026-09-19	MAHMOUD ABO ZAID	none
51	7	transportation	فاتورة 	300.00	2026-10-28 23:07:23.030604+00	2026-09-19	MAHMOUD ABO ZAID	none
52	4	transportation	فاتورة 	2000.00	2026-10-28 23:08:45.122185+00	2026-08-23	MAHMOUD ABO ZAID	none
53	2	transportation	TRANSPORTATIONS	417.25	2026-10-28 23:12:51.649991+00	2026-04-04	\N	none
54	1	materials	فاتورة 26-07090705	172000.00	2026-10-28 23:53:24.364236+00	2026-07-05	افكار-AFKAR.Co	recoverable
\.


--
-- Data for Name: project_discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_discounts (id, project_id, amount, contract_value_reduction, reason, discount_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: project_finance_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_finance_flags (project_id, contract_includes_vat, completion_date, notes, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, opportunity_id, customer_id, site_id, project_number, contract_value, scope_type, contract_signed_date, project_manager, engineer, planned_supply_date, actual_supply_date, planned_install_date, actual_install_date, status, notes, created_at, updated_at, id_system_type, inverter_spec, panel_spec, structure_type, payment_status) FROM stdin;
1	2	11	\N	PROJ-0555115352-SUP-P-AUG2026	175000	supply	2026-07-01	م محمود الحسيني	م محمود الحسيني	2026-07-09	2026-08-09	2026-08-09	2026-08-09	commissioned		2026-08-12 06:23:38.786816+00	2026-08-16 15:40:00.691+00	pump	\N	\N	\N	paid
3	4	9	\N	PROJ-0555115688-SUP-P-AUG2026	55000	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-17	2026-08-17	2026-08-17	2026-08-17	commissioned		2026-08-16 15:13:21.761183+00	2026-09-22 22:47:33.71+00	pump	\N	\N	\N	paid
4	3	9	\N	PROJ-0555115688-SUP-P-AUG2026-1513	95000	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-17	2026-08-17	2026-08-17	2026-08-17	commissioned		2026-08-16 15:13:36.488194+00	2026-08-24 19:05:47.034+00	pump	\N	\N	\N	partial
8	9	9	\N	PROJ-0555115688-LUM-OFG-SEP2026	52000	installation	2026-09-16	م محمود الحسيني	م محمود الحسيني	2026-09-17	2026-09-18	2026-09-18	2026-09-19	commissioned		2026-09-23 11:57:21.542311+00	2026-09-23 12:03:31.768+00	pump	\N	\N	\N	paid
7	8	12	\N	PROJ-0531133171-INS-P-SEP2026	21000	installation	2026-09-15	م محمود الحسيني	م محمود الحسيني	2026-09-17	2026-09-18	2026-10-15	\N	in_progress		2026-09-23 11:54:47.984386+00	2026-10-12 05:54:24.163+00	pump	\N	\N	\N	partial
5	1	12	\N	PROJ-0531133171-LUM-P-AUG2026-1555	175000	lumpsum	2026-07-09	م محمود الحسيني	م محمود الحسيني	2026-08-09	2026-08-09	2026-08-10	2026-08-10	commissioned		2026-08-16 15:55:39.989228+00	2026-08-16 15:57:45.316+00	pump	\N	\N	\N	paid
2	5	12	\N	PROJ-0531133171-LUM-P-AUG2026	85000	lumpsum	2026-03-15	م محمود الحسيني	م محمود الحسيني	2026-03-16	2026-03-16	2026-03-31	2026-03-31	commissioned		2026-08-12 11:42:14.266973+00	2026-08-16 15:28:26.853+00	pump	\N	\N	\N	paid
6	7	26	\N	PROJ-0554001217-SUP-P-AUG2026	10706	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-18	2026-08-18	2026-08-18	2026-08-18	commissioned		2026-08-16 16:20:23.937828+00	2026-10-26 21:46:29.587+00	pump	\N	\N	\N	paid
10	19	9	\N	PROJ-0555115688-SUP-P-OCT2026	201000	supply	\N	م محمود الحسيني	م محمود الحسيني	\N	\N	\N	\N	preparing		2026-10-25 08:37:42.752301+00	2026-10-27 11:19:25.882+00	pump	\N	\N	\N	paid
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, po_number, supplier_id, project_id, order_date, description, amount, tax_treatment, status, notes, created_at, rfq_id) FROM stdin;
6	\N	3	10	2026-10-27	حسب عرض سعر المورد RFQ-0005	13685.00	recoverable	open	\N	2026-10-27 21:38:36.248256+00	5
8	\N	11	10	2026-10-27	حسب عرض سعر المورد RFQ-0007 (سعر إجمالي)	1950.00	none	open	\N	2026-10-27 21:45:49.503613+00	7
7	\N	2	10	2026-10-27	حسب عرض سعر المورد RFQ-0006	172255.05	recoverable	open	\N	2026-10-27 21:41:57.107185+00	6
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, opportunity_id, customer_id, quotation_number, version, linked_quote_id, valid_until, sales_person, engineer, items, discount_total, vat_percent, subtotal, vat_amount, total, cost, gross_profit, gross_margin, status, notes, created_by, created_at, updated_at, ql_reference, id_system_type, pump_hp, capacity_kw, inverter_spec, panel_spec, structure_type, scope_type, segment) FROM stdin;
\.


--
-- Data for Name: quote_financials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_financials (quote_id, financials, captured_at) FROM stdin;
116	{"vat": 3576.309, "kind": "pump", "items": [{"key": "panel", "net": 17368.56, "qty": "#48#", "sell": 17368.56, "label": "ألواح الطاقة الشمسية", "margin": 340.5599999999977, "discount": 0, "costBasis": 17028.000000000004}, {"key": "inverter", "net": 2777, "qty": "#1#", "sell": 2777, "label": "الانفرتر", "margin": 277.6999999999998, "discount": 0, "costBasis": 2499.3}, {"key": "combiner", "net": 973.7, "qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004", "margin": 224.70000000000005, "discount": 0, "costBasis": 749}, {"key": "cables", "net": 707.2, "qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "label": "الكابلات - DC", "margin": 163.20000000000005, "discount": 0, "costBasis": 544}, {"key": "mc4", "net": 15.600000000000001, "qty": "#3#", "sell": 15.600000000000001, "label": "وصلات MC4", "margin": 3.6000000000000014, "discount": 0, "costBasis": 12}, {"key": "transport", "net": 2000, "qty": "#2#", "sell": 2000, "label": "النقل", "margin": 0, "discount": 0, "costBasis": 2000}], "profit": 1009.7599999999984, "profitPct": 4.235204508335263, "sellTotal": 23842.06, "totalCost": 22832.300000000003, "capturedAt": "2026-10-15T10:12:19.845Z", "finalTotal": 27418.369000000002, "discountTotal": 0, "netAfterManual": 23842.06, "manualDiscountAmt": 0}	2026-10-15 10:12:19.939293+00
117	{"vat": 64235.412, "kind": "pump", "items": [{"key": "panel", "net": 349660.08, "qty": "#742#", "sell": 349660.08, "label": "ألواح الطاقة الشمسية", "margin": 6856.079999999958, "discount": 0, "costBasis": 342804.00000000006}, {"key": "inverter", "net": 43333, "qty": "#1#", "sell": 43333, "label": "الانفرتر", "margin": 4333.299999999996, "discount": 0, "costBasis": 38999.700000000004}, {"key": "combiner", "net": 10007.4, "qty": "#1#", "sell": 10007.4, "label": "VEICHI Combiner box 060", "margin": 2309.3999999999996, "discount": 0, "costBasis": 7698}, {"key": "cables", "net": 24960, "qty": "4800 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 24960, "label": "الكابلات - DC", "margin": 5760, "discount": 0, "costBasis": 19200}, {"key": "mc4", "net": 275.6, "qty": "#53#", "sell": 275.6, "label": "وصلات MC4", "margin": 63.60000000000002, "discount": 0, "costBasis": 212}], "profit": 19322.379999999946, "profitPct": 4.512085950347749, "sellTotal": 428236.08, "totalCost": 408913.70000000007, "capturedAt": "2026-10-15T10:44:39.863Z", "finalTotal": 492471.492, "discountTotal": 0, "netAfterManual": 428236.08, "manualDiscountAmt": 0}	2026-10-15 10:44:39.89357+00
118	{"vat": 61592.76299999999, "kind": "pump", "items": [{"key": "panel", "net": 324213.12, "qty": "#896#", "sell": 324213.12, "label": "ألواح الطاقة الشمسية", "margin": 6357.119999999995, "discount": 0, "costBasis": 317856}, {"key": "inverter", "net": 43333, "qty": "#1#", "sell": 43333, "label": "الانفرتر", "margin": 4333.299999999996, "discount": 0, "costBasis": 38999.700000000004}, {"key": "combiner", "net": 10981.1, "qty": "#1#", "sell": 10981.1, "label": "VEICHI Combiner box 064", "margin": 2534.1000000000004, "discount": 0, "costBasis": 8447}, {"key": "cables", "net": 26000, "qty": "5000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 26000, "label": "الكابلات - DC", "margin": 6000, "discount": 0, "costBasis": 20000}, {"key": "mc4", "net": 291.2, "qty": "#56#", "sell": 291.2, "label": "وصلات MC4", "margin": 67.19999999999999, "discount": 0, "costBasis": 224}, {"key": "transport", "net": 5800, "qty": "#29#", "sell": 5800, "label": "النقل", "margin": 0, "discount": 0, "costBasis": 5800}], "profit": 19291.719999999972, "profitPct": 4.69821105443832, "sellTotal": 410618.42, "totalCost": 391326.7, "capturedAt": "2026-10-15T10:45:18.081Z", "finalTotal": 472211.18299999996, "discountTotal": 0, "netAfterManual": 410618.42, "manualDiscountAmt": 0}	2026-10-15 10:45:18.111637+00
119	{"vat": 3639.837, "kind": "pump", "items": [{"key": "panel", "net": 19792.08, "qty": "#42#", "sell": 19792.08, "label": "ألواح الطاقة الشمسية", "margin": 388.08000000000175, "discount": 0, "costBasis": 19404}, {"key": "inverter", "net": 2777, "qty": "#1#", "sell": 2777, "label": "الانفرتر", "margin": 277.6999999999998, "discount": 0, "costBasis": 2499.3}, {"key": "combiner", "net": 973.7, "qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004", "margin": 224.70000000000005, "discount": 0, "costBasis": 749}, {"key": "cables", "net": 707.2, "qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "label": "الكابلات - DC", "margin": 163.20000000000005, "discount": 0, "costBasis": 544}, {"key": "mc4", "net": 15.600000000000001, "qty": "#3#", "sell": 15.600000000000001, "label": "وصلات MC4", "margin": 3.6000000000000014, "discount": 0, "costBasis": 12}], "profit": 1057.2800000000025, "profitPct": 4.357118189633227, "sellTotal": 24265.58, "totalCost": 23208.3, "capturedAt": "2026-10-15T14:55:13.302Z", "finalTotal": 27905.417, "discountTotal": 0, "netAfterManual": 24265.58, "manualDiscountAmt": 0}	2026-10-15 14:55:13.412563+00
120	{"vat": 12669.8286, "kind": "pump", "items": [{"key": "panel", "net": 64842.624, "qty": "#176#", "sell": 64842.624, "label": "ألواح الطاقة الشمسية", "margin": 1271.423999999999, "discount": 0, "costBasis": 63571.200000000004}, {"key": "inverter", "net": 7222, "qty": "#1#", "sell": 7222, "label": "الانفرتر", "margin": 722.1999999999998, "discount": 0, "costBasis": 6499.8}, {"key": "combiner", "net": 2143.7000000000003, "qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016", "margin": 494.7000000000003, "discount": 0, "costBasis": 1649}, {"key": "cables", "net": 5200, "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC", "margin": 1200, "discount": 0, "costBasis": 4000}, {"key": "mc4", "net": 57.2, "qty": "#11#", "sell": 57.2, "label": "وصلات MC4", "margin": 13.200000000000003, "discount": 0, "costBasis": 44}], "profit": 8701.524000000005, "profitPct": 10.301864699258841, "sellTotal": 79465.524, "totalCost": 75764, "capturedAt": "2026-10-16T13:30:55.686Z", "finalTotal": 97135.35260000001, "discountTotal": 0, "netAfterManual": 84465.524, "manualDiscountAmt": -5000}	2026-10-16 13:30:55.720259+00
121	{"vat": 13829.079, "kind": "pump", "items": [{"key": "panel", "net": 72570.96, "qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية", "margin": 1422.9600000000064, "discount": 0, "costBasis": 71148}, {"key": "inverter", "net": 7222, "qty": "#1#", "sell": 7222, "label": "الانفرتر", "margin": 722.1999999999998, "discount": 0, "costBasis": 6499.8}, {"key": "combiner", "net": 2143.7000000000003, "qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016", "margin": 494.7000000000003, "discount": 0, "costBasis": 1649}, {"key": "cables", "net": 5200, "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC", "margin": 1200, "discount": 0, "costBasis": 4000}, {"key": "mc4", "net": 57.2, "qty": "#11#", "sell": 57.2, "label": "وصلات MC4", "margin": 13.200000000000003, "discount": 0, "costBasis": 44}], "profit": 8853.059999999998, "profitPct": 9.602656836366323, "sellTotal": 87193.86, "totalCost": 83340.8, "capturedAt": "2026-10-16T13:31:50.890Z", "finalTotal": 106022.939, "discountTotal": 0, "netAfterManual": 92193.86, "manualDiscountAmt": -5000}	2026-10-16 13:31:50.919372+00
122	{"vat": 13529.079, "kind": "pump", "items": [{"key": "panel", "net": 72570.96, "qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية", "margin": 1422.9600000000064, "discount": 0, "costBasis": 71148}, {"key": "inverter", "net": 7222, "qty": "#1#", "sell": 7222, "label": "الانفرتر", "margin": 722.1999999999998, "discount": 0, "costBasis": 6499.8}, {"key": "combiner", "net": 2143.7000000000003, "qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016", "margin": 494.7000000000003, "discount": 0, "costBasis": 1649}, {"key": "cables", "net": 5200, "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC", "margin": 1200, "discount": 0, "costBasis": 4000}, {"key": "mc4", "net": 57.2, "qty": "#11#", "sell": 57.2, "label": "وصلات MC4", "margin": 13.200000000000003, "discount": 0, "costBasis": 44}], "profit": 6853.059999999998, "profitPct": 7.598144707411344, "sellTotal": 87193.86, "totalCost": 83340.8, "capturedAt": "2026-10-16T13:32:14.206Z", "finalTotal": 103722.939, "discountTotal": 0, "netAfterManual": 90193.86, "manualDiscountAmt": -3000}	2026-10-16 13:32:14.248104+00
123	{"vat": 13829.079, "kind": "pump", "items": [{"key": "panel", "net": 72570.96, "qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية", "margin": 1422.9600000000064, "discount": 0, "costBasis": 71148}, {"key": "inverter", "net": 7222, "qty": "#1#", "sell": 7222, "label": "الانفرتر", "margin": 722.1999999999998, "discount": 0, "costBasis": 6499.8}, {"key": "combiner", "net": 2143.7000000000003, "qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016", "margin": 494.7000000000003, "discount": 0, "costBasis": 1649}, {"key": "cables", "net": 5200, "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC", "margin": 1200, "discount": 0, "costBasis": 4000}, {"key": "mc4", "net": 57.2, "qty": "#11#", "sell": 57.2, "label": "وصلات MC4", "margin": 13.200000000000003, "discount": 0, "costBasis": 44}], "profit": 8853.059999999998, "profitPct": 9.602656836366323, "sellTotal": 87193.86, "totalCost": 83340.8, "capturedAt": "2026-10-17T09:16:48.022Z", "finalTotal": 106022.939, "discountTotal": 0, "netAfterManual": 92193.86, "manualDiscountAmt": -5000}	2026-10-17 09:16:48.051381+00
124	{"vat": 25798.569000000003, "kind": "pump", "items": [{"key": "panel", "net": 138544.56, "qty": "#294#", "sell": 138544.56, "label": "ألواح الطاقة الشمسية", "margin": 2716.5599999999977, "discount": 0, "costBasis": 135828}, {"key": "inverter", "net": 12333, "qty": "#1#", "sell": 12333, "label": "الانفرتر", "margin": 1233.2999999999993, "discount": 0, "costBasis": 11099.7}, {"key": "combiner", "net": 5003.7, "qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030", "margin": 1154.6999999999998, "discount": 0, "costBasis": 3849}, {"key": "cables", "net": 10400, "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC", "margin": 2400, "discount": 0, "costBasis": 8000}, {"key": "mc4", "net": 109.2, "qty": "#21#", "sell": 109.2, "label": "وصلات MC4", "margin": 25.200000000000003, "discount": 0, "costBasis": 84}], "profit": 13129.76000000001, "profitPct": 7.634004816313654, "sellTotal": 166390.46000000002, "totalCost": 158860.7, "capturedAt": "2026-10-17T09:19:37.827Z", "finalTotal": 197789.02900000004, "discountTotal": 0, "netAfterManual": 171990.46000000002, "manualDiscountAmt": -5600}	2026-10-17 09:19:37.850334+00
125	{"vat": 1342.269, "kind": "pump", "items": [{"key": "panel", "net": 6597.36, "qty": "#14#", "sell": 6597.36, "label": "ألواح الطاقة الشمسية", "margin": 129.36000000000058, "discount": 0, "costBasis": 6467.999999999999}, {"key": "inverter", "net": 1133, "qty": "#1#", "sell": 1133, "label": "الانفرتر", "margin": 113.29999999999995, "discount": 0, "costBasis": 1019.7}, {"key": "combiner", "net": 973.7, "qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004", "margin": 224.70000000000005, "discount": 0, "costBasis": 749}, {"key": "cables", "net": 239.20000000000002, "qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "label": "الكابلات - DC", "margin": 55.20000000000002, "discount": 0, "costBasis": 184}, {"key": "mc4", "net": 5.2, "qty": "#1#", "sell": 5.2, "label": "وصلات MC4", "margin": 1.2000000000000002, "discount": 0, "costBasis": 4}], "profit": 523.760000000002, "profitPct": 5.85307416024659, "sellTotal": 8948.460000000001, "totalCost": 8424.699999999999, "capturedAt": "2026-10-18T09:14:02.745Z", "finalTotal": 10290.729000000001, "discountTotal": 0, "netAfterManual": 8948.460000000001, "manualDiscountAmt": 0}	2026-10-18 09:14:02.830637+00
126	{"vat": 7189.209, "kind": "pump", "items": [{"key": "panel", "net": 39584.16, "qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية", "margin": 776.1600000000035, "discount": 0, "costBasis": 38808}, {"key": "inverter", "net": 4999, "qty": "#1#", "sell": 4999, "label": "الانفرتر", "margin": 499.89999999999964, "discount": 0, "costBasis": 4499.1}, {"key": "combiner", "net": 1233.7, "qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008", "margin": 284.70000000000005, "discount": 0, "costBasis": 949}, {"key": "cables", "net": 2080, "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC", "margin": 480, "discount": 0, "costBasis": 1600}, {"key": "mc4", "net": 31.200000000000003, "qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4", "margin": 7.200000000000003, "discount": 0, "costBasis": 24}], "profit": 2047.9599999999991, "profitPct": 4.2729874733089535, "sellTotal": 47928.06, "totalCost": 45880.1, "capturedAt": "2026-10-19T05:35:21.565Z", "finalTotal": 55117.269, "discountTotal": 0, "netAfterManual": 47928.06, "manualDiscountAmt": 0}	2026-10-19 05:35:21.625427+00
127	{"vat": 7489.208999999999, "kind": "pump", "items": [{"key": "panel", "net": 39584.16, "qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية", "margin": 776.1600000000035, "discount": 0, "costBasis": 38808}, {"key": "inverter", "net": 4999, "qty": "#1#", "sell": 4999, "label": "الانفرتر", "margin": 499.89999999999964, "discount": 0, "costBasis": 4499.1}, {"key": "combiner", "net": 1233.7, "qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008", "margin": 284.70000000000005, "discount": 0, "costBasis": 949}, {"key": "cables", "net": 2080, "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC", "margin": 480, "discount": 0, "costBasis": 1600}, {"key": "mc4", "net": 31.200000000000003, "qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4", "margin": 7.200000000000003, "discount": 0, "costBasis": 24}], "profit": 4047.959999999999, "profitPct": 8.107585193576517, "sellTotal": 47928.06, "totalCost": 45880.1, "capturedAt": "2026-10-19T05:40:07.054Z", "finalTotal": 57417.269, "discountTotal": 0, "netAfterManual": 49928.06, "manualDiscountAmt": -2000}	2026-10-19 05:40:07.08881+00
128	{"vat": 11316.518999999998, "kind": "pump", "items": [{"key": "panel", "net": 39584.16, "qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية", "margin": 776.1600000000035, "discount": 0, "costBasis": 38808}, {"key": "inverter", "net": 4999, "qty": "#1#", "sell": 4999, "label": "الانفرتر", "margin": 499.89999999999964, "discount": 0, "costBasis": 4499.1}, {"key": "ip65", "net": 1200, "qty": "#1#", "sell": 1200, "label": "لوحة الحماية IP65", "margin": 240, "discount": 0, "costBasis": 960}, {"key": "combiner", "net": 1233.7, "qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008", "margin": 284.70000000000005, "discount": 0, "costBasis": 949}, {"key": "cables", "net": 2080, "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC", "margin": 480, "discount": 0, "costBasis": 1600}, {"key": "mc4", "net": 31.200000000000003, "qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4", "margin": 7.200000000000003, "discount": 0, "costBasis": 24}, {"key": "structure", "net": 9893.400000000001, "qty": "#6#", "sell": 9893.400000000001, "label": "الشاسيه/الحوامل (ثابت)", "margin": 899.4000000000015, "discount": 0, "costBasis": 8994}, {"key": "concrete", "net": 3542.0000000000005, "qty": "مطابق للمخطط", "sell": 3542.0000000000005, "label": "الخرسانة", "margin": 322.00000000000045, "discount": 0, "costBasis": 3220}, {"key": "install_mech", "net": 3360, "qty": "#84#", "sell": 3360, "label": "الأعمال الميدانية وتثبيت الألواح", "margin": 0, "discount": 0, "costBasis": 3360}, {"key": "install_elec", "net": 2520, "qty": "#84#", "sell": 2520, "label": "التركيبات والتوصيلات الكهربائية", "margin": 0, "discount": 0, "costBasis": 2520}, {"key": "transport", "net": 2000, "qty": "#4#", "sell": 2000, "label": "النقل", "margin": 0, "discount": 0, "costBasis": 2000}], "profit": 8509.359999999986, "profitPct": 11.279122139944253, "sellTotal": 70443.45999999999, "totalCost": 66934.1, "capturedAt": "2026-10-19T05:41:25.844Z", "finalTotal": 86759.97899999999, "discountTotal": 0, "netAfterManual": 75443.45999999999, "manualDiscountAmt": -5000}	2026-10-19 05:41:25.867236+00
129	{"vat": 5730.74, "kind": "product-cart", "note": "هامش البنود محسوب على أصناف السلة فقط؛ التركيب والنقل (الإضافات) غير مُدرجة في التكلفة.", "items": [{"key": "p:Aiko 770W", "net": 16256, "qty": 32, "sell": 16256, "label": "Aiko 770W", "margin": null, "unitSell": 508, "costBasis": null, "curUnitSell": null}, {"key": "p:VHT 20KW IP65", "net": 8923.95, "qty": 1, "sell": 8923.95, "label": "VHT 20KW IP65", "margin": 424.9500000000007, "unitSell": 8923.95, "costBasis": 8499, "curUnitSell": 8923.95}, {"key": "p:Sinoboly-628A-51V", "net": 11025, "qty": 1, "sell": 11025, "label": "Sinoboly-628A-51V", "margin": 525, "unitSell": 11025, "costBasis": 10500, "curUnitSell": 11025}], "profit": 17205.949999999997, "profitPct": 47.5237502054277, "sellTotal": 36204.95, "totalCost": 18999, "capturedAt": "2026-10-19T06:20:42.122Z", "finalTotal": 43935.69, "extrasTotal": 0, "discountTotal": 0, "netAfterManual": 38204.95, "unknownCostItems": 1, "manualDiscountAmt": -2000}	2026-10-19 06:20:42.164244+00
130	{"vat": 5430.74, "kind": "product-cart", "note": "هامش البنود محسوب على أصناف السلة فقط؛ التركيب والنقل (الإضافات) غير مُدرجة في التكلفة.", "items": [{"key": "p:Aiko 770W", "net": 16256, "qty": 32, "sell": 16256, "label": "Aiko 770W", "margin": null, "unitSell": 508, "costBasis": null, "curUnitSell": null}, {"key": "p:VHT 20KW IP65", "net": 8923.95, "qty": 1, "sell": 8923.95, "label": "VHT 20KW IP65", "margin": 424.9500000000007, "unitSell": 8923.95, "costBasis": 8499, "curUnitSell": 8923.95}, {"key": "p:Sinoboly-628A-51V", "net": 11025, "qty": 1, "sell": 11025, "label": "Sinoboly-628A-51V", "margin": 525, "unitSell": 11025, "costBasis": 10500, "curUnitSell": 11025}], "profit": 17205.949999999997, "profitPct": 47.5237502054277, "sellTotal": 36204.95, "totalCost": 18999, "capturedAt": "2026-10-19T06:21:02.416Z", "finalTotal": 41635.69, "extrasTotal": 0, "discountTotal": 0, "netAfterManual": 36204.95, "unknownCostItems": 1, "manualDiscountAmt": 0}	2026-10-19 06:21:02.451974+00
131	{"vat": 25573.569000000003, "kind": "pump", "items": [{"key": "panel", "net": 138544.56, "qty": "#294#", "sell": 138544.56, "label": "ألواح الطاقة الشمسية", "margin": 2716.5599999999977, "discount": 0, "costBasis": 135828}, {"key": "inverter", "net": 12333, "qty": "#1#", "sell": 12333, "label": "الانفرتر", "margin": 1233.2999999999993, "discount": 0, "costBasis": 11099.7}, {"key": "combiner", "net": 5003.7, "qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030", "margin": 1154.6999999999998, "discount": 0, "costBasis": 3849}, {"key": "cables", "net": 10400, "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC", "margin": 2400, "discount": 0, "costBasis": 8000}, {"key": "mc4", "net": 109.2, "qty": "#21#", "sell": 109.2, "label": "وصلات MC4", "margin": 25.200000000000003, "discount": 0, "costBasis": 84}], "profit": 11629.76000000001, "profitPct": 6.8213552828703765, "sellTotal": 166390.46000000002, "totalCost": 158860.7, "capturedAt": "2026-10-25T08:30:48.273Z", "finalTotal": 196064.02900000004, "discountTotal": 0, "netAfterManual": 170490.46000000002, "manualDiscountAmt": -4100}	2026-10-25 08:30:48.296611+00
132	{"vat": 26218.035, "kind": "pump", "items": [{"key": "panel", "net": 149410.8, "qty": "#308#", "sell": 149410.8, "label": "ألواح الطاقة الشمسية", "margin": 7114.799999999988, "discount": 0, "costBasis": 142296}, {"key": "inverter", "net": 12333, "qty": "#1#", "sell": 12333, "label": "الانفرتر", "margin": 1233.2999999999993, "discount": 0, "costBasis": 11099.7}, {"key": "combiner", "net": 5003.7, "qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030", "margin": 1154.6999999999998, "discount": 0, "costBasis": 3849}, {"key": "cables", "net": 10400, "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC", "margin": 2400, "discount": 0, "costBasis": 8000}, {"key": "mc4", "net": 114.4, "qty": "#22#", "sell": 114.4, "label": "وصلات MC4", "margin": 26.400000000000006, "discount": 0, "costBasis": 88}, {"key": "transport", "net": 2400, "qty": "#12#", "sell": 2400, "label": "النقل", "margin": 0, "discount": 0, "costBasis": 2400}], "profit": 7054.1999999999825, "profitPct": 4.035885984590369, "sellTotal": 179661.9, "totalCost": 167732.7, "capturedAt": "2026-10-27T11:39:56.909Z", "finalTotal": 201004.935, "discountTotal": 0, "netAfterManual": 174786.9, "manualDiscountAmt": 4875}	2026-10-27 11:39:56.932738+00
\.


--
-- Data for Name: quote_ref_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_ref_counters (counter_key, last_value) FROM stdin;
QL-202609	15
QL-202607	32
QL-202608	40
QL-202610	16
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, rep_username, rep_display_name, client_name, client_phone, hp, final_total, snapshot, created_at, customer_id, ref_code, ql_code, revision_no, segment) FROM stdin;
118	ALHUSSEINI	م محمود الحسيني	محمود عظوم	0541206995	500	479877	{"hp": 500, "qlCode": "QL-15Oct2026-P-500 HP-VEICHI 400 KW-Jinko645-FIXED-SUP-6995", "refCode": "QL-202610-0012-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-15T10:45:18.005Z", "panelIdx": 8, "revisionNo": 1, "revisionOf": "QL-202610-0012", "frozenItems": [{"qty": "#896#", "sell": 324213.12, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 43333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 10981.1, "label": "VEICHI Combiner box 064"}, {"qty": "5000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 26000, "label": "الكابلات - DC"}, {"qty": "#56#", "sell": 291.2, "label": "وصلات MC4"}, {"qty": "#29#", "sell": 5800, "label": "النقل"}], "frozenQuote": {"hp": 500, "vat": 61592.76299999999, "invKW": 400, "items": [{"on": true, "key": "panel", "qty": "#896#", "sell": 324213.12, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 43333, "type": "VEICHI أو ما يعادلها 400 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 400 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 10981.1, "type": "-", "label": "VEICHI Combiner box 064", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "5000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 26000, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#56#", "sell": 291.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "1000A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": true, "key": "transport", "qty": "#29#", "sell": 5800, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 577.92, "sellTotal": 410618.42, "finalTotal": 472211.18299999996, "panelLabel": "Jinko 645W", "totalPanels": 896, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 410618.42, "manualDiscountAmt": 0}, "frozenTotal": 472211.18299999996, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-15 10:45:18.036139+00	52	QL-202610-0012-R1	QL-15Oct2026-P-500 HP-VEICHI 400 KW-Jinko645-FIXED-SUP-6995	1	large
130	ALHUSSEINI	م محمود الحسيني	علاء - الاحساء 	0568651110	\N	41636	{"vat": 5430.74, "type": "product-cart", "items": [{"qty": 32, "name": "Aiko 770W", "price": 508, "category": "الألواح الشمسية"}, {"qty": 1, "name": "VHT 20KW IP65", "price": "8923.95", "category": "شواحن/انفرترات هجين MPPT"}, {"qty": 1, "name": "Sinoboly-628A-51V", "price": "11025", "category": "بطاريات ليثيوم"}], "total": 41635.69, "extras": [], "refCode": "QL-202610-0016-R1", "vatRate": 0.15, "subtotal": 36204.95, "revisionNo": 1, "revisionOf": "QL-202610-0016", "displayMode": "summary", "itemsSubtotal": 36204.95, "extrasSubtotal": 0.00, "serverVerified": true, "specialDiscountAmt": 0}	2026-10-19 06:21:02.305691+00	54	QL-202610-0016-R1	\N	1	\N
96	ALHUSSEINI	م محمود الحسيني	مبارك مبخوت	0551119244	400	371001	{"hp": 400, "qlCode": "QL-02Oct2026-P-400 HP-VEICHI 355 KW-Jinko645-FIXED-SUP-9244", "refCode": "QL-202610-0002", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-02T11:43:19.315Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#720#", "sell": 260528.40000000002, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 36666, "label": "الانفرتر"}, {"qty": "#1#", "sell": 7991.1, "label": "VEICHI Combiner box 050"}, {"qty": "4200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 21840, "label": "الكابلات - DC"}, {"qty": "#45#", "sell": 234, "label": "وصلات MC4"}], "frozenQuote": {"hp": 400, "vat": 48391.424999999996, "invKW": 355, "items": [{"on": true, "key": "panel", "qty": "#720#", "sell": 260528.40000000002, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 36666, "type": "VEICHI أو ما يعادلها 355 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 355 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 7991.1, "type": "-", "label": "VEICHI Combiner box 050", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "4200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 21840, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#45#", "sell": 234, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "1000A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 464.4, "sellTotal": 327259.5, "finalTotal": 371000.925, "panelLabel": "Jinko 645W", "totalPanels": 720, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 322609.5, "manualDiscountAmt": 4650}, "frozenTotal": 371000.925, "structureType": "FIXED", "specialDiscountAmt": 4650, "discountOverrideIdx": null}	2026-10-02 11:43:19.329904+00	46	QL-202610-0002	QL-02Oct2026-P-400 HP-VEICHI 355 KW-Jinko645-FIXED-SUP-9244	0	large
1	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "refCode": "QL-202607-0001", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:13:06.019153+00	\N	QL-202607-0001	\N	0	large
3	ALHUSSEINI	م محمود الحسيني	الشيخ علوش بن محسن بن قويد	0504101359	600	838137	{"hp": 600, "refCode": "QL-202607-0003", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:16:46.288822+00	3	QL-202607-0003	\N	0	large
4	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	639497	{"hp": 450, "refCode": "QL-202607-0004", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:23:01.30727+00	5	QL-202607-0004	\N	0	large
10	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	465291	{"hp": 350, "refCode": "QL-202607-0010", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 14:43:42.332633+00	4	QL-202607-0010	\N	0	large
49	ALHUSSEINI	م محمود الحسيني	0	0	500	708125	{"hp": 500, "refCode": "QL-202608-0017", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -500, "discountOverrideIdx": null}	2026-08-06 19:25:25.476823+00	\N	QL-202608-0017	\N	0	large
50	ALHUSSEINI	م محمود الحسيني	محمد جبران	0557761677	60	9724	{"hp": 60, "refCode": "QL-202608-0018", "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 440, "discountOverrideIdx": null}	2026-08-08 07:44:04.818685+00	10	QL-202608-0018	\N	0	medium
51	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	50	50001	{"hp": 50, "refCode": "QL-202608-0019", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -1685, "discountOverrideIdx": null}	2026-08-12 11:28:11.967621+00	\N	QL-202608-0019	\N	0	medium
52	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	60	11862	{"hp": 60, "refCode": "QL-202608-0020", "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-16 14:25:58.355688+00	26	QL-202608-0020	\N	0	medium
102	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	200	184944	{"hp": 200, "qlCode": "QL-07Oct2026-P-200 HP-VEICHI 160 KW-Jinko645-FIXED-SUP-5688", "refCode": "QL-202610-0006", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-07T13:45:28.456Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#352#", "sell": 127369.44000000002, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 12333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030"}, {"qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC"}, {"qty": "#22#", "sell": 114.4, "label": "وصلات MC4"}], "frozenQuote": {"hp": 200, "vat": 24123.081000000002, "invKW": 160, "items": [{"on": true, "key": "panel", "qty": "#352#", "sell": 127369.44000000002, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 12333, "type": "VEICHI أو ما يعادلها 160 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 160 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 5003.7, "type": "-", "label": "VEICHI Combiner box 030", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#22#", "sell": 114.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "450A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 227.04, "sellTotal": 155220.54, "finalTotal": 184943.621, "panelLabel": "Jinko 645W", "totalPanels": 352, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 160820.54, "manualDiscountAmt": -5600}, "frozenTotal": 184943.621, "structureType": "FIXED", "specialDiscountAmt": -5600, "discountOverrideIdx": null}	2026-10-07 13:45:28.537639+00	9	QL-202610-0006	QL-07Oct2026-P-200 HP-VEICHI 160 KW-Jinko645-FIXED-SUP-5688	0	medium
119	ALHUSSEINI	م محمود الحسيني	0509406999	0509406999	30	27905	{"hp": 30, "qlCode": "QL-15Oct2026-P-30 HP-VEICHI 30 KW-Aiko770-FIXED-SUP-6999", "refCode": "QL-202610-0013", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-15T14:55:13.037Z", "panelIdx": 11, "revisionNo": 0, "frozenItems": [{"qty": "#42#", "sell": 19792.08, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 2777, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "label": "الكابلات - DC"}, {"qty": "#3#", "sell": 15.600000000000001, "label": "وصلات MC4"}], "frozenQuote": {"hp": 30, "vat": 3639.837, "invKW": 30, "items": [{"on": true, "key": "panel", "qty": "#42#", "sell": 19792.08, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 2777, "type": "VEICHI أو ما يعادلها 30 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 30 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#3#", "sell": 15.600000000000001, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 32.34, "sellTotal": 24265.58, "finalTotal": 27905.417, "panelLabel": "Aiko 770W", "totalPanels": 42, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 24265.58, "manualDiscountAmt": 0}, "frozenTotal": 27905.417, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-15 14:55:13.155439+00	50	QL-202610-0013	QL-15Oct2026-P-30 HP-VEICHI 30 KW-Aiko770-FIXED-SUP-6999	0	medium
131	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	200	196064	{"hp": 200, "qlCode": "QL-25Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688", "refCode": "QL-202610-0006-R3", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-25T08:30:48.121Z", "panelIdx": 11, "revisionNo": 3, "revisionOf": "QL-202610-0006-R2", "frozenItems": [{"qty": "#294#", "sell": 138544.56, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 12333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030"}, {"qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC"}, {"qty": "#21#", "sell": 109.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 200, "vat": 25573.569000000003, "invKW": 160, "items": [{"on": true, "key": "panel", "qty": "#294#", "sell": 138544.56, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 12333, "type": "VEICHI أو ما يعادلها 160 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 160 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 5003.7, "type": "-", "label": "VEICHI Combiner box 030", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#21#", "sell": 109.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "450A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 226.38, "sellTotal": 166390.46000000002, "finalTotal": 196064.02900000004, "panelLabel": "Aiko 770W", "totalPanels": 294, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 170490.46000000002, "manualDiscountAmt": -4100}, "frozenTotal": 196064.02900000004, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -4100, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-25 08:30:48.147413+00	9	QL-202610-0006-R3	QL-25Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	3	medium
80	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	350	493544	{"hp": 350, "refCode": "QL-202609-0008", "toggles": {"mc4": true, "ip65": true, "earth": true, "panel": true, "cables": true, "supply": true, "reactor": true, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 11, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-19 08:41:28.452395+00	\N	QL-202609-0008	\N	0	large
81	ALHUSSEINI	م محمود الحسيني	0	0	100	95243	{"hp": 100, "refCode": "QL-202609-0009", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-19 10:33:05.401654+00	\N	QL-202609-0009	\N	0	medium
103	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	200	184944	{"hp": 200, "qlCode": "QL-07Oct2026-P-200 HP-VEICHI 160 KW-Jinko645-FIXED-SUP-5688", "refCode": "QL-202610-0006-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-07T13:47:19.609Z", "panelIdx": 8, "revisionNo": 1, "revisionOf": "QL-202610-0006", "frozenItems": [{"qty": "#352#", "sell": 127369.44000000002, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 12333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030"}, {"qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC"}, {"qty": "#22#", "sell": 114.4, "label": "وصلات MC4"}], "frozenQuote": {"hp": 200, "vat": 24123.081000000002, "invKW": 160, "items": [{"on": true, "key": "panel", "qty": "#352#", "sell": 127369.44000000002, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 12333, "type": "VEICHI أو ما يعادلها 160 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 160 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 5003.7, "type": "-", "label": "VEICHI Combiner box 030", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#22#", "sell": 114.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "450A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 227.04, "sellTotal": 155220.54, "finalTotal": 184943.621, "panelLabel": "Jinko 645W", "totalPanels": 352, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 160820.54, "manualDiscountAmt": -5600}, "frozenTotal": 184943.621, "structureType": "FIXED", "specialDiscountAmt": -5600, "discountOverrideIdx": null}	2026-10-07 13:47:19.699533+00	9	QL-202610-0006-R1	QL-07Oct2026-P-200 HP-VEICHI 160 KW-Jinko645-FIXED-SUP-5688	1	medium
120	ALHUSSEINI	م محمود الحسيني	عبدالله - وادي الدواسر	0597544148	100	97135	{"hp": 100, "qlCode": "QL-16Oct2026-P-100 HP-VEICHI 90 KW-Jinko645-FIXED-SUP-4148", "refCode": "QL-202610-0014", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-16T13:30:55.578Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#176#", "sell": 64842.624, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 7222, "label": "الانفرتر"}, {"qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016"}, {"qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC"}, {"qty": "#11#", "sell": 57.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 100, "vat": 12669.8286, "invKW": 90, "items": [{"on": true, "key": "panel", "qty": "#176#", "sell": 64842.624, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 7222, "type": "VEICHI أو ما يعادلها 90 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 90 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 2143.7000000000003, "type": "-", "label": "VEICHI Combiner box 016", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#11#", "sell": 57.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "315A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 113.52, "sellTotal": 79465.524, "finalTotal": 97135.35260000001, "panelLabel": "Jinko 645W", "totalPanels": 176, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 84465.524, "manualDiscountAmt": -5000}, "frozenTotal": 97135.35260000001, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -5000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-16 13:30:55.598392+00	53	QL-202610-0014	QL-16Oct2026-P-100 HP-VEICHI 90 KW-Jinko645-FIXED-SUP-4148	0	medium
132	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	200	201005	{"hp": 200, "qlCode": "QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688", "refCode": "QL-202610-0006-R4", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-27T11:39:56.783Z", "panelIdx": 11, "revisionNo": 4, "revisionOf": "QL-202610-0006-R3", "frozenItems": [{"qty": "#308#", "sell": 149410.8, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 12333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030"}, {"qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC"}, {"qty": "#22#", "sell": 114.4, "label": "وصلات MC4"}, {"qty": "#12#", "sell": 2400, "label": "النقل"}], "frozenQuote": {"hp": 200, "vat": 26218.035, "invKW": 160, "items": [{"on": true, "key": "panel", "qty": "#308#", "sell": 149410.8, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 12333, "type": "VEICHI أو ما يعادلها 160 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 160 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 5003.7, "type": "-", "label": "VEICHI Combiner box 030", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#22#", "sell": 114.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "450A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": true, "key": "transport", "qty": "#12#", "sell": 2400, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 237.16, "sellTotal": 179661.9, "finalTotal": 201004.935, "panelLabel": "Aiko 770W", "totalPanels": 308, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 174786.9, "manualDiscountAmt": 4875}, "frozenTotal": 201004.935, "stringsAdjust": -1, "structureType": "FIXED", "specialDiscountAmt": 4875, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-27 11:39:56.81135+00	9	QL-202610-0006-R4	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	4	medium
97	ALHUSSEINI	م محمود الحسيني	0555247459	0555247459	\N	38377	{"type": "product-cart", "items": [{"qty": 1, "name": "VEICHI Pump Inverter 30KW", "price": "2777.00", "category": "انفرتر مضخات VEICHI"}, {"qty": 2, "name": "VEICHI Pump Inverter 18.5KW", "price": "1799.00", "category": "انفرتر مضخات VEICHI"}, {"qty": 64, "name": "Jinko 645W", "price": 390, "category": "الألواح الشمسية"}, {"qty": 1, "name": "VEICHI Combiner BOX 08", "price": "996.45", "category": "صناديق التجميع (Combiner Box)"}, {"qty": 200, "name": "كابل", "price": "5.2", "category": "الكابلات والوصلات (MC4)"}], "refCode": "QL-202610-0003", "revisionNo": 0}	2026-10-04 12:58:35.662948+00	47	QL-202610-0003	\N	0	\N
34	ALHUSSEINI	م محمود الحسيني	0	0	200	181391	{"hp": 200, "refCode": "QL-202608-0002", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:05:48.011051+00	\N	QL-202608-0002	\N	0	medium
35	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	200	272147	{"hp": 200, "refCode": "QL-202608-0003", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:06:53.547374+00	\N	QL-202608-0003	\N	0	medium
36	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "refCode": "QL-202608-0004", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:00:47.429411+00	7	QL-202608-0004	\N	0	large
37	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "refCode": "QL-202608-0005", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:01:47.017741+00	7	QL-202608-0005	\N	0	large
40	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0567712263	450	423433	{"hp": 450, "refCode": "QL-202608-0008", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-02 19:23:16.289635+00	8	QL-202608-0008	\N	0	large
5	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	417794	{"hp": 450, "refCode": "QL-202607-0005", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:24:14.095115+00	5	QL-202607-0005	\N	0	large
6	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	417794	{"hp": 450, "refCode": "QL-202607-0006", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:24:59.253852+00	5	QL-202607-0006	\N	0	large
2	ALHUSSEINI	م محمود الحسيني	0	0000	600	838137	{"hp": 600, "refCode": "QL-202607-0002", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:14:51.564801+00	\N	QL-202607-0002	\N	0	large
7	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "refCode": "QL-202607-0007", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-18 08:53:11.228881+00	\N	QL-202607-0007	\N	0	large
8	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "refCode": "QL-202607-0008", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-18 19:11:09.722992+00	\N	QL-202607-0008	\N	0	large
9	ALHUSSEINI	م محمود الحسيني	0	0	500	686610	{"hp": 500, "refCode": "QL-202607-0009", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 12:27:31.797831+00	\N	QL-202607-0009	\N	0	large
11	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	465291	{"hp": 350, "refCode": "QL-202607-0011", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 14:44:36.804264+00	4	QL-202607-0011	\N	0	large
12	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	457400	{"hp": 350, "refCode": "QL-202607-0012", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 15:02:30.399101+00	4	QL-202607-0012	\N	0	large
14	ALHUSSEINI	م محمود الحسيني	0	0	300	273281	{"hp": 300, "refCode": "QL-202607-0014", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-22 07:10:28.107902+00	\N	QL-202607-0014	\N	0	large
53	ALHUSSEINI	م محمود الحسيني	أبو ماجد	0509927849	10	9129	{"hp": 10, "refCode": "QL-202608-0021", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:24:05.206398+00	28	QL-202608-0021	\N	0	small
54	ALHUSSEINI	م محمود الحسيني	عادل ديماس الجوف 	0560595743	250	324069	{"hp": 250, "refCode": "QL-202608-0022", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 9, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:26:23.086288+00	29	QL-202608-0022	\N	0	medium
55	ALHUSSEINI	م محمود الحسيني	الشيخه الاميره 	0506222121	150	195760	{"hp": 150, "refCode": "QL-202608-0023", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 9, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:49:27.549624+00	30	QL-202608-0023	\N	0	medium
56	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	696916	{"hp": 500, "refCode": "QL-202608-0024", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-20 11:48:22.751577+00	31	QL-202608-0024	\N	0	large
57	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	704644	{"hp": 500, "refCode": "QL-202608-0025", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:10:43.151687+00	31	QL-202608-0025	\N	0	large
121	ALHUSSEINI	م محمود الحسيني	عبدالله - وادي الدواسر	0597544148	100	106023	{"hp": 100, "qlCode": "QL-16Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-4148", "refCode": "QL-202610-0014-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-16T13:31:50.811Z", "panelIdx": 11, "revisionNo": 1, "revisionOf": "QL-202610-0014", "frozenItems": [{"qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 7222, "label": "الانفرتر"}, {"qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016"}, {"qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC"}, {"qty": "#11#", "sell": 57.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 100, "vat": 13829.079, "invKW": 90, "items": [{"on": true, "key": "panel", "qty": "#154#", "sell": 72570.96, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 7222, "type": "VEICHI أو ما يعادلها 90 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 90 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 2143.7000000000003, "type": "-", "label": "VEICHI Combiner box 016", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#11#", "sell": 57.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "315A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 118.58, "sellTotal": 87193.86, "finalTotal": 106022.939, "panelLabel": "Aiko 770W", "totalPanels": 154, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 92193.86, "manualDiscountAmt": -5000}, "frozenTotal": 106022.939, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -5000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-16 13:31:50.82528+00	53	QL-202610-0014-R1	QL-16Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-4148	1	medium
99	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	20	23181	{"hp": 20, "qlCode": "QL-05Oct2026-P-20 HP-VEICHI 18.5 KW-JA715-FIXED-SI", "refCode": "QL-202610-0004", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": true, "structure": false, "civilworks": false}, "frozenAt": "2026-10-05T07:20:06.943Z", "panelIdx": 9, "revisionNo": 0, "frozenItems": [{"qty": "#34#", "sell": 13885.872000000001, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1799, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "label": "الكابلات - DC"}, {"qty": "#2#", "sell": 10.4, "label": "وصلات MC4"}, {"qty": "#34#", "sell": 1020, "label": "التركيبات والتوصيلات الكهربائية"}, {"qty": "#2#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 20, "vat": 3023.5458000000003, "invKW": 18.5, "items": [{"on": true, "key": "panel", "qty": "#34#", "sell": 13885.872000000001, "type": "JA 715W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1799, "type": "VEICHI أو ما يعادلها 18.5 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 18.5 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#2#", "sell": 10.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": true, "key": "install_elec", "qty": "#34#", "sell": 1020, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "transport", "qty": "#2#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 24.31, "sellTotal": 20156.972, "finalTotal": 23180.5178, "panelLabel": "JA 715W", "totalPanels": 34, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 20156.972, "manualDiscountAmt": 0}, "frozenTotal": 23180.5178, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-05 07:20:06.978534+00	48	QL-202610-0004	QL-05Oct2026-P-20 HP-VEICHI 18.5 KW-JA715-FIXED-SI	0	medium
58	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "refCode": "QL-202608-0026", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:11:46.35746+00	31	QL-202608-0026	\N	0	large
59	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "refCode": "QL-202608-0027", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:12:15.895847+00	31	QL-202608-0027	\N	0	large
60	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "refCode": "QL-202608-0028", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:13:00.052612+00	31	QL-202608-0028	\N	0	large
61	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	474682	{"hp": 500, "refCode": "QL-202608-0029", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:14:47.706739+00	31	QL-202608-0029	\N	0	large
62	ALHUSSEINI	م محمود الحسيني	ابو منه	0565480579	500	467782	{"hp": 500, "refCode": "QL-202608-0030", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:47:52.627672+00	32	QL-202608-0030	\N	0	large
63	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "refCode": "QL-202608-0031", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:48:20.510326+00	32	QL-202608-0031	\N	0	large
64	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "refCode": "QL-202608-0032", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:50:54.804812+00	32	QL-202608-0032	\N	0	large
65	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "refCode": "QL-202608-0033", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:56:59.084815+00	32	QL-202608-0033	\N	0	large
66	ALHUSSEINI	م محمود الحسيني	فألح مفرج الطويله	0551833823	600	560308	{"hp": 600, "refCode": "QL-202608-0034", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-23 08:05:24.522245+00	33	QL-202608-0034	\N	0	large
68	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "refCode": "QL-202608-0036", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:18:55.645016+00	31	QL-202608-0036	\N	0	large
69	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "refCode": "QL-202608-0037", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:19:17.742217+00	31	QL-202608-0037	\N	0	large
70	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	1125448	{"hp": 800, "refCode": "QL-202608-0038", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:20:01.62291+00	31	QL-202608-0038	\N	0	large
109	ALHUSSEINI	م محمود الحسيني	0509406999	0509406999	20	27638	{"hp": 20, "qlCode": "QL-12Oct2026-P-20 HP-VEICHI 18.5 KW-Jinko645-FIXED-SI-6999", "refCode": "QL-202610-0007", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "frozenAt": "2026-10-12T17:43:19.401Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#32#", "sell": 11579.04, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1799, "label": "الانفرتر"}, {"qty": "#1#", "sell": 400, "label": "لوحة الحماية IP65"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "label": "الكابلات - DC"}, {"qty": "#2#", "sell": 10.4, "label": "وصلات MC4"}, {"qty": "#2#", "sell": 3297.8, "label": "الشاسيه/الحوامل (ثابت)"}, {"qty": "مطابق للمخطط", "sell": 1265, "label": "الخرسانة"}, {"qty": "#32#", "sell": 1280, "label": "الأعمال الميدانية وتثبيت الألواح"}, {"qty": "#32#", "sell": 960, "label": "التركيبات والتوصيلات الكهربائية"}, {"qty": "#2#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 20, "vat": 3604.9410000000003, "invKW": 18.5, "items": [{"on": true, "key": "panel", "qty": "#32#", "sell": 11579.04, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1799, "type": "VEICHI أو ما يعادلها 18.5 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": true, "key": "ip65", "qty": "#1#", "sell": 400, "type": "خاصة بانفرتر 18.5 KW", "label": "لوحة الحماية IP65", "warranty": "سنة واحدة"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#2#", "sell": 10.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": true, "key": "structure", "qty": "#2#", "sell": 3297.8, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "عشر سنوات"}, {"on": true, "key": "concrete", "qty": "مطابق للمخطط", "sell": 1265, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "---"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": true, "key": "install_mech", "qty": "#32#", "sell": 1280, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "install_elec", "qty": "#32#", "sell": 960, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "transport", "qty": "#2#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 20.64, "sellTotal": 24032.940000000002, "finalTotal": 27637.881, "panelLabel": "Jinko 645W", "totalPanels": 32, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 24032.940000000002, "manualDiscountAmt": 0}, "frozenTotal": 27637.881, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-12 17:43:19.525224+00	50	QL-202610-0007	QL-12Oct2026-P-20 HP-VEICHI 18.5 KW-Jinko645-FIXED-SI-6999	0	medium
122	ALHUSSEINI	م محمود الحسيني	عبدالله - وادي الدواسر	0597544148	100	103723	{"hp": 100, "qlCode": "QL-16Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-4148", "refCode": "QL-202610-0014-R2", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-16T13:32:14.155Z", "panelIdx": 11, "revisionNo": 2, "revisionOf": "QL-202610-0014-R1", "frozenItems": [{"qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 7222, "label": "الانفرتر"}, {"qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016"}, {"qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC"}, {"qty": "#11#", "sell": 57.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 100, "vat": 13529.079, "invKW": 90, "items": [{"on": true, "key": "panel", "qty": "#154#", "sell": 72570.96, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 7222, "type": "VEICHI أو ما يعادلها 90 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 90 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 2143.7000000000003, "type": "-", "label": "VEICHI Combiner box 016", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#11#", "sell": 57.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "315A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 118.58, "sellTotal": 87193.86, "finalTotal": 103722.939, "panelLabel": "Aiko 770W", "totalPanels": 154, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 90193.86, "manualDiscountAmt": -3000}, "frozenTotal": 103722.939, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -3000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-16 13:32:14.16528+00	53	QL-202610-0014-R2	QL-16Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-4148	2	medium
100	ALHUSSEINI	م محمود الحسيني	0	0	60	58507	{"hp": 60, "qlCode": "QL-06Oct2026-P-60 HP-VEICHI 55 KW-Jinko645-FIXED-SUP", "refCode": "QL-202610-0005", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-06T07:10:37.867Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#112#", "sell": 40526.64, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 4999, "label": "الانفرتر"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC"}, {"qty": "#7#", "sell": 36.4, "label": "وصلات MC4"}, {"qty": "#4#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 60, "vat": 7631.360999999999, "invKW": 55, "items": [{"on": true, "key": "panel", "qty": "#112#", "sell": 40526.64, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 4999, "type": "VEICHI أو ما يعادلها 55 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 55 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#7#", "sell": 36.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "160A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": true, "key": "transport", "qty": "#4#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 72.24, "sellTotal": 50875.74, "finalTotal": 58507.100999999995, "panelLabel": "Jinko 645W", "totalPanels": 112, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 50875.74, "manualDiscountAmt": 0}, "frozenTotal": 58507.100999999995, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-06 07:10:37.952619+00	48	QL-202610-0005	QL-06Oct2026-P-60 HP-VEICHI 55 KW-Jinko645-FIXED-SUP	0	medium
38	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "refCode": "QL-202608-0006", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:02:53.941281+00	7	QL-202608-0006	\N	0	large
42	ALHUSSEINI	م محمود الحسيني	0	0	100	97161	{"hp": 100, "refCode": "QL-202608-0010", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-08-03 06:51:46.065277+00	\N	QL-202608-0010	\N	0	medium
110	ALHUSSEINI	م محمود الحسيني	0509406999	0509406999	20	18032	{"hp": 20, "qlCode": "QL-12Oct2026-P-20 HP-VEICHI 18.5 KW-Jinko645-FIXED-SUP-6999", "refCode": "QL-202610-0007-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-12T17:44:49.065Z", "panelIdx": 8, "revisionNo": 1, "revisionOf": "QL-202610-0007", "frozenItems": [{"qty": "#32#", "sell": 11579.04, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1799, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "label": "الكابلات - DC"}, {"qty": "#2#", "sell": 10.4, "label": "وصلات MC4"}], "frozenQuote": {"hp": 20, "vat": 2352.021, "invKW": 18.5, "items": [{"on": true, "key": "panel", "qty": "#32#", "sell": 11579.04, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1799, "type": "VEICHI أو ما يعادلها 18.5 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 18.5 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#2#", "sell": 10.4, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 20.64, "sellTotal": 14830.140000000001, "finalTotal": 18032.161, "panelLabel": "Jinko 645W", "totalPanels": 32, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 15680.140000000001, "manualDiscountAmt": -850}, "frozenTotal": 18032.161, "structureType": "FIXED", "specialDiscountAmt": -850, "discountOverrideIdx": null}	2026-10-12 17:44:49.165071+00	50	QL-202610-0007-R1	QL-12Oct2026-P-20 HP-VEICHI 18.5 KW-Jinko645-FIXED-SUP-6999	1	medium
123	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	100	106023	{"hp": 100, "qlCode": "QL-17Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-5688", "refCode": "QL-202610-0008-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-17T09:16:47.881Z", "panelIdx": 11, "revisionNo": 1, "revisionOf": "QL-202610-0008", "frozenItems": [{"qty": "#154#", "sell": 72570.96, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 7222, "label": "الانفرتر"}, {"qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016"}, {"qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC"}, {"qty": "#11#", "sell": 57.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 100, "vat": 13829.079, "invKW": 90, "items": [{"on": true, "key": "panel", "qty": "#154#", "sell": 72570.96, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 7222, "type": "VEICHI أو ما يعادلها 90 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 90 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 2143.7000000000003, "type": "-", "label": "VEICHI Combiner box 016", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#11#", "sell": 57.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "315A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 118.58, "sellTotal": 87193.86, "finalTotal": 106022.939, "panelLabel": "Aiko 770W", "totalPanels": 154, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 92193.86, "manualDiscountAmt": -5000}, "frozenTotal": 106022.939, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -5000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-17 09:16:47.919864+00	9	QL-202610-0008-R1	QL-17Oct2026-P-100 HP-VEICHI 90 KW-Aiko770-FIXED-SUP-5688	1	medium
15	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0015", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-27 11:57:48.794924+00	\N	QL-202607-0015	\N	0	large
17	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	75	68785	{"hp": 75, "refCode": "QL-202607-0017", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:29:09.170898+00	\N	QL-202607-0017	\N	0	medium
111	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	100	95804	{"hp": 100, "qlCode": "QL-12Oct2026-P-100 HP-VEICHI 90 KW-Jinko645-FIXED-SUP-5688", "refCode": "QL-202610-0008", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-12T20:37:14.026Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#176#", "sell": 63684.72000000001, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 7222, "label": "الانفرتر"}, {"qty": "#1#", "sell": 2143.7000000000003, "label": "VEICHI Combiner box 016"}, {"qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "label": "الكابلات - DC"}, {"qty": "#11#", "sell": 57.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 100, "vat": 12496.142999999998, "invKW": 90, "items": [{"on": true, "key": "panel", "qty": "#176#", "sell": 63684.72000000001, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 7222, "type": "VEICHI أو ما يعادلها 90 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 90 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 2143.7000000000003, "type": "-", "label": "VEICHI Combiner box 016", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "1000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 5200, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#11#", "sell": 57.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "315A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 113.52, "sellTotal": 78307.62, "finalTotal": 95803.76299999999, "panelLabel": "Jinko 645W", "totalPanels": 176, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 83307.62, "manualDiscountAmt": -5000}, "frozenTotal": 95803.76299999999, "structureType": "FIXED", "specialDiscountAmt": -5000, "discountOverrideIdx": null}	2026-10-12 20:37:14.116538+00	9	QL-202610-0008	QL-12Oct2026-P-100 HP-VEICHI 90 KW-Jinko645-FIXED-SUP-5688	0	medium
124	ALHUSSEINI	م محمود الحسيني	حمود بن ناصر 	0555115688	200	197789	{"hp": 200, "qlCode": "QL-17Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688", "refCode": "QL-202610-0006-R2", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-17T09:19:37.764Z", "panelIdx": 11, "revisionNo": 2, "revisionOf": "QL-202610-0006-R1", "frozenItems": [{"qty": "#294#", "sell": 138544.56, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 12333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 5003.7, "label": "VEICHI Combiner box 030"}, {"qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "label": "الكابلات - DC"}, {"qty": "#21#", "sell": 109.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 200, "vat": 25798.569000000003, "invKW": 160, "items": [{"on": true, "key": "panel", "qty": "#294#", "sell": 138544.56, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 12333, "type": "VEICHI أو ما يعادلها 160 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 160 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 5003.7, "type": "-", "label": "VEICHI Combiner box 030", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "2000 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 10400, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#21#", "sell": 109.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "450A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 226.38, "sellTotal": 166390.46000000002, "finalTotal": 197789.02900000004, "panelLabel": "Aiko 770W", "totalPanels": 294, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 171990.46000000002, "manualDiscountAmt": -5600}, "frozenTotal": 197789.02900000004, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -5600, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-17 09:19:37.785857+00	9	QL-202610-0006-R2	QL-17Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	2	medium
18	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0555117066	75	68785	{"hp": 75, "refCode": "QL-202607-0018", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:29:43.514222+00	\N	QL-202607-0018	\N	0	medium
19	ALHUSSEINI	م محمود الحسيني	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0019", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 10:59:24.442053+00	\N	QL-202607-0019	\N	0	large
20	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0020", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:12:48.463555+00	\N	QL-202607-0020	\N	0	large
21	ALHUSSEINI	م محمود الحسيني	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0021", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:13:48.248172+00	\N	QL-202607-0021	\N	0	large
22	ALHUSSEINI	م محمود الحسيني	0	0	500	462121	{"hp": 500, "refCode": "QL-202607-0022", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:17:45.304218+00	\N	QL-202607-0022	\N	0	large
23	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0023", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 10:53:17.858084+00	\N	QL-202607-0023	\N	0	large
24	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0024", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 10:59:08.178986+00	\N	QL-202607-0024	\N	0	large
25	\N	الحاسبة الآلية (تسعير مباشر من العميل)	محمد 	0	500	692567	{"hp": 500, "refCode": "QL-202607-0025", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:03:45.389996+00	\N	QL-202607-0025	\N	0	large
26	\N	الحاسبة الآلية (تسعير مباشر من العميل)	محمد 	0	500	692567	{"hp": 500, "refCode": "QL-202607-0026", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:03:59.077388+00	\N	QL-202607-0026	\N	0	large
73	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكزافيت	501411010	100	98813	{"hp": 100, "refCode": "QL-202609-0001", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-09-05 09:05:21.140688+00	38	QL-202609-0001	\N	0	medium
16	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	75	68785	{"hp": 75, "refCode": "QL-202607-0016", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:25:15.645822+00	\N	QL-202607-0016	\N	0	medium
27	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0027", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:08:50.053896+00	\N	QL-202607-0027	\N	0	large
28	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0028", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:11:05.596633+00	\N	QL-202607-0028	\N	0	large
29	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0029", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:14:06.261231+00	\N	QL-202607-0029	\N	0	large
30	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0030", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:17:03.157882+00	\N	QL-202607-0030	\N	0	large
112	ALHUSSEINI	م محمود الحسيني	مطلق الدوسري - الافلاج	0555247459	40	51679	{"hp": 40, "qlCode": "QL-13Oct2026-P-40 HP-VEICHI 37 KW-Jinko645-FIXED-SI-7459", "refCode": "QL-202610-0009", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "frozenAt": "2026-10-13T09:51:55.159Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#64#", "sell": 23158.08, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 3333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 800, "label": "لوحة الحماية IP65"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 1040, "label": "الكابلات - DC"}, {"qty": "#4#", "sell": 20.8, "label": "وصلات MC4"}, {"qty": "#4#", "sell": 6595.6, "label": "الشاسيه/الحوامل (ثابت)"}, {"qty": "مطابق للمخطط", "sell": 2277, "label": "الخرسانة"}, {"qty": "#64#", "sell": 2560, "label": "الأعمال الميدانية وتثبيت الألواح"}, {"qty": "#64#", "sell": 1920, "label": "التركيبات والتوصيلات الكهربائية"}, {"qty": "#3#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 40, "vat": 6740.727, "invKW": 37, "items": [{"on": true, "key": "panel", "qty": "#64#", "sell": 23158.08, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 3333, "type": "VEICHI أو ما يعادلها 37 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": true, "key": "ip65", "qty": "#1#", "sell": 800, "type": "خاصة بانفرتر 37 KW", "label": "لوحة الحماية IP65", "warranty": "سنة واحدة"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 1040, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#4#", "sell": 20.8, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": true, "key": "structure", "qty": "#4#", "sell": 6595.6, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "عشر سنوات"}, {"on": true, "key": "concrete", "qty": "مطابق للمخطط", "sell": 2277, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "---"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "80A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": true, "key": "install_mech", "qty": "#64#", "sell": 2560, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "install_elec", "qty": "#64#", "sell": 1920, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "transport", "qty": "#3#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 41.28, "sellTotal": 44938.18, "finalTotal": 51678.907, "panelLabel": "Jinko 645W", "totalPanels": 64, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 44938.18, "manualDiscountAmt": 0}, "frozenTotal": 51678.907, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-13 09:51:55.208547+00	47	QL-202610-0009	QL-13Oct2026-P-40 HP-VEICHI 37 KW-Jinko645-FIXED-SI-7459	0	medium
125	ALHUSSEINI	م محمود الحسيني	0562258078	0562258078	10	10291	{"hp": 10, "qlCode": "QL-18Oct2026-P-10 HP-VEICHI 11 KW-Aiko770-FIXED-SUP-8078", "refCode": "QL-202610-0010-R2", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-18T09:14:02.462Z", "panelIdx": 11, "revisionNo": 2, "revisionOf": "QL-202610-0010-R1", "frozenItems": [{"qty": "#14#", "sell": 6597.36, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1133, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "label": "الكابلات - DC"}, {"qty": "#1#", "sell": 5.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 10, "vat": 1342.269, "invKW": 11, "items": [{"on": true, "key": "panel", "qty": "#14#", "sell": 6597.36, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1133, "type": "VEICHI أو ما يعادلها 11 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 11 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#1#", "sell": 5.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 10.78, "sellTotal": 8948.460000000001, "finalTotal": 10290.729000000001, "panelLabel": "Aiko 770W", "totalPanels": 14, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 8948.460000000001, "manualDiscountAmt": 0}, "frozenTotal": 10290.729000000001, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-18 09:14:02.560389+00	51	QL-202610-0010-R2	QL-18Oct2026-P-10 HP-VEICHI 11 KW-Aiko770-FIXED-SUP-8078	2	small
31	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0031", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:19:29.71914+00	\N	QL-202607-0031	\N	0	large
32	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "refCode": "QL-202607-0032", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:19:40.625108+00	\N	QL-202607-0032	\N	0	large
33	ALHUSSEINI	م محمود الحسيني	0	0	200	181391	{"hp": 200, "refCode": "QL-202608-0001", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:04:54.58689+00	\N	QL-202608-0001	\N	0	medium
75	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	112082	{"hp": 120, "refCode": "QL-202609-0003", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:45:42.673377+00	\N	QL-202609-0003	\N	0	medium
113	ALHUSSEINI	م محمود الحسيني	مطلق الدوسري - الافلاج	0555247459	40	52139	{"hp": 40, "qlCode": "QL-13Oct2026-P-40 HP-VEICHI 37 KW-Jinko645-FIXED-SI-7459", "refCode": "QL-202610-0009-R1", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "frozenAt": "2026-10-13T10:33:33.755Z", "panelIdx": 8, "revisionNo": 1, "revisionOf": "QL-202610-0009", "frozenItems": [{"qty": "#64#", "sell": 23158.08, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 3333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 800, "label": "لوحة الحماية IP65"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 1040, "label": "الكابلات - DC"}, {"qty": "#4#", "sell": 20.8, "label": "وصلات MC4"}, {"qty": "#4#", "sell": 6595.6, "label": "الشاسيه/الحوامل (ثابت)"}, {"qty": "مطابق للمخطط", "sell": 2277, "label": "الخرسانة"}, {"qty": "#64#", "sell": 2560, "label": "الأعمال الميدانية وتثبيت الألواح"}, {"qty": "#64#", "sell": 1920, "label": "التركيبات والتوصيلات الكهربائية"}, {"qty": "#3#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 40, "vat": 6800.727, "invKW": 37, "items": [{"on": true, "key": "panel", "qty": "#64#", "sell": 23158.08, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 3333, "type": "VEICHI أو ما يعادلها 37 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": true, "key": "ip65", "qty": "#1#", "sell": 800, "type": "خاصة بانفرتر 37 KW", "label": "لوحة الحماية IP65", "warranty": "سنة واحدة"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "200 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 1040, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#4#", "sell": 20.8, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": true, "key": "structure", "qty": "#4#", "sell": 6595.6, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "عشر سنوات"}, {"on": true, "key": "concrete", "qty": "مطابق للمخطط", "sell": 2277, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "---"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "80A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": true, "key": "install_mech", "qty": "#64#", "sell": 2560, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "install_elec", "qty": "#64#", "sell": 1920, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "transport", "qty": "#3#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 41.28, "sellTotal": 44938.18, "finalTotal": 52138.907, "panelLabel": "Jinko 645W", "totalPanels": 64, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 45338.18, "manualDiscountAmt": -400}, "frozenTotal": 52138.907, "structureType": "FIXED", "specialDiscountAmt": -400, "discountOverrideIdx": null}	2026-10-13 10:33:33.806817+00	47	QL-202610-0009-R1	QL-13Oct2026-P-40 HP-VEICHI 37 KW-Jinko645-FIXED-SI-7459	1	medium
76	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	112082	{"hp": 120, "refCode": "QL-202609-0004", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:46:10.53457+00	\N	QL-202609-0004	\N	0	medium
39	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	695894	{"hp": 500, "refCode": "QL-202608-0007", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 12:02:06.453292+00	\N	QL-202608-0007	\N	0	large
126	ALHUSSEINI	م محمود الحسيني	علاء - الاحساء 	0568651110	60	55117	{"hp": 60, "qlCode": "QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SUP-1110", "refCode": "QL-202610-0015", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-19T05:35:21.438Z", "panelIdx": 11, "revisionNo": 0, "frozenItems": [{"qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 4999, "label": "الانفرتر"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC"}, {"qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4"}], "frozenQuote": {"hp": 60, "vat": 7189.209, "invKW": 55, "items": [{"on": true, "key": "panel", "qty": "#84#", "sell": 39584.16, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 4999, "type": "VEICHI أو ما يعادلها 55 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 55 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#6#", "sell": 31.200000000000003, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "100A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 64.68, "sellTotal": 47928.06, "finalTotal": 55117.269, "panelLabel": "Aiko 770W", "totalPanels": 84, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 47928.06, "manualDiscountAmt": 0}, "frozenTotal": 55117.269, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-19 05:35:21.479757+00	54	QL-202610-0015	QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SUP-1110	0	medium
114	ALHUSSEINI	م محمود الحسيني	فارس الحارثي 	0562258078	10	9822	{"hp": 10, "qlCode": "QL-13Oct2026-P-10 HP-VEICHI 11 KW-Jinko645-FIXED-SUP-8078", "refCode": "QL-202610-0010", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-13T15:46:19.684Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#16#", "sell": 5789.52, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1133, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "label": "الكابلات - DC"}, {"qty": "#1#", "sell": 5.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 10, "vat": 1281.0929999999998, "invKW": 11, "items": [{"on": true, "key": "panel", "qty": "#16#", "sell": 5789.52, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1133, "type": "VEICHI أو ما يعادلها 11 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 11 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#1#", "sell": 5.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 10.32, "sellTotal": 8140.62, "finalTotal": 9821.713, "panelLabel": "Jinko 645W", "totalPanels": 16, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 8540.619999999999, "manualDiscountAmt": -400}, "frozenTotal": 9821.713, "structureType": "FIXED", "specialDiscountAmt": -400, "discountOverrideIdx": null}	2026-10-13 15:46:19.758044+00	51	QL-202610-0010	QL-13Oct2026-P-10 HP-VEICHI 11 KW-Jinko645-FIXED-SUP-8078	0	small
127	ALHUSSEINI	م محمود الحسيني	علاء - الاحساء 	0568651110	60	57417	{"hp": 60, "qlCode": "QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SUP-1110", "refCode": "QL-202610-0015-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-19T05:40:06.957Z", "panelIdx": 11, "revisionNo": 1, "revisionOf": "QL-202610-0015", "frozenItems": [{"qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 4999, "label": "الانفرتر"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC"}, {"qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4"}], "frozenQuote": {"hp": 60, "vat": 7489.208999999999, "invKW": 55, "items": [{"on": true, "key": "panel", "qty": "#84#", "sell": 39584.16, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 4999, "type": "VEICHI أو ما يعادلها 55 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 55 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#6#", "sell": 31.200000000000003, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "100A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 64.68, "sellTotal": 47928.06, "finalTotal": 57417.269, "panelLabel": "Aiko 770W", "totalPanels": 84, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 49928.06, "manualDiscountAmt": -2000}, "frozenTotal": 57417.269, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -2000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-19 05:40:06.995885+00	54	QL-202610-0015-R1	QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SUP-1110	1	medium
115	ALHUSSEINI	م محمود الحسيني	فارس الحارثي 	0562258078	10	10981	{"hp": 10, "qlCode": "QL-13Oct2026-P-10 HP-VEICHI 11 KW-Aiko770-FIXED-SUP-8078", "refCode": "QL-202610-0010-R1", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-13T16:00:34.391Z", "panelIdx": 11, "revisionNo": 1, "revisionOf": "QL-202610-0010", "frozenItems": [{"qty": "#14#", "sell": 6597.36, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1133, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "label": "الكابلات - DC"}, {"qty": "#1#", "sell": 5.2, "label": "وصلات MC4"}], "frozenQuote": {"hp": 10, "vat": 1432.269, "invKW": 11, "items": [{"on": true, "key": "panel", "qty": "#14#", "sell": 6597.36, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 1133, "type": "VEICHI أو ما يعادلها 11 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 11 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "46 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 239.20000000000002, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#1#", "sell": 5.2, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 10.78, "sellTotal": 8948.460000000001, "finalTotal": 10980.729000000001, "panelLabel": "Aiko 770W", "totalPanels": 14, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 9548.460000000001, "manualDiscountAmt": -600}, "frozenTotal": 10980.729000000001, "structureType": "FIXED", "specialDiscountAmt": -600, "discountOverrideIdx": null}	2026-10-13 16:00:34.546109+00	51	QL-202610-0010-R1	QL-13Oct2026-P-10 HP-VEICHI 11 KW-Aiko770-FIXED-SUP-8078	1	small
128	ALHUSSEINI	م محمود الحسيني	علاء - الاحساء 	0568651110	60	86760	{"hp": 60, "qlCode": "QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SI-1110", "refCode": "QL-202610-0015-R2", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "frozenAt": "2026-10-19T05:41:25.784Z", "panelIdx": 11, "revisionNo": 2, "revisionOf": "QL-202610-0015-R1", "frozenItems": [{"qty": "#84#", "sell": 39584.16, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 4999, "label": "الانفرتر"}, {"qty": "#1#", "sell": 1200, "label": "لوحة الحماية IP65"}, {"qty": "#1#", "sell": 1233.7, "label": "VEICHI Combiner box 008"}, {"qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "label": "الكابلات - DC"}, {"qty": "#6#", "sell": 31.200000000000003, "label": "وصلات MC4"}, {"qty": "#6#", "sell": 9893.400000000001, "label": "الشاسيه/الحوامل (ثابت)"}, {"qty": "مطابق للمخطط", "sell": 3542.0000000000005, "label": "الخرسانة"}, {"qty": "#84#", "sell": 3360, "label": "الأعمال الميدانية وتثبيت الألواح"}, {"qty": "#84#", "sell": 2520, "label": "التركيبات والتوصيلات الكهربائية"}, {"qty": "#4#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 60, "vat": 11316.518999999998, "invKW": 55, "items": [{"on": true, "key": "panel", "qty": "#84#", "sell": 39584.16, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 4999, "type": "VEICHI أو ما يعادلها 55 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": true, "key": "ip65", "qty": "#1#", "sell": 1200, "type": "خاصة بانفرتر 55 KW", "label": "لوحة الحماية IP65", "warranty": "سنة واحدة"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 1233.7, "type": "-", "label": "VEICHI Combiner box 008", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "400 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 2080, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#6#", "sell": 31.200000000000003, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": true, "key": "structure", "qty": "#6#", "sell": 9893.400000000001, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "عشر سنوات"}, {"on": true, "key": "concrete", "qty": "مطابق للمخطط", "sell": 3542.0000000000005, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "---"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "100A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": true, "key": "install_mech", "qty": "#84#", "sell": 3360, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "install_elec", "qty": "#84#", "sell": 2520, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "عام واحد فقط من تاريخ التشغيل"}, {"on": true, "key": "transport", "qty": "#4#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 64.68, "sellTotal": 70443.45999999999, "finalTotal": 86759.97899999999, "panelLabel": "Aiko 770W", "totalPanels": 84, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 75443.45999999999, "manualDiscountAmt": -5000}, "frozenTotal": 86759.97899999999, "stringsAdjust": 0, "structureType": "FIXED", "specialDiscountAmt": -5000, "discountOverrideIdx": null, "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0}	2026-10-19 05:41:25.806792+00	54	QL-202610-0015-R2	QL-19Oct2026-P-60 HP-VEICHI 55 KW-Aiko770-FIXED-SI-1110	2	medium
79	ALHUSSEINI	م محمود الحسيني	سالم مرزوق -٠ الكرافيت 	555115510	\N	42715	{"type": "product-cart", "items": [{"qty": 32, "name": "Jinko 650W", "price": 393, "category": "الألواح الشمسية"}, {"qty": 2, "name": "Sinoboly-628A-51V", "price": "11025", "category": "بطاريات ليثيوم"}, {"qty": 2, "name": "SISV 6.2KW (TWIN) MPPT", "price": "1258.95", "category": "شواحن/انفرترات هجين MPPT"}], "refCode": "QL-202609-0007"}	2026-09-16 16:31:45.301558+00	41	QL-202609-0007	\N	0	\N
67	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "refCode": "QL-202608-0035", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:17:56.511649+00	31	QL-202608-0035	\N	0	large
116	ALHUSSEINI	م محمود الحسيني	0562258078	0562258078	30	27418	{"hp": 30, "qlCode": "QL-15Oct2026-P-30 HP-VEICHI 30 KW-Jinko645-FIXED-SUP-8078", "refCode": "QL-202610-0011", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-15T10:12:19.584Z", "panelIdx": 8, "revisionNo": 0, "frozenItems": [{"qty": "#48#", "sell": 17368.56, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 2777, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "label": "الكابلات - DC"}, {"qty": "#3#", "sell": 15.600000000000001, "label": "وصلات MC4"}, {"qty": "#2#", "sell": 2000, "label": "النقل"}], "frozenQuote": {"hp": 30, "vat": 3576.309, "invKW": 30, "items": [{"on": true, "key": "panel", "qty": "#48#", "sell": 17368.56, "type": "Jinko 645W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 2777, "type": "VEICHI أو ما يعادلها 30 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 30 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 973.7, "type": "-", "label": "VEICHI Combiner box 004", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "136 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 707.2, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#3#", "sell": 15.600000000000001, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "50A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": true, "key": "transport", "qty": "#2#", "sell": 2000, "type": "-", "label": "النقل", "warranty": "---"}], "calcKW": 30.96, "sellTotal": 23842.06, "finalTotal": 27418.369000000002, "panelLabel": "Jinko 645W", "totalPanels": 48, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 23842.06, "manualDiscountAmt": 0}, "frozenTotal": 27418.369000000002, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-15 10:12:19.68896+00	51	QL-202610-0011	QL-15Oct2026-P-30 HP-VEICHI 30 KW-Jinko645-FIXED-SUP-8078	0	medium
129	ALHUSSEINI	م محمود الحسيني	علاء - الاحساء 	0568651110	\N	43936	{"vat": 5730.74, "type": "product-cart", "items": [{"qty": 32, "name": "Aiko 770W", "price": 508, "category": "الألواح الشمسية"}, {"qty": 1, "name": "VHT 20KW IP65", "price": "8923.95", "category": "شواحن/انفرترات هجين MPPT"}, {"qty": 1, "name": "Sinoboly-628A-51V", "price": "11025", "category": "بطاريات ليثيوم"}], "total": 43935.69, "extras": [], "refCode": "QL-202610-0016", "vatRate": 0.15, "subtotal": 38204.95, "revisionNo": 0, "displayMode": "summary", "itemsSubtotal": 36204.95, "extrasSubtotal": 0.00, "serverVerified": true, "specialDiscountAmt": -2000}	2026-10-19 06:20:41.979691+00	54	QL-202610-0016	\N	0	\N
41	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0567712263	450	630013	{"hp": 450, "refCode": "QL-202608-0009", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-02 19:24:06.062644+00	8	QL-202608-0009	\N	0	large
43	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	100	97001	{"hp": 100, "refCode": "QL-202608-0011", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 533, "discountOverrideIdx": null}	2026-08-03 06:55:44.225579+00	9	QL-202608-0011	\N	0	medium
13	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	308616	{"hp": 350, "refCode": "QL-202607-0013", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 15:06:16.741853+00	4	QL-202607-0013	\N	0	large
44	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	100	146410	{"hp": 100, "refCode": "QL-202608-0012", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 533, "discountOverrideIdx": null}	2026-08-03 06:56:34.14753+00	9	QL-202608-0012	\N	0	medium
45	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0	500	714203	{"hp": 500, "refCode": "QL-202608-0013", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-03 10:05:15.001621+00	\N	QL-202608-0013	\N	0	large
46	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0	500	714203	{"hp": 500, "refCode": "QL-202608-0014", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-03 10:05:19.275653+00	\N	QL-202608-0014	\N	0	large
47	ALHUSSEINI	م محمود الحسيني	0	0	60	3517	{"hp": 60, "refCode": "QL-202608-0015", "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": false, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-04 21:08:15.962087+00	\N	QL-202608-0015	\N	0	medium
48	ALHUSSEINI	م محمود الحسيني	0	0	60	3517	{"hp": 60, "refCode": "QL-202608-0016", "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": false, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-04 21:08:41.34035+00	\N	QL-202608-0016	\N	0	medium
71	ALHUSSEINI	م محمود الحسيني	احمد حامد السوداني	0565480579	400	375612	{"hp": 400, "refCode": "QL-202608-0039", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:31:05.771096+00	32	QL-202608-0039	\N	0	large
72	ALHUSSEINI	م محمود الحسيني	احمد حامد السوداني	0565480579	400	559594	{"hp": 400, "refCode": "QL-202608-0040", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:31:51.084862+00	32	QL-202608-0040	\N	0	large
74	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكزافيت	501411010	100	148514	{"hp": 100, "refCode": "QL-202609-0002", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-09-05 09:06:13.065612+00	38	QL-202609-0002	\N	0	medium
77	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	169904	{"hp": 120, "refCode": "QL-202609-0005", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:46:55.35918+00	\N	QL-202609-0005	\N	0	medium
78	ALHUSSEINI	م محمود الحسيني	تبو مهدي جار العقيد	556635456	10	8867	{"hp": 10, "refCode": "QL-202609-0006", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-11 16:59:44.085556+00	40	QL-202609-0006	\N	0	small
82	ALHUSSEINI	م محمود الحسيني	مبارك محمد ابو فاضل	0531133171	20	21000	{"hp": 20, "refCode": "QL-202609-0010", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 11, "structureType": "FIXED", "specialDiscountAmt": -510, "discountOverrideIdx": null}	2026-09-23 08:13:09.121286+00	12	QL-202609-0010	\N	0	medium
83	ALHUSSEINI	م محمود الحسيني	مبارك محمد ابو فاضل	531133171	20	21000	{"hp": 20, "refCode": "QL-202609-0011", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 11, "structureType": "FIXED", "specialDiscountAmt": -1339, "discountOverrideIdx": null}	2026-09-23 11:08:41.785172+00	\N	QL-202609-0011	\N	0	medium
84	ALHUSSEINI	م محمود الحسيني	محمد مبارك 	557315456	450	420475	{"hp": 450, "refCode": "QL-202609-0012", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-23 11:15:27.414367+00	45	QL-202609-0012	\N	0	large
85	ALHUSSEINI	م محمود الحسيني	محمد مبارك 	557315456	450	423925	{"hp": 450, "refCode": "QL-202609-0013", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "specialDiscountAmt": -3000, "discountOverrideIdx": null}	2026-09-23 11:18:50.519183+00	45	QL-202609-0013	\N	0	large
86	ALHUSSEINI	م محمود الحسيني	محمد مبارك 	557315456	500	468991	{"hp": 500, "refCode": "QL-202609-0014", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "specialDiscountAmt": -3000, "discountOverrideIdx": null}	2026-09-23 11:20:34.536859+00	45	QL-202609-0014	\N	0	large
87	ALHUSSEINI	م محمود الحسيني	مبارك محمد ابو فاضل	0531133171	20	21000	{"hp": 20, "refCode": "QL-202609-0015", "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 11, "structureType": "FIXED", "specialDiscountAmt": -510, "discountOverrideIdx": null}	2026-09-24 09:24:51.430088+00	12	QL-202609-0015	\N	0	medium
88	ALHUSSEINI	م محمود الحسيني	مبارك محمد ابو فاضل	0531133171	20	17055	{"hp": 20, "refCode": "QL-202610-0001", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-01T12:08:11.596Z", "panelIdx": 10, "frozenItems": [{"qty": "#32#", "sell": 11579.04, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 1799, "label": "الانفرتر"}, {"qty": "#1#", "sell": 973.7, "label": "VEICHI Combiner box 004"}, {"qty": "90 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 468, "label": "الكابلات - DC"}, {"qty": "#2#", "sell": 10.4, "label": "وصلات MC4"}], "frozenTotal": 17054.661, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-01 12:08:11.666649+00	12	QL-202610-0001	\N	0	medium
117	ALHUSSEINI	م محمود الحسيني	محمود عظوم	0541206995	500	500137	{"hp": 500, "qlCode": "QL-15Oct2026-P-500 HP-VEICHI 400 KW-Aiko770-FIXED-SUP-6995", "refCode": "QL-202610-0012", "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "frozenAt": "2026-10-15T10:44:39.671Z", "panelIdx": 11, "revisionNo": 0, "frozenItems": [{"qty": "#742#", "sell": 349660.08, "label": "ألواح الطاقة الشمسية"}, {"qty": "#1#", "sell": 43333, "label": "الانفرتر"}, {"qty": "#1#", "sell": 10007.4, "label": "VEICHI Combiner box 060"}, {"qty": "4800 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 24960, "label": "الكابلات - DC"}, {"qty": "#53#", "sell": 275.6, "label": "وصلات MC4"}], "frozenQuote": {"hp": 500, "vat": 64235.412, "invKW": 400, "items": [{"on": true, "key": "panel", "qty": "#742#", "sell": 349660.08, "type": "Aiko 770W أو ما يعادلها", "label": "ألواح الطاقة الشمسية", "warranty": "12 سنة ضد عيوب الصناعة / 30 سنة ضد التناقص الإنتاجي عن %80"}, {"on": true, "key": "inverter", "qty": "#1#", "sell": 43333, "type": "VEICHI أو ما يعادلها 400 KW", "label": "الانفرتر", "warranty": "سنة واحدة"}, {"on": false, "key": "ip65", "qty": "لا يوجد", "sell": 0, "type": "خاصة بانفرتر 400 KW", "label": "لوحة الحماية IP65", "warranty": "لا يوجد"}, {"on": true, "key": "combiner", "qty": "#1#", "sell": 10007.4, "type": "-", "label": "VEICHI Combiner box 060", "warranty": "سنة واحدة"}, {"on": true, "key": "cables", "qty": "4800 متر (تقريبي — يُحدد نهائيًا عند التوريد)", "sell": 24960, "type": "VEICHI / LEADER / SUNTREE 6mm", "label": "الكابلات - DC", "warranty": "سنة واحدة"}, {"on": true, "key": "mc4", "qty": "#53#", "sell": 275.6, "type": "Suntree / VEICHI / LEADER", "label": "وصلات MC4", "warranty": "---"}, {"on": false, "key": "structure", "qty": "لا يوجد", "sell": 0, "type": "HDG مجلفن مستورد", "label": "الشاسيه/الحوامل (ثابت)", "warranty": "لا يوجد"}, {"on": false, "key": "concrete", "qty": "لا يوجد", "sell": 0, "type": "مصبوبة في الموقع", "label": "الخرسانة", "warranty": "لا يوجد"}, {"on": false, "key": "earth", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التأريض (بئر أرضي)", "warranty": "لا يوجد"}, {"on": false, "key": "reactor", "qty": "لا يوجد", "sell": 0, "type": "1000A", "label": "الريأكتور", "warranty": "لا يوجد"}, {"on": false, "key": "install_mech", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "الأعمال الميدانية وتثبيت الألواح", "warranty": "لا يوجد"}, {"on": false, "key": "install_elec", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "التركيبات والتوصيلات الكهربائية", "warranty": "لا يوجد"}, {"on": false, "key": "transport", "qty": "لا يوجد", "sell": 0, "type": "-", "label": "النقل", "warranty": "لا يوجد"}], "calcKW": 571.34, "sellTotal": 428236.08, "finalTotal": 492471.492, "panelLabel": "Aiko 770W", "totalPanels": 742, "invBrandName": "VEICHI", "discountTotal": 0, "netAfterManual": 428236.08, "manualDiscountAmt": 0}, "frozenTotal": 492471.492, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-10-15 10:44:39.707939+00	52	QL-202610-0012	QL-15Oct2026-P-500 HP-VEICHI 400 KW-Aiko770-FIXED-SUP-6995	0	large
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recurring_expenses (id, category, description, amount, tax_treatment, start_month, end_month, active, created_at) FROM stdin;
1	rent	\N	2200.00	none	2026-03-01	\N	t	2026-10-24 23:58:09.238652+00
2	salary	محمود الحسيني 	5000.00	none	2026-03-01	\N	t	2026-10-24 23:59:02.903419+00
\.


--
-- Data for Name: reps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reps (id, username, password_hash, display_name, active, created_at, session_version, permissions) FROM stdin;
1	ALHUSSEINI	3ba982075eba89702c1637b9ce03d8a3d8b6dce9434dd07a4c30b5525ab27850	م محمود الحسيني	t	2026-07-12 10:56:49.950578+00	2	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
2	AhmedBnHamd	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	احمد بن حمد	f	2026-07-15 20:30:09.782466+00	1	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
3	test	9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08	test	f	2026-07-22 06:30:58.215591+00	1	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
\.


--
-- Data for Name: rfq_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_items (id, rfq_id, line_no, label, qty, unit_price, unit, qty_note, alloc) FROM stdin;
9	5	1	VEICHI Combiner box 030	1.000	3400.0000	P	\N	\N
10	5	2	الكابلات - DC	2000.000	4.2500	M	كمية تقريبية — تتحدد نهائيًا عند التوريد	\N
15	7	1	النقل	12.000	\N	\N	\N	\N
11	6	1	ألواح الطاقة الشمسية	308.000	450.0000	P	\N	\N
12	6	2	الانفرتر	1.000	11099.0000	P	\N	\N
13	6	3	VEICHI Combiner box 030	1.000	\N	P	\N	\N
14	6	4	وصلات MC4	22.000	4.0000	P	\N	\N
\.


--
-- Data for Name: rfqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfqs (id, supplier_id, quote_id, quote_ref, project_id, status, notes, supplier_quote_ref, supplier_quote_date, vat_mode, valid_invoice, po_id, created_at, sent_at, quoted_at, decided_at, lump_total, is_multi) FROM stdin;
5	3	132	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	10	accepted	\N	\N	\N	excl	t	6	2026-10-27 11:54:30.838224+00	\N	2026-10-27 21:37:58.203982+00	2026-10-27 21:38:36.248256+00	\N	f
7	11	132	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	10	accepted	\N	\N	2026-10-27	none	t	8	2026-10-27 11:56:55.790273+00	\N	2026-10-27 21:45:34.481818+00	2026-10-27 21:45:49.503613+00	1950.00	f
6	2	132	QL-27Oct2026-P-200 HP-VEICHI 160 KW-Aiko770-FIXED-SUP-5688	10	accepted	\N	\N	2026-10-27	excl	t	7	2026-10-27 11:55:24.202489+00	\N	2026-10-27 12:03:24.747098+00	2026-10-27 21:41:57.107185+00	\N	f
\.


--
-- Data for Name: segment_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.segment_config (id, small_max, medium_max, large_max, updated_at) FROM stdin;
1	15	250	800	2026-10-06 21:39:29.543119+00
\.


--
-- Data for Name: service_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_tickets (id, customer_id, site_id, asset_id, project_id, ticket_number, issue_description, priority, status, assigned_engineer, resolution_notes, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_surveys (id, opportunity_id, site_id, customer_id, engineer_name, survey_date, gps_lat, gps_lng, pump_type, pump_manufacturer, pump_model, pump_hp, pump_kw, flow, head, well_depth, static_water_level, dynamic_water_level, motor_manufacturer, motor_model, motor_hp, motor_kw, motor_voltage, motor_current, motor_frequency, motor_rpm, motor_power_factor, motor_efficiency, existing_diesel_generator, generator_capacity, diesel_consumption, electricity_grid, electricity_tariff, existing_solar, hours_per_day, days_per_month, seasonal_operation, required_water_production, available_area, roof_or_ground, shading, orientation, tilt, soil, access, distance, cable_length, technical_notes, photos, documents, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, customer_id, name, region, city, location_address, gps_lat, gps_lng, google_maps_link, farm_area, agricultural_activity, number_of_wells, number_of_pumps, water_source, well_depth, required_water_flow, required_operating_hours, current_energy_source, diesel_consumption, electricity_consumption, existing_system, technical_notes, photos, documents, created_at, updated_at) FROM stdin;
1	12	125	الوسطي_-_وادي_الدواسر	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	طريق خميس بعد الصوامع	[]	[]	2026-08-13 05:16:37.922777+00	2026-08-13 05:16:37.922777+00
2	9	مزرعه الشيخ حمود بن ناصر	الوسطي_-_وادي_الدواسر	\N	https://maps.app.goo.gl/9XVWYhLYzEFqsYZRA	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	الشماليه  من الطريق الدائري	[]	[]	2026-08-16 15:02:12.778161+00	2026-08-16 15:02:12.778161+00
\.


--
-- Data for Name: supplier_bill_edits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_bill_edits (id, bill_id, supplier_id, old_values, new_values, reason, edited_by, edited_at) FROM stdin;
2	11	2	{"bill_number": null}	{"bill_number": "26-03041025"}	اضافه زقم الفاتوره	admin	2026-10-28 12:34:05.446024+00
3	18	2	{"bill_date": "2026-10-27"}	{"bill_date": "2026-06-30"}	تحديث التاريخ	admin	2026-10-28 21:45:24.024421+00
4	21	2	{"description": null}	{"description": "فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال"}	فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال	admin	2026-10-28 22:05:59.445954+00
5	20	2	{"amount": 146791.00}	{"amount": 146791.46}	اضافه الكسور	admin	2026-10-28 22:21:02.451121+00
6	19	2	{"amount": 172000.00}	{"amount": 175000.00}	0	admin	2026-10-28 22:39:37.594502+00
7	19	2	{"amount": 175000.00}	{"amount": 172000.00}	00	admin	2026-10-28 22:47:19.670116+00
\.


--
-- Data for Name: supplier_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_bills (id, supplier_id, project_id, bill_number, bill_date, amount, tax_treatment, description, project_cost_id, expense_id, created_at, purchase_order_id, doc_type, bill_group) FROM stdin;
14	3	8	0006-6891	2026-10-26	45929.62	recoverable	\N	34	\N	2026-10-26 21:37:18.027957+00	\N	invoice	\N
11	2	2	26-03041025	2026-04-04	64625.00	recoverable	\N	29	\N	2026-10-26 20:43:05.128052+00	\N	invoice	\N
22	2	8	26-09129420	2026-09-20	1840.00	recoverable	\N	42	\N	2026-10-28 12:44:02.046925+00	\N	invoice	\N
23	2	6	26-08114318	2026-08-18	9830.20	recoverable	\N	43	\N	2026-10-28 12:45:10.725903+00	\N	invoice	\N
26	2	\N	\N	2026-07-28	575.00	recoverable	\N	\N	6	2026-10-28 21:44:22.878787+00	\N	invoice	\N
21	2	7	26-09130322	2026-09-22	3102.70	recoverable	فاتوره باجمالي 5402 و متبقي منها 500 متر كابلات بقيمه 2300 ريال	41	\N	2026-10-28 12:42:40.407872+00	\N	invoice	\N
20	2	5	26-08112917	2026-08-17	146791.46	recoverable	\N	40	\N	2026-10-28 12:39:43.138811+00	\N	invoice	\N
29	11	2	\N	2026-03-19	1700.00	none	RAJHI	48	\N	2026-10-28 23:03:13.128246+00	\N	invoice	\N
30	11	5	\N	2026-07-11	2200.00	none	\N	49	\N	2026-10-28 23:04:18.237323+00	\N	invoice	\N
31	11	8	\N	2026-09-19	1800.00	none	\N	50	\N	2026-10-28 23:06:22.30172+00	\N	invoice	\N
32	11	7	\N	2026-09-19	300.00	none	\N	51	\N	2026-10-28 23:07:23.030604+00	\N	invoice	\N
33	11	4	\N	2026-08-23	2000.00	none	\N	52	\N	2026-10-28 23:08:45.122185+00	\N	invoice	\N
19	2	1	26-07090705	2026-07-05	172000.00	recoverable	\N	54	\N	2026-10-28 12:36:25.948178+00	\N	invoice	\N
12	3	\N	0006-6771	2026-09-17	14734.72	recoverable	\N	\N	8	2026-10-26 20:50:37.973909+00	\N	invoice	\N
18	2	\N	26-06088730	2026-06-30	139001.65	recoverable	\N	\N	9	2026-10-27 23:14:24.492188+00	\N	invoice	\N
\.


--
-- Data for Name: supplier_payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_payment_allocations (id, entry_id, bill_id, amount, created_at) FROM stdin;
34	24	11	50000.00	2026-10-28 22:48:17.79486+00
35	25	11	14625.00	2026-10-28 22:48:36.463318+00
39	64	19	72000.00	2026-10-28 22:50:14.461391+00
40	29	20	50000.00	2026-10-28 22:51:42.55689+00
41	30	20	95687.00	2026-10-28 22:51:55.290203+00
45	65	23	534.66	2026-10-28 22:53:09.065932+00
46	65	22	1840.00	2026-10-28 22:53:23.615053+00
47	65	21	3028.34	2026-10-28 22:53:37.661142+00
49	28	19	100000.00	2026-10-28 23:15:52.069583+00
50	26	18	100000.00	2026-10-28 23:18:13.966502+00
51	33	18	39001.65	2026-10-28 23:18:38.534927+00
52	33	20	298.35	2026-10-28 23:19:28.882942+00
53	31	23	5000.00	2026-10-28 23:19:28.882942+00
55	32	23	4295.54	2026-10-28 23:19:52.27545+00
58	34	14	45765.28	2026-10-28 23:23:22.193305+00
60	35	14	164.34	2026-10-28 23:27:12.827513+00
61	35	12	0.66	2026-10-28 23:34:26.803983+00
62	34	12	14734.06	2026-10-28 23:35:06.118584+00
63	32	21	74.36	2026-10-28 23:49:04.022121+00
64	32	20	806.11	2026-10-28 23:49:13.073282+00
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, vat_number, phone, notes, active, created_at) FROM stdin;
2	افكار-AFKAR.Co	311674749800003	0544576566	\N	t	2026-10-25 09:53:35.118914+00
3	شركه اشراق للتجارة -Eshraq	312855595400003	0554355091	\N	t	2026-10-25 23:07:39.780053+00
11	MAHMOUD ABO ZAID	\N	0595193474	\N	t	2026-10-27 11:56:08.892395+00
\.


--
-- Data for Name: technical_studies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technical_studies (id, opportunity_id, site_survey_id, quote_id, pv_capacity, number_of_panels, panel_model, panel_wattage, inverter, inverter_capacity, pump, vfd, structure, dc_cables, ac_cables, protection, combiner_boxes, monitoring, expected_production, expected_operating_hours, estimated_diesel_saving, estimated_electricity_saving, capex, opex, estimated_roi, payback_period, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: treasury_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_accounts (id, name, kind, holder, opening_balance, opening_date, active, created_at) FROM stdin;
2	ANB	bank	\N	0.00	2026-03-08	t	2026-10-25 09:37:11.840928+00
1	محمود الحسيني / بنك الراجحي	cash	\N	0.00	2026-03-08	t	2026-10-25 09:37:11.840928+00
\.


--
-- Data for Name: treasury_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_entries (id, entry_date, account_id, direction, amount, kind, method, reference, notes, project_id, supplier_id, bill_id, payment_id, expense_id, distribution_id, transfer_group, created_by, created_at, project_cost_id, purchase_order_id, payment_group) FROM stdin;
5	2026-10-25	2	in	74000.00	customer_receipt	bank_transfer	\N	\N	10	\N	\N	11	\N	\N	\N	admin	2026-10-25 09:59:34.525436+00	\N	\N	\N
6	2026-10-25	2	in	70000.00	customer_receipt	bank_transfer	\N	\N	10	\N	\N	10	\N	\N	\N	admin	2026-10-25 09:59:44.490889+00	\N	\N	\N
14	2026-09-20	2	in	5403.00	customer_receipt	\N	\N	تحويل الي فيتشي	7	\N	\N	5	\N	\N	\N	admin	2026-10-25 16:53:06.965045+00	\N	\N	\N
15	2026-09-23	2	in	14570.00	customer_receipt	bank_transfer	\N	مباشر الي اشراق	7	\N	\N	6	\N	\N	\N	admin	2026-10-25 16:53:11.606899+00	\N	\N	\N
16	2026-03-15	2	in	85000.00	customer_receipt	bank_transfer	\N	\N	2	\N	\N	13	\N	\N	\N	admin	2026-10-25 16:53:18.533837+00	\N	\N	\N
17	2026-09-16	2	in	52000.00	customer_receipt	bank_transfer	\N	\N	8	\N	\N	4	\N	\N	\N	admin	2026-10-25 16:56:33.89638+00	\N	\N	\N
18	2026-08-13	2	in	45000.00	customer_receipt	bank_transfer	\N	\N	4	\N	\N	16	\N	\N	\N	admin	2026-10-26 06:47:06.408828+00	\N	\N	\N
13	2026-06-29	2	in	175000.00	customer_receipt	bank_transfer	\N	\N	5	\N	\N	9	\N	\N	\N	admin	2026-10-25 16:52:56.878469+00	\N	\N	\N
19	2026-08-12	2	in	55000.00	customer_receipt	bank_transfer	\N	\N	3	\N	\N	15	\N	\N	\N	admin	2026-10-26 06:53:26.245475+00	\N	\N	\N
29	2026-08-13	2	out	50000.00	supplier_payment	bank_transfer	500001986152	\N	\N	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:57:38.775893+00	\N	\N	\N
30	2026-08-16	2	out	95687.00	supplier_payment	bank_transfer	500001999581	\N	\N	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:58:19.182304+00	\N	\N	\N
46	2026-04-04	2	out	1372.00	expense	cash	\N	MANPOWER	2	\N	\N	\N	\N	\N	\N	admin	2026-10-26 20:38:16.75535+00	25	\N	\N
48	2026-04-04	2	out	3835.00	expense	bank_transfer	\N	CONCRETE	2	\N	\N	\N	\N	\N	\N	admin	2026-10-26 20:40:03.960797+00	27	\N	\N
49	2026-04-04	2	out	359.00	expense	cash	\N	accessories 	2	\N	\N	\N	\N	\N	\N	admin	2026-10-26 20:41:21.23731+00	28	\N	\N
51	2026-04-04	2	out	680.00	expense	cash	\N	fasilities 	2	\N	\N	\N	\N	\N	\N	admin	2026-10-26 20:52:54.501731+00	32	\N	\N
52	2026-08-18	1	in	5706.00	customer_receipt	bank_transfer	\N	\N	6	\N	\N	21	\N	\N	\N	admin	2026-10-26 21:43:25.904626+00	\N	\N	\N
53	2026-08-16	1	in	5000.00	customer_receipt	bank_transfer	\N	\N	6	\N	\N	22	\N	\N	\N	admin	2026-10-26 21:44:22.959185+00	\N	\N	\N
57	2026-10-27	2	in	40000.00	customer_receipt	bank_transfer	500002667091	\N	10	\N	\N	23	\N	\N	\N	admin	2026-10-27 11:17:12.565262+00	\N	\N	\N
24	2026-03-16	2	out	50000.00	supplier_payment	bank_transfer	500000673162	مبارك 60حصان/ محمد مسلم 	2	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:52:10.71674+00	\N	\N	\N
25	2026-03-18	2	out	14625.00	supplier_payment	bank_transfer	9118032600926165	مبارك فاضل 60حصان/ محمد مسلم 	2	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:53:36.821049+00	\N	\N	\N
58	2026-10-28	1	in	17000.00	customer_receipt	bank_transfer	\N	\N	10	\N	\N	24	\N	\N	\N	admin	2026-10-28 12:25:55.447362+00	\N	\N	\N
62	2026-10-28	2	out	100000.00	supplier_payment	bank_transfer	\N	\N	10	2	\N	\N	\N	\N	\N	admin	2026-10-28 21:36:40.752509+00	\N	7	\N
63	2026-07-26	2	out	575.00	supplier_payment	bank_transfer	\N	BARQ - SCREENSHOOT	\N	2	26	\N	\N	\N	\N	admin	2026-10-28 21:53:17.475202+00	\N	\N	\N
64	2026-07-01	2	out	72000.00	supplier_payment	bank_transfer	\N	\N	1	2	\N	\N	\N	\N	\N	admin	2026-10-28 21:56:05.388918+00	\N	\N	\N
65	2026-09-20	2	out	5403.00	supplier_payment	bank_transfer	\N	\N	7	2	\N	\N	\N	\N	\N	admin	2026-10-28 22:17:00.047442+00	\N	\N	\N
66	2026-08-01	2	in	175000.00	customer_receipt	bank_transfer	\N	\N	1	\N	\N	26	\N	\N	\N	admin	2026-10-28 22:44:13.088906+00	\N	\N	\N
23	2026-10-26	2	out	50000.00	supplier_payment	bank_transfer	\N	تحت حساب مشروع الشيخ حمود 200 حصان/ سعود 	10	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:50:22.815362+00	\N	7	\N
67	2026-04-04	2	out	417.25	expense	cash	\N	TRANSPORTATIONS	2	\N	\N	\N	\N	\N	\N	admin	2026-10-28 23:12:51.649991+00	53	\N	\N
28	2026-07-01	2	out	100000.00	supplier_payment	bank_transfer	500001584188	حاظر ابومسفر 200حصان	1	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:56:36.258651+00	\N	\N	\N
26	2026-06-28	2	out	100000.00	supplier_payment	bank_transfer	500001553445	مبارك125حصان	5	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:54:37.559367+00	\N	\N	\N
33	2026-06-29	2	out	39300.00	supplier_payment	bank_transfer	 500001565851	\N	5	2	\N	\N	\N	\N	\N	admin	2026-10-26 12:02:37.246458+00	\N	\N	\N
31	2026-08-16	1	out	5000.00	supplier_payment	bank_transfer	9116082600870274	\N	6	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:59:19.078655+00	\N	\N	\N
32	2026-08-17	1	out	5400.00	supplier_payment	bank_transfer	9117082600527266	\N	6	2	\N	\N	\N	\N	\N	admin	2026-10-26 11:59:59.946304+00	\N	\N	\N
34	2026-09-16	2	out	60500.00	supplier_payment	bank_transfer	\N	129 لوح JA + COMBINE 8LINE	8	3	\N	\N	\N	\N	\N	admin	2026-10-26 12:04:29.422699+00	\N	\N	\N
35	2026-09-17	1	out	165.00	supplier_payment	bank_transfer	\N	فرق تحويلات	7	3	\N	\N	\N	\N	\N	admin	2026-10-26 12:05:19.182112+00	\N	\N	\N
\.


--
-- Data for Name: treasury_entry_edits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_entry_edits (id, entry_id, kind, old_values, new_values, reason, edited_by, edited_at) FROM stdin;
5	23	supplier_payment	{"project_id": null}	{"project_id": 10}	اضافه اسم المشروع	admin	2026-10-27 02:40:26.217801+00
6	24	supplier_payment	{"project_id": null}	{"project_id": 2}	ربط المشروع	admin	2026-10-27 23:08:25.441158+00
7	25	supplier_payment	{"project_id": null}	{"project_id": 2}	ربط المشروع	admin	2026-10-27 23:08:59.60229+00
8	58	customer_receipt	{"method": "cheque"}	{"method": "bank_transfer"}	BANK TRANSFER	admin	2026-10-28 12:31:37.753462+00
9	23	supplier_payment	{"purchase_order_id": null}	{"purchase_order_id": 7}	اضافة امر الشراء	admin	2026-10-28 22:59:10.579612+00
10	31	supplier_payment	{"project_id": null}	{"project_id": 6}	PROJECT	admin	2026-10-28 23:19:28.882942+00
11	32	supplier_payment	{"project_id": null}	{"project_id": 6}	PROJECT	admin	2026-10-28 23:19:52.27545+00
\.


--
-- Data for Name: warranty_category_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_category_map (category, warranty_class, requires_serial) FROM stdin;
ألواح الطاقة الشمسية	solar_panel	f
شواحن/انفرترات هجين MPPT	inverter	t
انفرتر مضخات VEICHI	inverter	t
صناديق التجميع (Combiner Box)	combiner_box	f
بطاريات ليثيوم	battery	t
الريأكتور (Reactor)	reactor	f
قواطع وفيوزات DC	dc_protection	f
الكابلات والوصلات (MC4)	cables	f
\.


--
-- Data for Name: warranty_certificates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_certificates (id, certificate_number, invoice_id, line_index, revision, customer_id, asset_id, serial_normalized, warranty_start, warranty_end, snapshot, status, voided_at, void_reason, issued_by, issued_at) FROM stdin;
\.


--
-- Data for Name: warranty_print_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_print_log (id, certificate_id, printed_by, printed_at) FROM stdin;
\.


--
-- Data for Name: warranty_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_rules (id, catalog_category, brand, warranty_years, performance_warranty_years, notes, updated_at) FROM stdin;
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activities_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assets_id_seq', 30, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 363, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, true);


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.crm_interactions_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 54, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 10, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 40, true);


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_contracts_id_seq', 1, false);


--
-- Name: opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.opportunities_id_seq', 20, true);


--
-- Name: partner_distributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partner_distributions_id_seq', 1, false);


--
-- Name: partner_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partner_shares_id_seq', 4, true);


--
-- Name: partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.partners_id_seq', 2, true);


--
-- Name: payment_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_edits_id_seq', 3, true);


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_milestones_id_seq', 17, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 26, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 109, true);


--
-- Name: project_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_costs_id_seq', 56, true);


--
-- Name: project_discounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_discounts_id_seq', 1, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 10, true);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 11, true);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotes_id_seq', 132, true);


--
-- Name: recurring_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recurring_expenses_id_seq', 2, true);


--
-- Name: reps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reps_id_seq', 3, true);


--
-- Name: rfq_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rfq_items_id_seq', 18, true);


--
-- Name: rfqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rfqs_id_seq', 9, true);


--
-- Name: service_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_tickets_id_seq', 1, false);


--
-- Name: site_surveys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_surveys_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: supplier_bill_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_bill_edits_id_seq', 7, true);


--
-- Name: supplier_bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_bills_id_seq', 35, true);


--
-- Name: supplier_payment_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_payment_allocations_id_seq', 64, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 11, true);


--
-- Name: technical_studies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.technical_studies_id_seq', 1, false);


--
-- Name: treasury_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.treasury_accounts_id_seq', 4, true);


--
-- Name: treasury_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.treasury_entries_id_seq', 67, true);


--
-- Name: treasury_entry_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.treasury_entry_edits_id_seq', 11, true);


--
-- Name: warranty_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warranty_certificates_id_seq', 3, true);


--
-- Name: warranty_print_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warranty_print_log_id_seq', 1, false);


--
-- Name: warranty_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warranty_rules_id_seq', 4, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: admin_secret admin_secret_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_secret
    ADD CONSTRAINT admin_secret_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: catalog_category_map catalog_category_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_category_map
    ADD CONSTRAINT catalog_category_map_pkey PRIMARY KEY (catalog_category);


--
-- Name: company_profile company_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_profile
    ADD CONSTRAINT company_profile_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: crm_interactions crm_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_pkey PRIMARY KEY (id);


--
-- Name: crm_settings crm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_settings
    ADD CONSTRAINT crm_settings_pkey PRIMARY KEY (id);


--
-- Name: customers customers_phone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_key UNIQUE (phone);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: einvoice_config einvoice_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.einvoice_config
    ADD CONSTRAINT einvoice_config_pkey PRIMARY KEY (id);


--
-- Name: einvoice_counters einvoice_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.einvoice_counters
    ADD CONSTRAINT einvoice_counters_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: finance_settings finance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_settings
    ADD CONSTRAINT finance_settings_pkey PRIMARY KEY (id);


--
-- Name: invoice_counters invoice_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_counters
    ADD CONSTRAINT invoice_counters_pkey PRIMARY KEY (counter_key);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: maintenance_contracts maintenance_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: partner_distributions partner_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_distributions
    ADD CONSTRAINT partner_distributions_pkey PRIMARY KEY (id);


--
-- Name: partner_shares partner_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_shares
    ADD CONSTRAINT partner_shares_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: payment_edits payment_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_edits
    ADD CONSTRAINT payment_edits_pkey PRIMARY KEY (id);


--
-- Name: payment_milestones payment_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT payment_milestones_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pricing_config pricing_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_config
    ADD CONSTRAINT pricing_config_pkey PRIMARY KEY (id);


--
-- Name: product_families product_families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_families
    ADD CONSTRAINT product_families_pkey PRIMARY KEY (prefix);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_product_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_code_key UNIQUE (product_code);


--
-- Name: project_costs project_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_pkey PRIMARY KEY (id);


--
-- Name: project_discounts project_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_discounts
    ADD CONSTRAINT project_discounts_pkey PRIMARY KEY (id);


--
-- Name: project_finance_flags project_finance_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_finance_flags
    ADD CONSTRAINT project_finance_flags_pkey PRIMARY KEY (project_id);


--
-- Name: projects projects_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: quote_financials quote_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_financials
    ADD CONSTRAINT quote_financials_pkey PRIMARY KEY (quote_id);


--
-- Name: quote_ref_counters quote_ref_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_ref_counters
    ADD CONSTRAINT quote_ref_counters_pkey PRIMARY KEY (counter_key);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: reps reps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_pkey PRIMARY KEY (id);


--
-- Name: reps reps_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_username_key UNIQUE (username);


--
-- Name: rfq_items rfq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_pkey PRIMARY KEY (id);


--
-- Name: rfq_items rfq_items_rfq_id_line_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_rfq_id_line_no_key UNIQUE (rfq_id, line_no);


--
-- Name: rfqs rfqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_pkey PRIMARY KEY (id);


--
-- Name: segment_config segment_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.segment_config
    ADD CONSTRAINT segment_config_pkey PRIMARY KEY (id);


--
-- Name: service_tickets service_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_pkey PRIMARY KEY (id);


--
-- Name: site_surveys site_surveys_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: site_surveys site_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: supplier_bill_edits supplier_bill_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bill_edits
    ADD CONSTRAINT supplier_bill_edits_pkey PRIMARY KEY (id);


--
-- Name: supplier_bills supplier_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_pkey PRIMARY KEY (id);


--
-- Name: supplier_payment_allocations supplier_payment_allocations_entry_id_bill_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT supplier_payment_allocations_entry_id_bill_id_key UNIQUE (entry_id, bill_id);


--
-- Name: supplier_payment_allocations supplier_payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT supplier_payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: technical_studies technical_studies_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: technical_studies technical_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_pkey PRIMARY KEY (id);


--
-- Name: treasury_accounts treasury_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_pkey PRIMARY KEY (id);


--
-- Name: treasury_entries treasury_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_pkey PRIMARY KEY (id);


--
-- Name: treasury_entry_edits treasury_entry_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entry_edits
    ADD CONSTRAINT treasury_entry_edits_pkey PRIMARY KEY (id);


--
-- Name: warranty_category_map warranty_category_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_category_map
    ADD CONSTRAINT warranty_category_map_pkey PRIMARY KEY (category);


--
-- Name: warranty_certificates warranty_certificates_certificate_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_certificates
    ADD CONSTRAINT warranty_certificates_certificate_number_key UNIQUE (certificate_number);


--
-- Name: warranty_certificates warranty_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_certificates
    ADD CONSTRAINT warranty_certificates_pkey PRIMARY KEY (id);


--
-- Name: warranty_print_log warranty_print_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_print_log
    ADD CONSTRAINT warranty_print_log_pkey PRIMARY KEY (id);


--
-- Name: warranty_rules warranty_rules_catalog_category_brand_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_rules
    ADD CONSTRAINT warranty_rules_catalog_category_brand_key UNIQUE (catalog_category, brand);


--
-- Name: warranty_rules warranty_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_rules
    ADD CONSTRAINT warranty_rules_pkey PRIMARY KEY (id);


--
-- Name: customers_last_quote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_last_quote_idx ON public.customers USING btree (last_quote_at DESC);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: expenses_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_date_idx ON public.expenses USING btree (expense_date);


--
-- Name: expenses_recurring_month_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX expenses_recurring_month_uq ON public.expenses USING btree (recurring_id, expense_date) WHERE (recurring_id IS NOT NULL);


--
-- Name: idx_activities_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activities_customer ON public.activities USING btree (customer_id);


--
-- Name: idx_activities_opportunity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activities_opportunity ON public.activities USING btree (opportunity_id);


--
-- Name: idx_assets_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_customer ON public.assets USING btree (customer_id);


--
-- Name: idx_assets_opportunity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_opportunity_id ON public.assets USING btree (opportunity_id);


--
-- Name: idx_assets_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_site_id ON public.assets USING btree (site_id);


--
-- Name: idx_assets_warranty_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_warranty_end ON public.assets USING btree (warranty_end_date);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_contacts_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contacts_customer ON public.contacts USING btree (customer_id);


--
-- Name: idx_crm_interactions_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crm_interactions_customer ON public.crm_interactions USING btree (customer_id);


--
-- Name: idx_customers_next_follow_up; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_next_follow_up ON public.customers USING btree (next_follow_up_date);


--
-- Name: idx_invoices_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_customer_id ON public.invoices USING btree (customer_id);


--
-- Name: idx_invoices_milestone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_milestone_id ON public.invoices USING btree (milestone_id);


--
-- Name: idx_invoices_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_project ON public.invoices USING btree (project_id);


--
-- Name: idx_invoices_related_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_related_invoice_id ON public.invoices USING btree (related_invoice_id);


--
-- Name: idx_invoices_source_calc_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_source_calc_quote_id ON public.invoices USING btree (source_calc_quote_id);


--
-- Name: idx_invoices_source_quotation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_source_quotation_id ON public.invoices USING btree (source_quotation_id);


--
-- Name: idx_maint_contracts_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maint_contracts_customer ON public.maintenance_contracts USING btree (customer_id);


--
-- Name: idx_maint_contracts_next_visit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maint_contracts_next_visit ON public.maintenance_contracts USING btree (next_visit_date);


--
-- Name: idx_maintenance_contracts_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_contracts_project_id ON public.maintenance_contracts USING btree (project_id);


--
-- Name: idx_milestones_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_milestones_project ON public.payment_milestones USING btree (project_id);


--
-- Name: idx_opportunities_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_contact_id ON public.opportunities USING btree (contact_id);


--
-- Name: idx_opportunities_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_site_id ON public.opportunities USING btree (site_id);


--
-- Name: idx_opps_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opps_customer ON public.opportunities USING btree (customer_id);


--
-- Name: idx_payments_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_project ON public.payments USING btree (project_id);


--
-- Name: idx_project_costs_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_costs_project ON public.project_costs USING btree (project_id);


--
-- Name: idx_projects_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_customer ON public.projects USING btree (customer_id);


--
-- Name: idx_projects_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_site_id ON public.projects USING btree (site_id);


--
-- Name: idx_quotations_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_customer_id ON public.quotations USING btree (customer_id);


--
-- Name: idx_quotations_linked_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_linked_quote_id ON public.quotations USING btree (linked_quote_id);


--
-- Name: idx_quotations_opportunity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_opportunity ON public.quotations USING btree (opportunity_id);


--
-- Name: idx_service_tickets_asset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_asset_id ON public.service_tickets USING btree (asset_id);


--
-- Name: idx_service_tickets_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_project_id ON public.service_tickets USING btree (project_id);


--
-- Name: idx_service_tickets_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_site_id ON public.service_tickets USING btree (site_id);


--
-- Name: idx_site_surveys_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_surveys_customer ON public.site_surveys USING btree (customer_id);


--
-- Name: idx_site_surveys_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_surveys_site_id ON public.site_surveys USING btree (site_id);


--
-- Name: idx_sites_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_customer ON public.sites USING btree (customer_id);


--
-- Name: idx_technical_studies_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_technical_studies_quote_id ON public.technical_studies USING btree (quote_id);


--
-- Name: idx_technical_studies_site_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_technical_studies_site_survey_id ON public.technical_studies USING btree (site_survey_id);


--
-- Name: idx_tickets_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_customer ON public.service_tickets USING btree (customer_id);


--
-- Name: invoices_icv_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX invoices_icv_uq ON public.invoices USING btree (icv) WHERE (icv IS NOT NULL);


--
-- Name: invoices_project_id_null_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_project_id_null_idx ON public.invoices USING btree (created_at) WHERE (project_id IS NULL);


--
-- Name: opportunities_follow_up_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX opportunities_follow_up_idx ON public.opportunities USING btree (next_follow_up_date) WHERE (stage <> ALL (ARRAY['won'::text, 'lost'::text]));


--
-- Name: opportunities_sales_person_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX opportunities_sales_person_idx ON public.opportunities USING btree (sales_person);


--
-- Name: opportunities_segment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX opportunities_segment_idx ON public.opportunities USING btree (segment);


--
-- Name: opportunities_stage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX opportunities_stage_idx ON public.opportunities USING btree (stage);


--
-- Name: partner_shares_partner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX partner_shares_partner_idx ON public.partner_shares USING btree (partner_id);


--
-- Name: payment_edits_payment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_edits_payment_idx ON public.payment_edits USING btree (payment_id);


--
-- Name: payment_edits_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_edits_project_idx ON public.payment_edits USING btree (project_id);


--
-- Name: products_brand_part_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_brand_part_uq ON public.products USING btree (lower(brand), lower(part_number)) WHERE ((part_number IS NOT NULL) AND (brand IS NOT NULL));


--
-- Name: products_catalog_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_catalog_name_uq ON public.products USING btree (catalog_name) WHERE (catalog_name IS NOT NULL);


--
-- Name: products_family_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_family_idx ON public.products USING btree (family);


--
-- Name: project_discounts_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_discounts_project_idx ON public.project_discounts USING btree (project_id);


--
-- Name: purchase_orders_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_project_idx ON public.purchase_orders USING btree (project_id);


--
-- Name: purchase_orders_rfq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_rfq_idx ON public.purchase_orders USING btree (rfq_id) WHERE (rfq_id IS NOT NULL);


--
-- Name: purchase_orders_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_supplier_idx ON public.purchase_orders USING btree (supplier_id);


--
-- Name: quotes_client_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_client_phone_idx ON public.quotes USING btree (client_phone);


--
-- Name: quotes_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_customer_id_idx ON public.quotes USING btree (customer_id);


--
-- Name: quotes_ref_code_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX quotes_ref_code_uq ON public.quotes USING btree (ref_code) WHERE (ref_code IS NOT NULL);


--
-- Name: quotes_segment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_segment_idx ON public.quotes USING btree (segment);


--
-- Name: rfqs_quote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rfqs_quote_idx ON public.rfqs USING btree (quote_id);


--
-- Name: rfqs_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rfqs_supplier_idx ON public.rfqs USING btree (supplier_id);


--
-- Name: spa_bill_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spa_bill_idx ON public.supplier_payment_allocations USING btree (bill_id);


--
-- Name: supplier_bill_edits_bill_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_bill_edits_bill_idx ON public.supplier_bill_edits USING btree (bill_id);


--
-- Name: supplier_bills_bgroup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_bills_bgroup_idx ON public.supplier_bills USING btree (bill_group) WHERE (bill_group IS NOT NULL);


--
-- Name: supplier_bills_po_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_bills_po_idx ON public.supplier_bills USING btree (purchase_order_id);


--
-- Name: supplier_bills_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_bills_project_idx ON public.supplier_bills USING btree (project_id);


--
-- Name: supplier_bills_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_bills_supplier_idx ON public.supplier_bills USING btree (supplier_id);


--
-- Name: suppliers_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX suppliers_name_uq ON public.suppliers USING btree (lower(name));


--
-- Name: treasury_entries_account_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_account_date_idx ON public.treasury_entries USING btree (account_id, entry_date, id);


--
-- Name: treasury_entries_bill_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_bill_idx ON public.treasury_entries USING btree (bill_id);


--
-- Name: treasury_entries_cost_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_cost_idx ON public.treasury_entries USING btree (project_cost_id);


--
-- Name: treasury_entries_payment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_payment_idx ON public.treasury_entries USING btree (payment_id);


--
-- Name: treasury_entries_pgroup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_pgroup_idx ON public.treasury_entries USING btree (payment_group) WHERE (payment_group IS NOT NULL);


--
-- Name: treasury_entries_po_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_po_idx ON public.treasury_entries USING btree (purchase_order_id);


--
-- Name: treasury_entries_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_project_idx ON public.treasury_entries USING btree (project_id);


--
-- Name: treasury_entries_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entries_supplier_idx ON public.treasury_entries USING btree (supplier_id);


--
-- Name: treasury_entry_edits_entry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_entry_edits_entry_idx ON public.treasury_entry_edits USING btree (entry_id, edited_at DESC);


--
-- Name: uq_invoices_one_credit_note; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_invoices_one_credit_note ON public.invoices USING btree (related_invoice_id) WHERE (document_type = 'credit_note'::text);


--
-- Name: uq_payments_milestone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_payments_milestone_id ON public.payments USING btree (milestone_id) WHERE (milestone_id IS NOT NULL);


--
-- Name: warranty_cert_active_line_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX warranty_cert_active_line_uq ON public.warranty_certificates USING btree (invoice_id, line_index) WHERE (status = 'active'::text);


--
-- Name: warranty_cert_active_serial_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX warranty_cert_active_serial_uq ON public.warranty_certificates USING btree (serial_normalized) WHERE ((status = 'active'::text) AND (serial_normalized IS NOT NULL));


--
-- Name: warranty_cert_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warranty_cert_customer_idx ON public.warranty_certificates USING btree (customer_id);


--
-- Name: v_account_balances _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_account_balances WITH (security_invoker='true') AS
 SELECT a.id AS account_id,
    a.name,
    a.kind,
    a.holder,
    a.active,
    a.opening_balance,
    a.opening_date,
    COALESCE(sum(
        CASE
            WHEN (e.direction = 'in'::text) THEN e.amount
            ELSE NULL::numeric
        END), (0)::numeric) AS total_in,
    COALESCE(sum(
        CASE
            WHEN (e.direction = 'out'::text) THEN e.amount
            ELSE NULL::numeric
        END), (0)::numeric) AS total_out,
    ((a.opening_balance + COALESCE(sum(
        CASE
            WHEN (e.direction = 'in'::text) THEN e.amount
            ELSE NULL::numeric
        END), (0)::numeric)) - COALESCE(sum(
        CASE
            WHEN (e.direction = 'out'::text) THEN e.amount
            ELSE NULL::numeric
        END), (0)::numeric)) AS balance
   FROM (public.treasury_accounts a
     LEFT JOIN public.treasury_entries e ON (((e.account_id = a.id) AND (e.entry_date >= a.opening_date))))
  GROUP BY a.id;


--
-- Name: assets trg_assets_warranty_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_assets_warranty_guard BEFORE DELETE OR UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.assets_warranty_guard();


--
-- Name: assets trg_assets_warranty_insert_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_assets_warranty_insert_guard BEFORE INSERT ON public.assets FOR EACH ROW EXECUTE FUNCTION public.assets_warranty_insert_guard();


--
-- Name: catalog_category_map trg_category_map_warranty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_category_map_warranty AFTER INSERT ON public.catalog_category_map FOR EACH ROW EXECUTE FUNCTION public.trg_category_map_warranty();


--
-- Name: project_costs trg_guard_linked_cost; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_linked_cost BEFORE DELETE ON public.project_costs FOR EACH ROW EXECUTE FUNCTION public.trg_guard_linked_cost();


--
-- Name: partner_distributions trg_guard_linked_distribution; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_linked_distribution BEFORE DELETE ON public.partner_distributions FOR EACH ROW EXECUTE FUNCTION public.trg_guard_linked_distribution();


--
-- Name: expenses trg_guard_linked_expense; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_linked_expense BEFORE DELETE ON public.expenses FOR EACH ROW EXECUTE FUNCTION public.trg_guard_linked_expense();


--
-- Name: invoices trg_invoices_block_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_block_delete BEFORE DELETE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_block_delete();


--
-- Name: invoices trg_invoices_block_tamper; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_block_tamper BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_block_tamper();


--
-- Name: invoices trg_invoices_enrich_warranty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_enrich_warranty BEFORE INSERT ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_enrich_warranty_items();


--
-- Name: invoices trg_invoices_require_issued_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_require_issued_at BEFORE INSERT ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_require_issued_at();


--
-- Name: invoices trg_invoices_void_warranties; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_void_warranties AFTER UPDATE OF status ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_void_warranties();


--
-- Name: payment_milestones trg_milestone_paid_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_milestone_paid_sync BEFORE UPDATE OF status ON public.payment_milestones FOR EACH ROW EXECUTE FUNCTION public.trg_milestone_paid_sync();


--
-- Name: opportunities trg_opportunities_set_segment; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_opportunities_set_segment BEFORE INSERT OR UPDATE OF estimated_capacity ON public.opportunities FOR EACH ROW EXECUTE FUNCTION public.trg_opportunities_set_segment();


--
-- Name: payments trg_payment_delete_milestone; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_payment_delete_milestone AFTER DELETE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.trg_payment_delete_milestone();


--
-- Name: payments trg_payment_match_milestone; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_payment_match_milestone BEFORE INSERT ON public.payments FOR EACH ROW EXECUTE FUNCTION public.trg_payment_match_milestone();


--
-- Name: payments trg_payments_recalc; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_payments_recalc AFTER INSERT OR DELETE OR UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.trg_payments_recalc();


--
-- Name: pricing_config trg_pricing_config_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pricing_config_sync AFTER UPDATE OF data ON public.pricing_config FOR EACH ROW WHEN ((old.data IS DISTINCT FROM new.data)) EXECUTE FUNCTION public.trg_pricing_config_sync();


--
-- Name: products trg_products_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_products_guard BEFORE INSERT OR DELETE OR UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.products_guard();


--
-- Name: projects trg_projects_contract_recalc; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_projects_contract_recalc AFTER UPDATE OF contract_value ON public.projects FOR EACH ROW EXECUTE FUNCTION public.trg_projects_contract_recalc();


--
-- Name: projects trg_projects_pipeline_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_projects_pipeline_sync AFTER INSERT OR DELETE OR UPDATE OF status ON public.projects FOR EACH ROW EXECUTE FUNCTION public.trg_projects_pipeline_sync();


--
-- Name: projects trg_projects_status_auto; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_projects_status_auto BEFORE INSERT OR UPDATE OF actual_supply_date ON public.projects FOR EACH ROW EXECUTE FUNCTION public.trg_projects_status_auto();


--
-- Name: quotations trg_quotations_set_segment; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotations_set_segment BEFORE INSERT OR UPDATE OF pump_hp ON public.quotations FOR EACH ROW EXECUTE FUNCTION public.trg_quotations_set_segment();


--
-- Name: quotes trg_quotes_a_cart_enforce; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_a_cart_enforce BEFORE INSERT ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.quotes_cart_enforce();


--
-- Name: quotes trg_quotes_auto_opportunity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_auto_opportunity AFTER INSERT ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.trg_quotes_auto_opportunity();


--
-- Name: quotes trg_quotes_bump_priority; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_bump_priority AFTER INSERT ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.trg_quotes_bump_customer_priority();


--
-- Name: quotes trg_quotes_mark_contacted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_mark_contacted AFTER INSERT ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.trg_quotes_mark_contacted();


--
-- Name: quotes trg_quotes_set_segment; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_set_segment BEFORE INSERT OR UPDATE OF hp ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.trg_quotes_set_segment();


--
-- Name: quotes trg_quotes_stamp_codes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_quotes_stamp_codes BEFORE INSERT ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.quotes_stamp_codes();


--
-- Name: warranty_certificates trg_warranty_cert_after_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_warranty_cert_after_delete AFTER DELETE ON public.warranty_certificates FOR EACH ROW EXECUTE FUNCTION public.warranty_cert_after_delete();


--
-- Name: warranty_certificates trg_warranty_cert_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_warranty_cert_guard BEFORE DELETE OR UPDATE ON public.warranty_certificates FOR EACH ROW EXECUTE FUNCTION public.warranty_cert_guard();


--
-- Name: activities activities_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: activities activities_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: assets assets_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: assets assets_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE SET NULL;


--
-- Name: assets assets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: catalog_category_map catalog_category_map_family_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_category_map
    ADD CONSTRAINT catalog_category_map_family_fkey FOREIGN KEY (family) REFERENCES public.product_families(prefix);


--
-- Name: contacts contacts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: crm_interactions crm_interactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_recurring_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_recurring_id_fkey FOREIGN KEY (recurring_id) REFERENCES public.recurring_expenses(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_milestone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES public.payment_milestones(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_related_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_related_invoice_id_fkey FOREIGN KEY (related_invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_source_calc_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_source_calc_quote_id_fkey FOREIGN KEY (source_calc_quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_source_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_source_quotation_id_fkey FOREIGN KEY (source_quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- Name: maintenance_contracts maintenance_contracts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: maintenance_contracts maintenance_contracts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: opportunities opportunities_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: opportunities opportunities_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: opportunities opportunities_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: partner_distributions partner_distributions_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_distributions
    ADD CONSTRAINT partner_distributions_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id);


--
-- Name: partner_shares partner_shares_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_shares
    ADD CONSTRAINT partner_shares_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON DELETE CASCADE;


--
-- Name: payment_edits payment_edits_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_edits
    ADD CONSTRAINT payment_edits_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: payment_milestones payment_milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT payment_milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: payments payments_milestone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES public.payment_milestones(id) ON DELETE SET NULL;


--
-- Name: payments payments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: products products_family_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_family_fkey FOREIGN KEY (family) REFERENCES public.product_families(prefix);


--
-- Name: project_costs project_costs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_discounts project_discounts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_discounts
    ADD CONSTRAINT project_discounts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_finance_flags project_finance_flags_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_finance_flags
    ADD CONSTRAINT project_finance_flags_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: projects projects_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: projects projects_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfqs(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: quotations quotations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_linked_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_linked_quote_id_fkey FOREIGN KEY (linked_quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: quotations quotations_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: quote_financials quote_financials_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_financials
    ADD CONSTRAINT quote_financials_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: rfq_items rfq_items_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfqs(id) ON DELETE CASCADE;


--
-- Name: rfqs rfqs_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id) ON DELETE SET NULL;


--
-- Name: rfqs rfqs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: rfqs rfqs_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: rfqs rfqs_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: service_tickets service_tickets_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: service_tickets service_tickets_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: service_tickets service_tickets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: service_tickets service_tickets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: site_surveys site_surveys_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: site_surveys site_surveys_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: site_surveys site_surveys_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: sites sites_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: supplier_bills supplier_bills_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES public.expenses(id) ON DELETE SET NULL;


--
-- Name: supplier_bills supplier_bills_project_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_project_cost_id_fkey FOREIGN KEY (project_cost_id) REFERENCES public.project_costs(id) ON DELETE SET NULL;


--
-- Name: supplier_bills supplier_bills_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: supplier_bills supplier_bills_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE RESTRICT;


--
-- Name: supplier_bills supplier_bills_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bills
    ADD CONSTRAINT supplier_bills_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: supplier_payment_allocations supplier_payment_allocations_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT supplier_payment_allocations_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.supplier_bills(id) ON DELETE CASCADE;


--
-- Name: supplier_payment_allocations supplier_payment_allocations_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT supplier_payment_allocations_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.treasury_entries(id) ON DELETE CASCADE;


--
-- Name: technical_studies technical_studies_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: technical_studies technical_studies_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: technical_studies technical_studies_site_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_site_survey_id_fkey FOREIGN KEY (site_survey_id) REFERENCES public.site_surveys(id) ON DELETE SET NULL;


--
-- Name: treasury_entries treasury_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.treasury_accounts(id);


--
-- Name: treasury_entries treasury_entries_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.supplier_bills(id);


--
-- Name: treasury_entries treasury_entries_distribution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_distribution_id_fkey FOREIGN KEY (distribution_id) REFERENCES public.partner_distributions(id) ON DELETE RESTRICT;


--
-- Name: treasury_entries treasury_entries_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES public.expenses(id) ON DELETE RESTRICT;


--
-- Name: treasury_entries treasury_entries_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON DELETE CASCADE;


--
-- Name: treasury_entries treasury_entries_project_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_project_cost_id_fkey FOREIGN KEY (project_cost_id) REFERENCES public.project_costs(id) ON DELETE RESTRICT;


--
-- Name: treasury_entries treasury_entries_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: treasury_entries treasury_entries_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE SET NULL;


--
-- Name: treasury_entries treasury_entries_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_entries
    ADD CONSTRAINT treasury_entries_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: warranty_certificates warranty_certificates_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_certificates
    ADD CONSTRAINT warranty_certificates_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: warranty_certificates warranty_certificates_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_certificates
    ADD CONSTRAINT warranty_certificates_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: warranty_certificates warranty_certificates_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_certificates
    ADD CONSTRAINT warranty_certificates_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: warranty_print_log warranty_print_log_certificate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_print_log
    ADD CONSTRAINT warranty_print_log_certificate_id_fkey FOREIGN KEY (certificate_id) REFERENCES public.warranty_certificates(id) ON DELETE CASCADE;


--
-- Name: activities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_secret; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_secret ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings anyone can read settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "anyone can read settings" ON public.app_settings FOR SELECT USING (true);


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: catalog_category_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.catalog_category_map ENABLE ROW LEVEL SECURITY;

--
-- Name: company_profile; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_profile ENABLE ROW LEVEL SECURITY;

--
-- Name: contacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crm_interactions ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crm_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: einvoice_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.einvoice_config ENABLE ROW LEVEL SECURITY;

--
-- Name: einvoice_counters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.einvoice_counters ENABLE ROW LEVEL SECURITY;

--
-- Name: expenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.finance_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_counters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_counters ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings only authenticated can update settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "only authenticated can update settings" ON public.app_settings FOR UPDATE USING ((( SELECT auth.role() AS role) = 'authenticated'::text));


--
-- Name: opportunities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;

--
-- Name: partner_distributions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.partner_distributions ENABLE ROW LEVEL SECURITY;

--
-- Name: partner_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.partner_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: partners; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_edits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_edits ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_milestones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_milestones ENABLE ROW LEVEL SECURITY;

--
-- Name: payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

--
-- Name: pricing_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pricing_config ENABLE ROW LEVEL SECURITY;

--
-- Name: product_families; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_families ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

--
-- Name: project_costs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_costs ENABLE ROW LEVEL SECURITY;

--
-- Name: project_discounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_discounts ENABLE ROW LEVEL SECURITY;

--
-- Name: project_finance_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_finance_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: quotations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quotations ENABLE ROW LEVEL SECURITY;

--
-- Name: quote_financials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quote_financials ENABLE ROW LEVEL SECURITY;

--
-- Name: quote_ref_counters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quote_ref_counters ENABLE ROW LEVEL SECURITY;

--
-- Name: quotes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;

--
-- Name: recurring_expenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recurring_expenses ENABLE ROW LEVEL SECURITY;

--
-- Name: reps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reps ENABLE ROW LEVEL SECURITY;

--
-- Name: rfq_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rfq_items ENABLE ROW LEVEL SECURITY;

--
-- Name: rfqs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rfqs ENABLE ROW LEVEL SECURITY;

--
-- Name: segment_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.segment_config ENABLE ROW LEVEL SECURITY;

--
-- Name: service_tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: site_surveys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.site_surveys ENABLE ROW LEVEL SECURITY;

--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: supplier_bill_edits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.supplier_bill_edits ENABLE ROW LEVEL SECURITY;

--
-- Name: supplier_bills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.supplier_bills ENABLE ROW LEVEL SECURITY;

--
-- Name: supplier_payment_allocations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.supplier_payment_allocations ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: technical_studies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.technical_studies ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treasury_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treasury_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_entry_edits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treasury_entry_edits ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_category_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warranty_category_map ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_certificates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warranty_certificates ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_print_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warranty_print_log ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warranty_rules ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict qw6NzOHu54DVL1C8oxp9MY0bNyi9xBw7X6qcqIUxiyZy2zdBhRERjg8RZcshubQ

