--
-- PostgreSQL database dump
--

\restrict Qotg90XoqDKPSwVslPWpaIzYvLhO9mTQyPPzaYHgkyr3PU0dGgbzRCFrpbc9qgW

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: einvoice_go_live(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.einvoice_go_live() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare n integer;
begin
  if not coalesce((select trial_mode from public.einvoice_config where id = 1), false) then
    raise exception 'Already live.';
  end if;
  perform set_config('app.allow_invoice_delete', 'on', true);
  delete from public.invoices where document_type = 'credit_note';
  delete from public.invoices;
  get diagnostics n = row_count;
  delete from public.invoice_counters;
  update public.einvoice_config set trial_mode = false where id = 1;
  return n;
end $$;


--
-- Name: invoices_block_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_block_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if coalesce(current_setting('app.allow_invoice_delete', true), '') = 'on'
     or coalesce((select trial_mode from public.einvoice_config where id = 1), false) then
    return old;
  end if;
  raise exception 'Issued invoices cannot be deleted. Issue a credit note instead.';
end $$;


--
-- Name: invoices_block_tamper(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_block_tamper() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if coalesce(current_setting('app.allow_invoice_delete', true), '') = 'on' then
    return new;
  end if;
  if (new.invoice_number, new.invoice_type, new.document_type, new.related_invoice_id,
      new.items, new.discount_total, new.vat_percent, new.subtotal, new.vat_amount, new.total,
      new.qr_base64, new.issued_at, new.customer_name, new.customer_vat_number,
      new.customer_cr_number, new.customer_address, new.customer_id)
     is distinct from
     (old.invoice_number, old.invoice_type, old.document_type, old.related_invoice_id,
      old.items, old.discount_total, old.vat_percent, old.subtotal, old.vat_amount, old.total,
      old.qr_base64, old.issued_at, old.customer_name, old.customer_vat_number,
      old.customer_cr_number, old.customer_address, old.customer_id)
  then
    raise exception 'Issued invoice content is immutable. Issue a credit note and a new invoice instead.';
  end if;
  return new;
end $$;


--
-- Name: invoices_require_issued_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invoices_require_issued_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.issued_at is null then
    raise exception 'Invoices must be issued through the invoice-api function (issued_at is required).';
  end if;
  return new;
end $$;


--
-- Name: next_invoice_seq(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.next_invoice_seq(p_key text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v integer;
begin
  insert into public.invoice_counters (counter_key, last_value) values (p_key, 1)
  on conflict (counter_key) do update set last_value = public.invoice_counters.last_value + 1
  returning last_value into v;
  return v;
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    activity_type text DEFAULT 'call'::text NOT NULL,
    description text,
    result text,
    next_action text,
    next_follow_up_date date,
    rep_username text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: admin_secret; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_secret (
    id integer DEFAULT 1 NOT NULL,
    password_hash text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    session_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    id integer DEFAULT 1 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    opportunity_id bigint,
    asset_type text DEFAULT 'other'::text NOT NULL,
    manufacturer text,
    model text,
    serial_number text,
    capacity text,
    quantity integer DEFAULT 1,
    location_note text,
    installation_date date,
    warranty_start_date date,
    warranty_end_date date,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    warranty_years numeric,
    performance_warranty_years numeric,
    performance_warranty_end_date date,
    warranty_years_requested numeric,
    warranty_request_status text DEFAULT 'none'::text NOT NULL,
    warranty_requested_by text,
    warranty_approved_by text,
    warranty_approved_at timestamp with time zone,
    warranty_number text,
    CONSTRAINT assets_warranty_request_status_check CHECK ((warranty_request_status = ANY (ARRAY['none'::text, 'pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor text NOT NULL,
    actor_role text NOT NULL,
    action_type text NOT NULL,
    entity_type text NOT NULL,
    entity_id bigint,
    entity_label text,
    old_value jsonb,
    new_value jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    name text NOT NULL,
    "position" text,
    mobile text,
    whatsapp text,
    email text,
    preferred_contact_method text,
    decision_power text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: crm_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_interactions (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    rep_username text,
    interaction_type text DEFAULT 'call'::text NOT NULL,
    note text,
    outcome text,
    status_after text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.crm_interactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.crm_interactions_id_seq OWNED BY public.crm_interactions.id;


--
-- Name: crm_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_settings (
    id integer DEFAULT 1 NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT crm_settings_id_check CHECK ((id = 1))
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    name text,
    phone text NOT NULL,
    rep_username text,
    quotes_count integer DEFAULT 0 NOT NULL,
    first_quote_at timestamp with time zone,
    last_quote_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    price_feedback text,
    blocker_reason text,
    blocker_notes text,
    next_follow_up_date date,
    last_contact_at timestamp with time zone,
    assigned_rep text,
    priority text DEFAULT 'warm'::text,
    lost_reason_detail text,
    city text,
    crm_created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_type text DEFAULT 'individual'::text,
    classification text,
    commercial_registration text,
    vat_number text,
    unified_number text,
    region text,
    lead_source text
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: einvoice_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.einvoice_config (
    id integer DEFAULT 1 NOT NULL,
    trial_mode boolean DEFAULT true NOT NULL,
    CONSTRAINT einvoice_config_id_check CHECK ((id = 1))
);


--
-- Name: invoice_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_counters (
    counter_key text NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    project_id bigint,
    customer_id bigint NOT NULL,
    milestone_id bigint,
    invoice_number text NOT NULL,
    invoice_date date DEFAULT CURRENT_DATE NOT NULL,
    due_date date,
    customer_name text,
    customer_phone text,
    customer_vat_number text,
    customer_cr_number text,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    discount_total numeric DEFAULT 0 NOT NULL,
    vat_percent numeric DEFAULT 15 NOT NULL,
    subtotal numeric DEFAULT 0 NOT NULL,
    vat_amount numeric DEFAULT 0 NOT NULL,
    total numeric DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    invoice_type text DEFAULT 'simplified'::text NOT NULL,
    rep_username text,
    payment_method text,
    paid_at timestamp with time zone,
    qr_base64 text,
    approval_status text DEFAULT 'approved'::text NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    customer_address text,
    source_quotation_id bigint,
    issued_at timestamp with time zone,
    document_type text DEFAULT 'invoice'::text NOT NULL,
    related_invoice_id bigint,
    reason text,
    CONSTRAINT invoices_approval_status_check CHECK ((approval_status = ANY (ARRAY['pending'::text, 'approved'::text]))),
    CONSTRAINT invoices_document_type_check CHECK ((document_type = ANY (ARRAY['invoice'::text, 'credit_note'::text]))),
    CONSTRAINT invoices_invoice_type_check CHECK ((invoice_type = ANY (ARRAY['simplified'::text, 'standard'::text])))
);


--
-- Name: COLUMN invoices.source_quotation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.invoices.source_quotation_id IS 'If this invoice was issued against an existing customer quotation, the quotation it was generated from (items are pulled from that quotation server-side).';


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: maintenance_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_contracts (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    project_id bigint,
    contract_number text,
    start_date date,
    end_date date,
    contract_value numeric,
    visits_per_year integer,
    next_visit_date date,
    responsible_engineer text,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_contracts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_contracts_id_seq OWNED BY public.maintenance_contracts.id;


--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunities (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    contact_id bigint,
    name text NOT NULL,
    project_type text,
    stage text DEFAULT 'new_lead'::text NOT NULL,
    stage_changed_at timestamp with time zone DEFAULT now() NOT NULL,
    estimated_capacity text,
    estimated_value numeric,
    expected_cost numeric,
    probability integer,
    expected_closing_date date,
    sales_person text,
    competitor_name text,
    competitor_price numeric,
    lost_reason text,
    next_action text,
    next_follow_up_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opportunities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opportunities_id_seq OWNED BY public.opportunities.id;


--
-- Name: payment_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_milestones (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    title text NOT NULL,
    percentage numeric,
    amount numeric,
    due_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_milestones_id_seq OWNED BY public.payment_milestones.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    method text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pricing_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_config (
    id integer DEFAULT 1 NOT NULL,
    data jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT single_row CHECK ((id = 1))
);


--
-- Name: project_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_costs (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    cost_type text DEFAULT 'other'::text NOT NULL,
    description text,
    amount numeric DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_costs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_costs_id_seq OWNED BY public.project_costs.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    project_number text NOT NULL,
    contract_value numeric,
    scope_type text,
    contract_signed_date date,
    project_manager text,
    engineer text,
    planned_supply_date date,
    actual_supply_date date,
    planned_install_date date,
    actual_install_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id_system_type text,
    inverter_spec text,
    panel_spec text,
    structure_type text
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    quotation_number text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    linked_quote_id bigint,
    valid_until date,
    sales_person text,
    engineer text,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    discount_total numeric DEFAULT 0 NOT NULL,
    vat_percent numeric DEFAULT 15 NOT NULL,
    subtotal numeric DEFAULT 0 NOT NULL,
    vat_amount numeric DEFAULT 0 NOT NULL,
    total numeric DEFAULT 0 NOT NULL,
    cost numeric,
    gross_profit numeric,
    gross_margin numeric,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ql_reference text,
    id_system_type text,
    pump_hp numeric,
    capacity_kw numeric,
    inverter_spec text,
    panel_spec text,
    structure_type text,
    scope_type text
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id bigint NOT NULL,
    rep_username text,
    rep_display_name text,
    client_name text,
    client_phone text,
    hp numeric,
    final_total numeric,
    snapshot jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_id bigint
);


--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: reps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reps (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_version integer DEFAULT 1 NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: reps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reps_id_seq OWNED BY public.reps.id;


--
-- Name: service_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_tickets (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    site_id bigint,
    asset_id bigint,
    project_id bigint,
    ticket_number text NOT NULL,
    issue_description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    assigned_engineer text,
    resolution_notes text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_tickets_id_seq OWNED BY public.service_tickets.id;


--
-- Name: site_surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_surveys (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    site_id bigint,
    customer_id bigint NOT NULL,
    engineer_name text,
    survey_date date,
    gps_lat double precision,
    gps_lng double precision,
    pump_type text,
    pump_manufacturer text,
    pump_model text,
    pump_hp text,
    pump_kw text,
    flow text,
    head text,
    well_depth text,
    static_water_level text,
    dynamic_water_level text,
    motor_manufacturer text,
    motor_model text,
    motor_hp text,
    motor_kw text,
    motor_voltage text,
    motor_current text,
    motor_frequency text,
    motor_rpm text,
    motor_power_factor text,
    motor_efficiency text,
    existing_diesel_generator text,
    generator_capacity text,
    diesel_consumption text,
    electricity_grid text,
    electricity_tariff text,
    existing_solar text,
    hours_per_day text,
    days_per_month text,
    seasonal_operation text,
    required_water_production text,
    available_area text,
    roof_or_ground text,
    shading text,
    orientation text,
    tilt text,
    soil text,
    access text,
    distance text,
    cable_length text,
    technical_notes text,
    photos jsonb DEFAULT '[]'::jsonb NOT NULL,
    documents jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_surveys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_surveys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_surveys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_surveys_id_seq OWNED BY public.site_surveys.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    name text NOT NULL,
    region text,
    city text,
    location_address text,
    gps_lat double precision,
    gps_lng double precision,
    google_maps_link text,
    farm_area text,
    agricultural_activity text,
    number_of_wells integer,
    number_of_pumps integer,
    water_source text,
    well_depth text,
    required_water_flow text,
    required_operating_hours text,
    current_energy_source text,
    diesel_consumption text,
    electricity_consumption text,
    existing_system text,
    technical_notes text,
    photos jsonb DEFAULT '[]'::jsonb NOT NULL,
    documents jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: technical_studies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technical_studies (
    id bigint NOT NULL,
    opportunity_id bigint NOT NULL,
    site_survey_id bigint,
    quote_id bigint,
    pv_capacity text,
    number_of_panels text,
    panel_model text,
    panel_wattage text,
    inverter text,
    inverter_capacity text,
    pump text,
    vfd text,
    structure text,
    dc_cables text,
    ac_cables text,
    protection text,
    combiner_boxes text,
    monitoring text,
    expected_production text,
    expected_operating_hours text,
    estimated_diesel_saving text,
    estimated_electricity_saving text,
    capex numeric,
    opex numeric,
    estimated_roi text,
    payback_period text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: technical_studies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.technical_studies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: technical_studies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.technical_studies_id_seq OWNED BY public.technical_studies.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: crm_interactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions ALTER COLUMN id SET DEFAULT nextval('public.crm_interactions_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: maintenance_contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts ALTER COLUMN id SET DEFAULT nextval('public.maintenance_contracts_id_seq'::regclass);


--
-- Name: opportunities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities ALTER COLUMN id SET DEFAULT nextval('public.opportunities_id_seq'::regclass);


--
-- Name: payment_milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones ALTER COLUMN id SET DEFAULT nextval('public.payment_milestones_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: project_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs ALTER COLUMN id SET DEFAULT nextval('public.project_costs_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: reps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps ALTER COLUMN id SET DEFAULT nextval('public.reps_id_seq'::regclass);


--
-- Name: service_tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets ALTER COLUMN id SET DEFAULT nextval('public.service_tickets_id_seq'::regclass);


--
-- Name: site_surveys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys ALTER COLUMN id SET DEFAULT nextval('public.site_surveys_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: technical_studies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies ALTER COLUMN id SET DEFAULT nextval('public.technical_studies_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activities (id, opportunity_id, customer_id, activity_type, description, result, next_action, next_follow_up_date, rep_username, created_at) FROM stdin;
\.


--
-- Data for Name: admin_secret; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_secret (id, password_hash, updated_at, session_version) FROM stdin;
1	1ea0b5950b43151459d77019f50ecdc58d457635085dbc0032b74b476e2ee774	2026-07-18 19:51:38.291693+00	2
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (id, data, updated_at) FROM stdin;
1	{}	2026-07-06 13:07:02.426489+00
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, customer_id, site_id, opportunity_id, asset_type, manufacturer, model, serial_number, capacity, quantity, location_note, installation_date, warranty_start_date, warranty_end_date, status, notes, created_at, updated_at, warranty_years, performance_warranty_years, performance_warranty_end_date, warranty_years_requested, warranty_request_status, warranty_requested_by, warranty_approved_by, warranty_approved_at, warranty_number) FROM stdin;
11	26	\N	\N	other	VEICHI	REACTOR-160A	N/A	160A	1		2026-08-18	2026-08-18	2027-08-17	active		2026-08-18 20:21:45.627688+00	2026-09-01 11:41:14.218+00	1	\N	\N	\N	none	\N	\N	\N	GC-0554001217-1-AUG2026-2021
9	12	\N	\N	solar_panel	JA	JAM66D45-625LB		625W	112		2026-04-11	2026-04-11	2038-04-10	active		2026-08-16 15:52:30.279162+00	2026-09-01 11:38:19.087+00	12	30	2056-04-10	\N	none	\N	\N	\N	GC-0531133171-1-APR2026-1552
10	26	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669481	90KW	1		2026-08-18	2026-08-18	2027-08-17	active		2026-08-18 20:20:38.491167+00	2026-09-01 19:44:05.987+00	1	\N	\N	\N	none	\N	\N	\N	GC-0554001217-1-AUG2026
5	9	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669477	90	1		2026-08-17	2026-08-17	2027-08-16	active		2026-08-16 15:06:28.577562+00	2026-09-01 19:44:43.293+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026
6	9	\N	\N	inverter	VEICHI	SI23-T3-090G-A(H)	9130550190Q108669466	90	1		2026-08-17	2026-08-17	2027-08-16	active		2026-08-16 15:08:49.382281+00	2026-09-01 19:45:01.961+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026-1508
1	12	\N	\N	inverter	VEICHI	SI23-T3-132G-A(H)	9130550192PC08474278	132kw	1		2026-08-01	2026-08-01	2027-07-31	active		2026-08-08 17:38:48.116516+00	2026-09-01 19:46:54.508+00	1	\N	\N	\N	none	\N	\N	\N	GC-0531133171-1-AUG2026
2	11	\N	\N	inverter	VEICHI	SI23-T3-200G-A(H)	9130550195Q208781854	200kw	1		2026-08-04	2026-07-08	2027-07-07	active		2026-08-10 16:28:52.19+00	2026-09-01 19:50:49.639+00	1	\N	\N	\N	none	\N	\N	\N	GC-0555115352-1-AUG2026
3	11	\N	\N	solar_panel	AIKO	MDE72DW-665W		665W	336		2026-08-08	2026-07-08	2038-07-07	active		2026-08-10 16:29:45.9101+00	2026-09-01 19:52:12.204+00	12	30	2056-07-07	\N	none	\N	\N	\N	GC-0555115352-1-AUG2026-1629
4	12	\N	\N	solar_panel	AIKO	MDE72DW-665W		665W	224		2026-08-01	2026-08-01	2038-07-31	active		2026-08-10 16:30:41.850884+00	2026-09-01 19:52:31.92+00	12	30	2056-07-31	\N	none	\N	\N	\N	GC-0531133171-1-AUG2026-1630
7	9	\N	\N	solar_panel	AIKO	MDE72DW-665W		665	285		2026-08-17	2026-08-17	2038-08-16	active		2026-08-16 15:12:04.963564+00	2026-09-01 19:52:50.518+00	12	30	2056-08-16	\N	none	\N	\N	\N	GC-0555115688-1-AUG2026-1512
8	12	\N	\N	inverter	VEICHI	SI23-T3-055G-A(H)		60	1		2026-04-11	2026-04-11	2027-04-10	active		2026-08-16 15:50:54.919314+00	2026-09-01 19:54:32.651+00	1	\N	\N	\N	none	\N	\N	\N	GC-0531133171-1-APR2026
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, actor, actor_role, action_type, entity_type, entity_id, entity_label, old_value, new_value, created_at) FROM stdin;
1	admin	admin	update	project	4	PRJ-2026-004	{"status": "pending", "contract_value": 95000}	{"status": "", "contract_value": 95000}	2026-08-16 15:13:40.764871+00
2	admin	admin	update	project	4	PRJ-2026-004	{"status": "", "contract_value": 95000}	{"status": "in_progress", "contract_value": 95000}	2026-08-16 15:15:40.948054+00
3	admin	admin	update	project	3	PRJ-2026-003	{"status": "pending", "contract_value": 50000}	{"status": "", "contract_value": 50000}	2026-08-16 15:16:47.768589+00
4	admin	admin	update	project	3	PRJ-2026-003	{"status": "", "contract_value": 50000}	{"status": "preparing", "contract_value": 55000}	2026-08-16 15:17:12.489008+00
5	admin	admin	update	project	3	PRJ-2026-003	{"status": "preparing", "contract_value": 55000}	{"status": "in_progress", "contract_value": 55000}	2026-08-16 15:18:12.842603+00
6	admin	admin	add_cost	project	2	other	\N	{"amount": 73000, "description": null}	2026-08-16 15:34:49.083111+00
7	admin	admin	add_cost	project	1	other	\N	{"amount": 173500, "description": null}	2026-08-16 15:36:07.527969+00
8	admin	admin	update	project	5	PRJ-2026-005	{"status": "pending", "contract_value": 175000}	{"status": "commissioned", "contract_value": 175000}	2026-08-16 15:57:45.404156+00
9	admin	admin	add_cost	project	5	other	\N	{"amount": 161000, "description": null}	2026-08-16 15:58:48.855923+00
10	admin	admin	delete	customer	27	شمس التل	\N	\N	2026-08-16 16:15:24.033099+00
11	admin	admin	stage_change	opportunity	7	صفقة - عرض 2026-08-16	{"stage": "new_lead"}	{"stage": "final_approval"}	2026-08-16 16:17:43.251172+00
12	admin	admin	stage_change	opportunity	7	صفقة - عرض 2026-08-16	{"stage": "final_approval"}	{"stage": "won"}	2026-08-16 16:20:07.605649+00
13	admin	admin	status_change	payment_milestone	2	مقدم	{"status": "pending"}	{"status": "paid"}	2026-08-16 16:21:22.625947+00
14	admin	admin	add_payment	project	6	\N	\N	{"amount": 5000, "payment_date": "2026-08-16"}	2026-08-16 16:22:06.035602+00
15	admin	admin	add_cost	project	6	materials	\N	{"amount": 10403, "description": null}	2026-08-16 16:22:58.457967+00
16	admin	admin	update	project	6	PRJ-2026-006	{"status": "pending", "contract_value": 10925}	{"status": "preparing", "contract_value": 10925}	2026-08-16 16:23:44.673738+00
17	admin	admin	update	project	6	PRJ-2026-006	{"status": "preparing", "contract_value": 10925}	{"status": "commissioned", "contract_value": 10925}	2026-08-18 20:15:39.288293+00
18	admin	admin	status_change	payment_milestone	5	عند الاستلام	{"status": "pending"}	{"status": "paid"}	2026-08-18 20:16:57.1369+00
19	admin	admin	add_payment	project	6	\N	\N	{"amount": 5706, "payment_date": "2026-08-18"}	2026-08-18 20:17:13.729881+00
20	admin	admin	add_cost	project	6	materials	\N	{"amount": 10400, "description": "افكار كو"}	2026-08-18 20:17:33.662177+00
21	admin	admin	delete_cost	project	6	materials	{"amount": 10400}	\N	2026-08-18 20:17:44.252316+00
22	admin	admin	add_cost	project	6	transportation	\N	{"amount": 50, "description": null}	2026-08-18 20:17:52.339503+00
23	admin	admin	update	project	4	PRJ-2026-004	{"status": "in_progress", "contract_value": 95000}	{"status": "commissioned", "contract_value": 95000}	2026-08-24 19:05:47.092482+00
24	admin	admin	create	invoice	1	INV-2026-001	\N	{"type": "simplified", "total": 230, "status": "paid"}	2026-08-28 08:56:04.072858+00
25	admin	admin	delete	invoice	1	INV-2026-001	\N	\N	2026-08-29 19:36:31.880527+00
26	admin	admin	create	invoice	2	HEWDS20260829-001	\N	{"type": "simplified", "total": 38138.6, "status": "paid", "approval": "approved"}	2026-08-29 19:46:05.563429+00
27	admin	admin	delete	invoice	2	HEWDS20260829-001	\N	\N	2026-08-29 19:47:12.221075+00
28	admin	admin	delete	customer	36	0	\N	\N	2026-08-29 20:01:43.965668+00
29	admin	admin	delete	customer	35	شمس التل	\N	\N	2026-09-01 11:46:50.521477+00
30	admin	admin	create	invoice	3	HEWDS20260905-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-05 23:26:26.585605+00
31	admin	admin	delete	invoice	3	HEWDS20260905-001	\N	\N	2026-09-05 23:27:28.5683+00
32	admin	admin	create	invoice	4	HEWDS20260906-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-06 09:14:18.499426+00
33	admin	admin	delete	invoice	4	HEWDS20260906-001	\N	\N	2026-09-06 09:22:21.900231+00
34	admin	admin	create	invoice	5	HEWDS20260906-001	\N	{"type": "simplified", "total": 899.3, "status": "paid", "approval": "approved"}	2026-09-06 09:22:44.498985+00
35	admin	admin	delete	invoice	5	HEWDS20260906-001	\N	\N	2026-09-06 09:32:48.744328+00
36	admin	admin	create	invoice	6	HEWDS20260906-001	\N	{"type": "simplified", "total": 38138.6, "status": "paid", "approval": "approved"}	2026-09-06 09:33:09.89261+00
37	admin	admin	delete	invoice	6	HEWDS20260906-001	\N	\N	2026-09-06 13:24:19.362354+00
38	admin	admin	create	invoice	7	HEWDS20260906-001	\N	{"type": "simplified", "total": 899.3, "status": "paid", "approval": "approved"}	2026-09-06 13:31:10.49473+00
39	admin	admin	delete	customer	39	عبدالرحمن منصور - الكرافيت	\N	\N	2026-09-06 15:37:55.005728+00
40	admin	admin	delete	invoice	7	HEWDS20260906-001	\N	\N	2026-09-07 08:36:22.615152+00
41	admin	admin	create	invoice	8	HEWDS20260922-001	\N	{"type": "simplified", "total": 516.35, "status": "paid", "approval": "approved"}	2026-09-21 22:30:28.040145+00
42	admin	admin	create	invoice	9	HEWDS20260922-002	\N	{"type": "simplified", "total": 422.8, "status": "paid", "approval": "approved"}	2026-09-21 22:47:55.09496+00
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, customer_id, name, "position", mobile, whatsapp, email, preferred_contact_method, decision_power, notes, created_at, updated_at) FROM stdin;
1	9	الشيخ حمود بن ناصر	555115688	\N	\N	\N	\N	\N	\N	2026-08-10 16:04:38.686701+00	2026-08-10 16:04:38.686701+00
\.


--
-- Data for Name: crm_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_interactions (id, customer_id, rep_username, interaction_type, note, outcome, status_after, created_at) FROM stdin;
1	10	admin	visit	مشكله ف الحساب البنكي الخاص بالمؤسسه الاسم غير متطابق مع الاسم المعلن و المستخدم في التسويق	موافق	\N	2026-08-08 08:13:54.084257+00
2	9	admin	visit	زياره للمزرعه بتاريخ 12082026 لمعرفه الطريق و حاله الموقع و الجاهزية لتسليم الخامات	\N	\N	2026-08-12 11:38:57.812387+00
\.


--
-- Data for Name: crm_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_settings (id, data, updated_at) FROM stdin;
1	{"regions": [{"label": "الوسطي - وادي الدواسر", "value": "الوسطي_-_وادي_الدواسر"}, {"label": "الوسطي - القصيم", "value": "الوسطي_-_القصيم"}, {"label": "الشمال - طبرجل", "value": "الشمال_-_طبرجل"}, {"label": "الشمال - تبوك و حائل", "value": "الشمال_-_تبوك_و_حائل"}, {"label": "الجنوب - خميس مشيط و جيزان", "value": "الجنوب_-_خميس_مشيط_و_جيزان"}, {"label": "الجنوب - نجران", "value": "الجنوب_-_نجران"}], "statuses": [{"color": "#5b8ef2", "label": "عميل جديد", "value": "new"}, {"color": "#f0c14b", "label": "تم التواصل", "value": "contacted"}, {"color": "#e8a33d", "label": "بيتفاوض", "value": "negotiating"}, {"color": "#0fa98d", "label": "تم الاتفاق", "value": "won"}, {"color": "#e0553f", "label": "اتفقد", "value": "lost"}, {"color": "#93a89c", "label": "مؤجل", "value": "on_hold"}], "costTypes": [{"label": "خامات", "value": "materials"}, {"label": "عمالة", "value": "labor"}, {"label": "نقل", "value": "transportation"}, {"label": "تركيب", "value": "installation"}, {"label": "أعمال خرسانية", "value": "concrete"}, {"label": "هيكل", "value": "structure"}, {"label": "كابلات", "value": "cables"}, {"label": "أعمال هندسية", "value": "engineering"}, {"label": "مصاريف أخرى", "value": "other"}], "assetTypes": [{"label": "لوح شمسي", "value": "solar_panel"}, {"label": "إنفرتر", "value": "inverter"}, {"label": "مضخة", "value": "pump"}, {"label": "موتور", "value": "motor"}, {"label": "VFD (محرك متغير التردد)", "value": "vfd"}, {"label": "لوحة تحكم", "value": "control_panel"}, {"label": "هيكل تركيب", "value": "structure"}, {"label": "نظام مراقبة", "value": "monitoring_system"}, {"label": "بطارية", "value": "battery"}, {"label": "كابلات", "value": "cables"}, {"label": "أخرى", "value": "other"}, {"label": "صندوق تجميع (Combiner Box)", "value": "combiner_box"}, {"label": "إنفرتر جهد عالي (HV)", "value": "hv_inverter"}, {"label": "بطارية جهد عالي (HV)", "value": "hv_battery"}], "priorities": [{"label": "ساخن 🔥", "value": "hot"}, {"label": "دافئ", "value": "warm"}, {"label": "بارد", "value": "cold"}], "leadSources": [{"label": "الموقع الإلكتروني", "value": "website"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "مكالمة مباشرة", "value": "phone"}, {"label": "توصية عميل", "value": "referral"}, {"label": "عميل حالي (مشروع جديد)", "value": "existing_customer"}, {"label": "زيارة ميدانية", "value": "site_visit"}, {"label": "سوشيال ميديا", "value": "social_media"}, {"label": "معرض", "value": "exhibition"}, {"label": "شريك/وسيط", "value": "partner"}, {"label": "حملة تسويقية", "value": "marketing_campaign"}, {"label": "أخرى", "value": "other"}], "idScopeTypes": [{"code": "INS", "label": "تركيب فقط (Installation Only)", "value": "installation"}, {"code": "SUP", "label": "توريد فقط (Supply Only)", "value": "supply"}, {"code": "LUM", "label": "مقطوعية (Lump Sum)", "value": "lumpsum"}], "projectTypes": [{"label": "طاقة شمسية لمضخات الري", "value": "solar_pumping"}, {"label": "محطة طاقة شمسية", "value": "solar_power_plant"}, {"label": "هجين شمسي/ديزل", "value": "solar_diesel_hybrid"}, {"label": "شمسي مربوط بالشبكة", "value": "solar_grid"}, {"label": "تخزين بطاريات", "value": "battery_storage"}, {"label": "طاقة شمسية تجارية", "value": "commercial_solar"}, {"label": "طاقة شمسية صناعية", "value": "industrial_solar"}, {"label": "طاقة شمسية زراعية", "value": "agricultural_solar"}, {"label": "EPC", "value": "epc"}, {"label": "مقاولات كهربائية", "value": "electrical_contracting"}, {"label": "مقاولات عامة", "value": "general_contracting"}, {"label": "صيانة", "value": "maintenance"}, {"label": "توسعة", "value": "expansion"}, {"label": "أخرى", "value": "other"}], "activityTypes": [{"label": "مكالمة تليفون", "value": "call"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "إيميل", "value": "email"}, {"label": "اجتماع", "value": "meeting"}, {"label": "زيارة مزرعة", "value": "site_visit"}, {"label": "اجتماع فني", "value": "technical_meeting"}, {"label": "إرسال عرض سعر", "value": "quotation"}, {"label": "متابعة", "value": "follow_up"}, {"label": "شكوى", "value": "complaint"}, {"label": "تانى", "value": "other"}], "assetStatuses": [{"color": "#0fa98d", "label": "شغال", "value": "active"}, {"color": "#e0553f", "label": "فيه عطل", "value": "faulty"}, {"color": "#93a89c", "label": "اتستبدل", "value": "replaced"}, {"color": "#63736f", "label": "اتشال", "value": "removed"}], "customerTypes": [{"label": "فرد", "value": "individual"}, {"label": "مؤسسة", "value": "institution"}, {"label": "شركة", "value": "company"}], "energySources": [{"label": "ديزيل", "value": "ديزيل"}, {"label": "كهرباء", "value": "كهرباء"}], "idSystemTypes": [{"code": "P", "label": "مضخة (Pump)", "value": "pump"}, {"code": "OG", "label": "أون-جريد (On-Grid)", "value": "ongrid"}, {"code": "OFG", "label": "أوف-جريد (Off-Grid)", "value": "offgrid"}, {"code": "H", "label": "هايبرد (Hybrid)", "value": "hybrid"}], "priceFeedback": [{"label": "السعر مناسب", "value": "acceptable"}, {"label": "غالي شوية", "value": "slightly_high"}, {"label": "غالي جدًا", "value": "too_high"}, {"label": "محتاج خصم", "value": "needs_discount"}, {"label": "مش معروف", "value": "unknown"}], "blockerReasons": [{"label": "السعر غالي", "value": "price_too_high"}, {"label": "مفيش ميزانية دلوقتي", "value": "no_budget"}, {"label": "بيقارن بعروض تانية", "value": "comparing_offers"}, {"label": "مخاوف فنية", "value": "technical_concerns"}, {"label": "مش متأكد من الشركة", "value": "trust_company"}, {"label": "مش وقته دلوقتي (موسم/حصاد)", "value": "timing_not_ready"}, {"label": "مبيردش / اختفى", "value": "no_response"}, {"label": "غيّر رأيه", "value": "changed_mind"}, {"label": "سبب تاني", "value": "other"}, {"label": "مفيش مشكلة", "value": "none"}], "contactMethods": [{"label": "اتصال هاتفي", "value": "اتصال_هاتفي"}, {"label": "واتس اب", "value": "واتس_اب"}], "paymentMethods": [{"label": "كاش", "value": "cash"}, {"label": "تحويل بنكي", "value": "bank_transfer"}, {"label": "شيك", "value": "cheque"}, {"label": "ماكينات ال POS", "value": "other"}, {"label": "أخرى", "value": "أخرى"}], "ticketStatuses": [{"color": "#5b8ef2", "label": "مفتوحة", "value": "open"}, {"color": "#e7ac12", "label": "معيّنة لمهندس", "value": "assigned"}, {"color": "#f3cb56", "label": "جاري العمل", "value": "in_progress"}, {"color": "#93a89c", "label": "في انتظار العميل", "value": "waiting_customer"}, {"color": "#0fa98d", "label": "اتحلت", "value": "resolved"}, {"color": "#63736f", "label": "مقفولة", "value": "closed"}], "classifications": [{"label": "صغير (1-5)", "value": "صغير_1-5"}, {"label": "متوسط( 5-20)", "value": "متوسط_5-20"}, {"label": "كبير (20- 100)", "value": "كبير_20-_100"}], "invoiceStatuses": [{"color": "#93a89c", "label": "مسودة", "value": "draft"}, {"color": "#5b8ef2", "label": "اتبعتت للعميل", "value": "sent"}, {"color": "#0FA98D", "label": "اتسددت", "value": "paid"}, {"color": "#e0553f", "label": "متأخرة عن السداد", "value": "overdue"}, {"color": "#63736F", "label": "ملغاة", "value": "cancelled"}], "projectStatuses": [{"color": "#E7AC12", "label": "جاري التجهيز", "value": "preparing"}, {"color": "#155E85", "label": "قيد التنفيذ", "value": "in_progress"}, {"color": "#0FA98D", "label": "تم التشغيل والتسليم", "value": "commissioned"}], "interactionTypes": [{"label": "مكالمة", "value": "call"}, {"label": "واتساب", "value": "whatsapp"}, {"label": "زيارة مزرعة", "value": "visit"}, {"label": "اجتماع", "value": "meeting"}, {"label": "تانى", "value": "other"}], "ticketPriorities": [{"color": "#e0553f", "label": "حرجة", "value": "critical"}, {"color": "#e7ac12", "label": "عالية", "value": "high"}, {"color": "#5b8ef2", "label": "متوسطة", "value": "medium"}, {"color": "#93a89c", "label": "منخفضة", "value": "low"}], "milestoneStatuses": [{"color": "#93a89c", "label": "لسه مستحقة", "value": "pending"}, {"color": "#E7AC12", "label": "مستحقة دلوقتي", "value": "due"}, {"color": "#0FA98D", "label": "اتسددت", "value": "paid"}], "opportunityStages": [{"color": "#5b8ef2", "label": "عميل جديد", "value": "new_lead"}, {"color": "#7c9dd6", "label": "مؤهّل", "value": "qualified"}, {"color": "#0fa98d", "label": "تواصل أولي", "value": "initial_contact"}, {"color": "#0b7a66", "label": "محتاج مسح ميداني", "value": "survey_required"}, {"color": "#0b7a66", "label": "المسح الميداني تم", "value": "survey_completed"}, {"color": "#155e85", "label": "دراسة فنية", "value": "technical_study"}, {"color": "#e7ac12", "label": "تم إرسال العرض", "value": "quotation_sent"}, {"color": "#e8a33d", "label": "تفاوض", "value": "negotiation"}, {"color": "#f3cb56", "label": "موافقة نهائية", "value": "final_approval"}, {"color": "#0fa98d", "label": "اتكسبت", "value": "won"}, {"color": "#e0553f", "label": "اتفقدت", "value": "lost"}, {"color": "#93a89c", "label": "متابعة لاحقًا", "value": "follow_up_later"}], "projectScopeTypes": [{"label": "توريد فقط", "value": "supply_only"}, {"label": "تركيب فقط", "value": "install_only"}, {"label": "توريد وتركيب", "value": "supply_and_install"}, {"label": "صيانة فقط", "value": "maintenance_only"}], "quotationStatuses": [{"color": "#93a89c", "label": "مسودة", "value": "draft"}, {"color": "#5b8ef2", "label": "اتبعت للعميل", "value": "sent"}, {"color": "#0fa98d", "label": "اتقبلت", "value": "accepted"}, {"color": "#e0553f", "label": "اترفضت", "value": "rejected"}, {"color": "#63736f", "label": "منتهية الصلاحية", "value": "expired"}], "standardWarranties": {"inverter": {"defectYears": 1}, "hv_battery": {"defectYears": 10}, "hv_inverter": {"defectYears": 5}, "solar_panel": {"defectYears": 12, "performanceYears": 30}, "combiner_box": {"defectYears": 1}}, "decisionPowerLevels": [{"label": "المدير", "value": "المدير"}, {"label": "وسيط", "value": "وسيط"}, {"label": "العامل", "value": "العامل"}], "opportunityLostReasons": [{"label": "السعر", "value": "price"}, {"label": "منافس", "value": "competitor"}, {"label": "الميزانية", "value": "budget"}, {"label": "تأخر القرار", "value": "delayed"}, {"label": "العميل غيّر خطته", "value": "customer_changed_plan"}, {"label": "التمويل", "value": "financing"}, {"label": "مشكلة فنية", "value": "technical_issue"}, {"label": "المشروع اتلغى", "value": "project_cancelled"}, {"label": "سبب تاني", "value": "other"}], "maintenanceContractStatuses": [{"color": "#0fa98d", "label": "سارٍ", "value": "active"}, {"color": "#e0553f", "label": "منتهي", "value": "expired"}, {"color": "#63736f", "label": "ملغي", "value": "cancelled"}]}	2026-08-10 16:13:59.326+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, rep_username, quotes_count, first_quote_at, last_quote_at, created_at, updated_at, status, price_feedback, blocker_reason, blocker_notes, next_follow_up_date, last_contact_at, assigned_rep, priority, lost_reason_detail, city, crm_created_at, customer_type, classification, commercial_registration, vat_number, unified_number, region, lead_source) FROM stdin;
8	عبدالرحمن ناصر محمد القحطاني	0567712263	ALHUSSEINI	2	2026-08-02 19:23:16.163+00	2026-08-02 19:24:06.021+00	2026-08-02 19:23:16.237128+00	2026-08-10 16:21:05.425+00	contacted	slightly_high	no_budget		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	\N	\N				\N	\N
3	الشيخ علوش بن محسن بن قويد	0504101359	ALHUSSEINI	1	2026-07-12 11:16:46.288822+00	2026-07-12 11:16:46.288822+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:22:28.177+00	contacted	acceptable	no_budget		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	فرد	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
5	عبدالعزيز محمد الدوسري	0599909493	ALHUSSEINI	3	2026-07-17 11:23:01.30727+00	2026-07-17 11:24:59.253852+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:22:52.896+00	contacted	slightly_high	no_budget	اقساط 50% مقدم و الباقي ع سنه	\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-07 14:47:36.15421+00	فرد	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
4	محمد الحارثي	0509837564	ALHUSSEINI	4	2026-07-19 14:43:42.332633+00	2026-07-19 15:06:16.741853+00	2026-07-28 03:46:40.715874+00	2026-08-10 16:23:34.098+00	contacted	unknown	no_response		\N	\N	م محمود الحسيني	warm	\N		2026-08-07 14:47:36.15421+00	فرد	متوسط_5-20				الوسطي_-_وادي_الدواسر	\N
15	مهدي مؤسسه الوسائل المتطورة	0549307344	\N	0	\N	\N	2026-08-10 16:18:57.461629+00	2026-08-10 16:24:14.248+00	negotiating	needs_discount	no_response		\N	\N	م محمود الحسيني	warm	\N	السليل	2026-08-10 16:18:57.461629+00	فرد	متوسط_5-20				الوسطي_-_وادي_الدواسر	site_visit
7	عبدالله محمد الدوسري	0531457772	ALHUSSEINI	3	2026-08-01 10:00:47.279+00	2026-08-01 10:02:53.839+00	2026-08-01 10:00:47.374387+00	2026-08-10 16:24:42.697+00	new	\N	\N		\N	\N		warm	\N		2026-08-07 14:47:36.15421+00	\N	\N				\N	\N
32	احمد حامد السوداني	0565480579	ALHUSSEINI	6	2026-08-22 05:47:52.505+00	2026-08-24 11:31:51.022+00	2026-08-22 05:47:52.57721+00	2026-09-04 11:54:03.160175+00	contacted	acceptable	\N		\N	\N	م محمود الحسيني	hot	\N	Wae	2026-08-22 05:47:52.57721+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	site_visit
31	عادل ماسه الوادي	0550900968	ALHUSSEINI	10	2026-08-20 11:48:22.336+00	2026-08-24 11:20:01.524+00	2026-08-20 11:48:22.570641+00	2026-09-04 11:54:03.160175+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-08-20 11:48:22.570641+00	individual	\N	\N	\N	\N	\N	\N
24	ظافر مسعود اليامي الرشدان	0505116132	\N	0	\N	\N	2026-08-11 08:57:29.852052+00	2026-08-11 08:58:50.133+00	contacted	\N	technical_concerns		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 08:57:29.852052+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	phone
10	محمد جبران	0557761677	ALHUSSEINI	1	2026-08-08 07:44:04.718+00	2026-08-08 07:44:04.718+00	2026-08-08 07:44:04.773132+00	2026-08-12 11:34:39.99+00	lost	acceptable	trust_company	نفذ بالواح جينكو 590 وات من مورد منافس	\N	2026-08-08 08:13:54.168+00		warm	\N		2026-08-08 07:44:04.773132+00	\N	\N				\N	\N
9	الشيخ حمود بن ناصر	0555115688	ALHUSSEINI	2	2026-08-03 06:55:44.126+00	2026-08-03 06:56:34.07+00	2026-08-03 06:55:44.172335+00	2026-08-16 14:59:29.708+00	won	slightly_high	\N		\N	2026-08-12 11:38:57.852+00	م محمود الحسيني	warm	\N	Wae	2026-08-07 14:47:36.15421+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	referral
12	مبارك محمد ابو فاضل	0531133171	\N	0	\N	\N	2026-08-08 08:18:25.624249+00	2026-08-16 15:49:32.143+00	won	acceptable	\N	تم الانتهاء من تنفيذ المنظومة	\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-08 08:18:25.624249+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
14	مبارك الخنين	0567043616	\N	0	\N	\N	2026-08-10 16:18:18.514212+00	2026-08-16 16:01:57.911+00	contacted	\N	timing_not_ready		\N	\N	م محمود الحسيني	cold	\N	wae	2026-08-10 16:18:18.514212+00	institution	متوسط_5-20				الوسطي_-_وادي_الدواسر	phone
26	شمس التل	0554001217	\N	1	2026-08-16 14:25:58.2+00	2026-08-16 14:25:58.2+00	2026-08-16 14:25:58.289442+00	2026-08-16 16:16:59.649+00	won	acceptable	\N		\N	\N	م محمود الحسيني	hot	\N	Wae	2026-08-16 14:25:58.289442+00	institution	متوسط_5-20	7050598759	313102440300003		الوسطي_-_وادي_الدواسر	site_visit
18	مصابيح بن قويد	0505115222	\N	0	\N	\N	2026-08-11 07:37:17.204705+00	2026-08-18 05:53:58.103+00	contacted	too_high	no_budget		\N	\N	م محمود الحسيني	cold	\N	wae	2026-08-11 07:37:17.204705+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
28	أبو ماجد	0509927849	ALHUSSEINI	1	2026-08-18 05:24:05.117+00	2026-08-18 05:24:05.117+00	2026-08-18 05:24:05.151716+00	2026-08-18 05:52:59.906+00	contacted	\N	\N		\N	\N		cold	\N		2026-08-18 05:24:05.151716+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
16	ماجد سلامه أبو عبدالهادي الدوسري امن الطرق	0531209995	\N	0	\N	\N	2026-08-11 07:34:35.062176+00	2026-08-18 05:54:10.268+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:34:35.062176+00	individual	\N				\N	\N
29	عادل ديماس الجوف	0560595743	ALHUSSEINI	1	2026-08-18 05:26:22.984+00	2026-08-18 05:26:22.984+00	2026-08-18 05:26:23.043012+00	2026-08-18 05:53:12.593+00	contacted	acceptable	\N		\N	\N		hot	\N	Wae	2026-08-18 05:26:23.043012+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
23	يحي مزرعه الجيلا	0502319478	\N	0	\N	\N	2026-08-11 07:43:54.460404+00	2026-08-18 05:54:38.873+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:43:54.460404+00	individual	\N				\N	\N
17	محمد بن ناصر بن صقر	0555532122	\N	0	\N	\N	2026-08-11 07:35:48.393292+00	2026-08-18 05:54:52.888+00	lost	acceptable	no_response		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-11 07:35:48.393292+00	institution	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
20	شجاع محمد السنبله	0555116727	\N	0	\N	\N	2026-08-11 07:39:20.275483+00	2026-08-18 05:55:05.089+00	contacted	\N	\N		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:39:20.275483+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	site_visit
22	حسن الشهري أبو محمد شركه الانماء	0505702103	\N	0	\N	\N	2026-08-11 07:43:03.840453+00	2026-08-18 05:55:35.069+00	contacted	unknown	trust_company		\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-11 07:43:03.840453+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	referral
13	محماس مجدل	0504196915	\N	0	\N	\N	2026-08-10 16:17:23.261703+00	2026-08-10 16:20:28.168+00	new	\N	\N		\N	\N	م محمود الحسيني	warm	\N	WAE	2026-08-10 16:17:23.261703+00	\N	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
19	مبارك مخاريم الدوسري	0505943588	\N	0	\N	\N	2026-08-11 07:38:22.709247+00	2026-08-24 06:43:41.808+00	contacted	unknown	timing_not_ready		2026-10-17	\N	م محمود الحسيني	cold	\N	wae	2026-08-11 07:38:22.709247+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	site_visit
30	الشيخه الاميره	0506222121	ALHUSSEINI	1	2026-08-18 05:49:27.436+00	2026-08-18 05:49:27.436+00	2026-08-18 05:49:27.501345+00	2026-08-24 06:44:21.657+00	contacted	acceptable	no_budget		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-18 05:49:27.501345+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
11	حاظر مشلح ابو مسفر	0555115352	\N	0	\N	\N	2026-08-08 08:17:12.516939+00	2026-09-01 11:48:41.472+00	won	needs_discount	\N	تم التنفيذ	\N	\N	م محمود الحسيني	warm	\N	wae	2026-08-08 08:17:12.516939+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	partner
33	فألح مفرج الطويله	0551833823	ALHUSSEINI	1	2026-08-23 08:05:24.442+00	2026-08-23 08:05:24.442+00	2026-08-23 08:05:24.477599+00	2026-09-04 11:54:03.160175+00	contacted	acceptable	comparing_offers		\N	\N	م محمود الحسيني	cold	\N	Wae	2026-08-23 08:05:24.477599+00	individual	متوسط_5-20				الوسطي_-_وادي_الدواسر	partner
37	فيحان محمد فيحان ذعار الرجبان سمك في دوسر	0501111713	\N	0	\N	\N	2026-08-29 20:01:04.991004+00	2026-09-04 11:54:03.160175+00	new	\N	\N	\N	\N	\N	م محمود الحسيني	warm	\N	Wae	2026-08-29 20:01:04.991004+00	individual	\N	\N	\N	\N	\N	\N
38	عبدالرحمن منصور - الكرافيت	0551411010	ALHUSSEINI	2	2026-09-05 09:05:21.034+00	2026-09-05 09:06:12.445+00	2026-09-05 09:05:21.091554+00	2026-09-05 17:44:55.408+00	new	\N	\N		\N	\N		warm	\N		2026-09-05 09:05:21.091554+00	individual	صغير_1-5				الوسطي_-_وادي_الدواسر	phone
40	تبو مهدي جار العقيد	556635456	ALHUSSEINI	1	2026-09-11 16:59:43.425+00	2026-09-11 16:59:43.425+00	2026-09-11 16:59:43.67111+00	2026-09-11 16:59:43.425+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-09-11 16:59:43.67111+00	individual	\N	\N	\N	\N	\N	\N
41	سالم مرزوق -٠ الكرافيت 	555115510	ALHUSSEINI	1	2026-09-16 16:31:44.327+00	2026-09-16 16:31:44.327+00	2026-09-16 16:31:44.861294+00	2026-09-16 16:31:44.327+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-09-16 16:31:44.861294+00	individual	\N	\N	\N	\N	\N	\N
42	0	0	ALHUSSEINI	2	2026-09-19 08:41:27.293+00	2026-09-19 10:33:05.227+00	2026-09-19 08:41:28.0436+00	2026-09-19 10:33:05.227+00	new	\N	\N	\N	\N	\N	\N	warm	\N	\N	2026-09-19 08:41:28.0436+00	individual	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: einvoice_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.einvoice_config (id, trial_mode) FROM stdin;
1	t
\.


--
-- Data for Name: invoice_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_counters (counter_key, last_value) FROM stdin;
HEWDS20260922	2
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, project_id, customer_id, milestone_id, invoice_number, invoice_date, due_date, customer_name, customer_phone, customer_vat_number, customer_cr_number, items, discount_total, vat_percent, subtotal, vat_amount, total, status, notes, created_by, created_at, updated_at, invoice_type, rep_username, payment_method, paid_at, qr_base64, approval_status, approved_by, approved_at, customer_address, source_quotation_id, issued_at, document_type, related_invoice_id, reason) FROM stdin;
8	\N	12	\N	HEWDS20260922-001	2026-09-21	\N	مبارك محمد ابو فاضل	0531133171	\N	\N	[{"qty": 1, "code": "SIS4-12V 1KW MPPT", "name": "SIS4-12V 1KW MPPT", "type": "product", "discount": 0, "lineTotal": 449, "unitPrice": 449}]	0	15	449	67.35	516.35	paid	\N	admin	2026-09-21 22:30:27.637342+00	2026-09-21 22:30:27.637342+00	simplified	admin	cash	2026-09-21 22:30:27.559+00	AUbZhdik2LPYs9ipINit2YTZiNmEINin2YTYt9in2YLYqSDYp9mE2YXYqtis2K/Yr9ipINmI2KfZhNmF2YLYp9mI2YTYp9iqAg8zMTEzODYzNDEyMDAwMDMDFDIwMjYtMDktMjFUMjI6MzA6MjdaBAY1MTYuMzUFBTY3LjM1	approved	admin	2026-09-21 22:30:27.559+00	\N	\N	2026-09-21 22:30:27.559+00	invoice	\N	\N
9	\N	12	\N	HEWDS20260922-002	2026-09-21	\N	مبارك محمد ابو فاضل	0531133171	\N	\N	[{"qty": 1, "code": "PANEL-Jinko-645W", "name": "PANEL-Jinko-645W", "type": "product", "discount": 0, "lineTotal": 367.65, "unitPrice": 367.65}]	0	15	367.65	55.15	422.8	paid	\N	admin	2026-09-21 22:47:54.946662+00	2026-09-21 22:47:54.946662+00	simplified	admin	cash	2026-09-21 22:47:54.885+00	AUbZhdik2LPYs9ipINit2YTZiNmEINin2YTYt9in2YLYqSDYp9mE2YXYqtis2K/Yr9ipINmI2KfZhNmF2YLYp9mI2YTYp9iqAg8zMTEzODYzNDEyMDAwMDMDFDIwMjYtMDktMjFUMjI6NDc6NTRaBAY0MjIuODAFBTU1LjE1	approved	admin	2026-09-21 22:47:54.885+00	\N	\N	2026-09-21 22:47:54.885+00	invoice	\N	\N
\.


--
-- Data for Name: maintenance_contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_contracts (id, customer_id, project_id, contract_number, start_date, end_date, contract_value, visits_per_year, next_visit_date, responsible_engineer, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opportunities (id, customer_id, site_id, contact_id, name, project_type, stage, stage_changed_at, estimated_capacity, estimated_value, expected_cost, probability, expected_closing_date, sales_person, competitor_name, competitor_price, lost_reason, next_action, next_follow_up_date, notes, created_at, updated_at) FROM stdin;
2	11	\N	\N	مزرعه حاظر ابو مشلح علي طريق مجدل	solar_pumping	won	2026-08-12 06:19:27.819+00	200	175000	174000	100	\N	م محمود الحسيني	\N	\N	\N		\N		2026-08-10 16:27:57.139902+00	2026-08-12 06:19:27.819+00
3	9	\N	\N	صفقة - عرض 2026-08-03	solar_pumping	won	2026-08-12 06:27:16.295+00	100	95000	\N	\N	\N		\N	\N	\N		\N		2026-08-12 06:26:19.314255+00	2026-08-12 06:27:16.295+00
4	9	\N	\N	الشيخ حمود بن ناصر 50 حصان	solar_pumping	won	2026-08-12 11:30:37.981+00	50	50000	\N	100	\N	م محمود الحسيني	\N	\N	\N		\N		2026-08-12 11:30:23.072797+00	2026-08-12 11:30:37.981+00
1	12	\N	\N	مبارك ابو فاضل الدوسري 125hp	solar_pumping	won	2026-08-10 16:25:41.013+00	125	175000	161000	100	2026-08-01	م محمود الحسيني	\N	\N	\N		\N		2026-08-08 17:43:49.848416+00	2026-08-12 11:31:40.753+00
5	12	\N	\N	مبارك ابو فاضل الدوسري 60hp	solar_pumping	won	2026-08-12 11:33:14.581+00	60	85000	\N	100	2026-04-11	م محمود الحسيني	\N	\N	\N		\N		2026-08-12 11:32:41.454325+00	2026-08-12 11:45:13.875+00
7	26	\N	\N	صفقة - عرض 2026-08-16	solar_pumping	won	2026-08-16 16:20:07.568+00		10925	10402	100	2026-08-16	م محمود الحسيني	\N	\N	\N		2026-08-18		2026-08-16 16:17:08.743423+00	2026-08-16 16:20:07.568+00
\.


--
-- Data for Name: payment_milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_milestones (id, project_id, title, percentage, amount, due_date, status, notes, created_at, updated_at) FROM stdin;
1	1	كامل	100	175000	2026-08-01	paid	\N	2026-08-13 05:18:04.433747+00	2026-08-13 05:18:11.68+00
2	6	مقدم	\N	5000	2026-08-16	paid	\N	2026-08-16 16:21:16.232064+00	2026-08-16 16:21:22.582+00
5	6	عند الاستلام	\N	5706	2026-08-18	paid	\N	2026-08-18 20:16:50.348887+00	2026-08-18 20:16:57.099+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, project_id, amount, payment_date, method, notes, created_at) FROM stdin;
1	1	175000	2026-08-01	bank_transfer	\N	2026-08-13 05:17:31.467672+00
2	6	5000	2026-08-16	bank_transfer	\N	2026-08-16 16:22:05.993308+00
3	6	5706	2026-08-18	bank_transfer	\N	2026-08-18 20:17:13.708689+00
\.


--
-- Data for Name: pricing_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pricing_config (id, data, updated_at) FROM stdin;
1	{"vat": 0.15, "feas": {"psh": 5.5, "years": 30, "gridPrice": 0.22, "dieselPrice": 1.79, "gridEscalationPct": 8, "solarOMPctOfCapex": 1, "co2FactorKgPerLiter": 2.68, "dieselEscalationPct": 5, "panelDegradationPct": 0.65, "dieselConsumptionPerKWh": 0.25}, "ongrid": {"panelIdx": 0, "sunHours": 5.5, "tariffRate": 0.18, "cablingFixedCost": 700, "cablingFixedSell": 1200, "installPerKwCost": 250, "installPerKwSell": 450, "performanceRatio": 0.8, "inverterMarkupPct": 20, "netMeteringFeeCost": 500, "netMeteringFeeSell": 900, "structurePerPanelCost": 110, "structurePerPanelSell": 170}, "panels": [{"isc": 15.45, "voc": 55.2, "iimp": 14.75, "vimp": 45.09, "brand": "Aiko", "image": "https://aikosolar.com/wp-content/uploads/2025/12/Stellar-3Nplus72-1272-514.jpg", "power": 665, "specs": {"Imp (STC)": "14.75 أمبير", "Isc (STC)": "15.45 أمبير", "Vmp (STC)": "45.09 فولت", "Voc (STC)": "55.20 فولت", "النوع": "ثنائي الوجه (Bifacial)", "الوزن": "32.2 كجم", "الإطار": "ألومنيوم أنودايز", "الزجاج": "مزدوج 2.0+2.0مم شبه مقسّى", "الوصلة": "MC4 Compatible / MC4-EVO2A", "الأبعاد": "2382×1134×30 مم", "نوع الخلية": "N-Type ABC (Back Contact)", "الكفاءة (STC)": "24.6%", "ضمان المنتج": "15 سنة", "عدد الخلايا": "144 (6×24)", "معامل حرارة Pmax": "-0.26%/°م", "أقصى جهد للنظام": "DC 1500V", "ضمان الأداء الخطي": "30 سنة", "درجة حرارة التشغيل": "-40°م إلى +70°م"}, "priceW": 0.55, "visible": true, "description": "لوح Aiko Stellar 3N+72 ثنائي الزجاج وثنائي الوجه (Bifacial)، تقنية N-Type ABC (Back Contact)، من عائلة موديلات 650-685 واط — بكفاءة تصل حتى 24.6%، وضمان منتج 15 سنة وضمان أداء خطي 30 سنة.", "datasheetUrl": "https://aikosolar.com/wp-content/uploads/2026/06/Stellar-3NPlus72-AIKO-A-MDE72Dw_650-685W-2382%C3%971134%C3%9730_202603_V2.1_EN.pdf", "internalNote": "AIKO-A665-MDE72Dw — القيم الكهربائية مطابقة للداتا شيت الرسمي (إصدار 202603_V2.1_EN). خط منتج مختلف عن Stellar 1N+ (635-660W): هذا Bifacial ومدى حرارة تشغيله أضيق (-40° إلى +70°م بدل -40° إلى +85°م). للاستخدام الداخلي فقط — لا يظهر للمناديب أو العملاء."}, {"isc": 15.06, "voc": 54, "iimp": 14.35, "vimp": 45.3, "brand": "Aiko", "image": "https://aikosolar.com/wp-content/uploads/2024/03/Stellar-series-1Nplus_Polaris-detail.jpg", "power": 650, "priceW": 0, "visible": false, "datasheetUrl": "https://aikosolar.com/wp-content/uploads/2025/10/Stellar-1N_192.5-AIKO-G-MCH72Dw-635-660W_2382x1134x30mm_V4.1_202510_DsDr_EN.pdf"}, {"isc": 16.15, "voc": 48.7, "iimp": 15.45, "vimp": 40.45, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 595, "priceW": 0, "visible": false, "datasheetUrl": "https://jasolar.com/uploadfile/fujian/2024/1120/eafad230aca62a5.pdf"}, {"isc": 13.99, "voc": 52.58, "iimp": 13.333, "vimp": 44.64, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 620, "priceW": 0.55, "visible": true, "datasheetUrl": "https://www.enfsolar.com/pv/panel-datasheet/crystalline/66270"}, {"isc": 13.99, "voc": 52.58, "iimp": 13.333, "vimp": 44.64, "brand": "JA", "image": "https://cdn.enfsolar.com/Product/logo/Crystalline/674e835d5151d.png", "power": 630, "priceW": 0, "visible": false, "datasheetUrl": "https://www.enfsolar.com/pv/panel-datasheet/crystalline/66270"}, {"isc": 16.02, "voc": 48.88, "iimp": 15.15, "vimp": 40.46, "brand": "JINKO", "image": "https://jinkosolarcdn.shwebspace.com/uploads/665d7237/72-182x182%20V.jpg", "power": 615, "priceW": 0.53, "visible": false, "datasheetUrl": "https://jinkosolar.eu/wp-content/uploads/JKM605-625N-78HL4-BDV-F3-EN-1.pdf"}, {"isc": 16.08, "voc": 49.08, "iimp": 15.22, "vimp": 40.74, "brand": "JINKO", "image": "https://jinkosolarcdn.shwebspace.com/uploads/665d7237/72-182x182%20V.jpg", "power": 620, "priceW": 0.53, "visible": false, "datasheetUrl": "https://jinkosolar.eu/wp-content/uploads/JKM605-625N-78HL4-BDV-F3-EN-1.pdf"}, {"isc": 16.14, "voc": 48.09, "iimp": 15.33, "vimp": 39.79, "brand": "TRINA", "image": "https://www-cdn.trinasolar.com/wwwstorage/sites/17/635W-TSM-NEG19RC20.png", "power": 610, "priceW": 0.49, "visible": false, "datasheetUrl": "http://static.trinasolar.com/sites/default/files/Vertex_NEG19RC.20_EN_2023_APAC_B_web.pdf"}, {"isc": 16.05, "voc": 48.78, "iimp": 15.16, "vimp": 40.91, "brand": "Longi", "image": "https://static.longi.com/Hi_MO_9_8f7fb3dbfe.png", "power": 620, "priceW": 0.5, "visible": false, "datasheetUrl": "https://static.longi.com/2_LR_7_72_HGD_585_620_M_V2_30_30_and_15_V05_EN_c6514bcafc.pdf"}, {"isc": 18.55, "voc": 49.28, "iimp": 17.55, "vimp": 41.03, "brand": "TW", "power": 720, "priceW": 0.55, "visible": true}, {"isc": 0.0416, "voc": 50.44, "iimp": 15.34, "vimp": 42.7, "brand": "Jinko", "power": 645, "priceW": 0.55, "visible": true}, {"isc": 18.55, "voc": 48.8, "iimp": 17.44, "vimp": 41, "brand": "JA", "power": 715, "priceW": 0.56, "visible": true}], "offgrid": {"panelIdx": 0, "sunHours": 6, "batteryDoD": 0.8, "appliancePresets": [{"name": "لمبة إضاءة LED", "watts": 10, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "DVR / NVR", "watts": 25, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "راوتر / شاحن", "watts": 15, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "كاميرا مراقبة", "watts": 10, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "لابتوب", "watts": 65, "dayHours": 6, "nightHours": 0, "surgeMultiplier": 1}, {"name": "مروحة", "watts": 70, "dayHours": 4, "nightHours": 6, "surgeMultiplier": 3}, {"name": "شفاط مطبخ", "watts": 75, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 3}, {"name": "تلفاز LCD / كاميرات CCTV", "watts": 60, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 1}, {"name": "تلفاز LCD", "watts": 80, "dayHours": 3, "nightHours": 3, "surgeMultiplier": 1}, {"name": "ثلاجة", "watts": 150, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 5}, {"name": "كشاف إنارة", "watts": 200, "dayHours": 0, "nightHours": 12, "surgeMultiplier": 1}, {"name": "فريزر", "watts": 200, "dayHours": 6, "nightHours": 18, "surgeMultiplier": 5}, {"name": "موتور 1 حصان", "watts": 740, "dayHours": 0.25, "nightHours": 2, "surgeMultiplier": 5}, {"name": "ميكروويف", "watts": 1000, "dayHours": 1, "nightHours": 1, "surgeMultiplier": 1}, {"name": "موتور 1.5 حصان / غاطس", "watts": 1100, "dayHours": 2, "nightHours": 0.5, "surgeMultiplier": 5}, {"name": "تكييف 1.5 حصان", "watts": 1100, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "غسالة", "watts": 1500, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 3}, {"name": "تكييف 2.5 حصان", "watts": 1800, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "تكييف 3 حصان", "watts": 2200, "dayHours": 6, "nightHours": 8, "surgeMultiplier": 5}, {"name": "هيتر مياه", "watts": 9000, "dayHours": 2, "nightHours": 0, "surgeMultiplier": 1}], "batteryMarkupPct": 10, "cablingFixedCost": 800, "cablingFixedSell": 1400, "installPerKwCost": 300, "installPerKwSell": 500, "systemEfficiency": 0.85, "applianceDefaults": [{"qty": 1, "name": "ثلاجة", "watts": 150, "dayHours": 4, "nightHours": 4}, {"qty": 10, "name": "إضاءة LED", "watts": 10, "dayHours": 0, "nightHours": 6}, {"qty": 1, "name": "تلفزيون", "watts": 120, "dayHours": 2, "nightHours": 3}, {"qty": 1, "name": "مروحة/تكييف نافذة", "watts": 900, "dayHours": 3, "nightHours": 3}, {"qty": 1, "name": "مضخة مياه منزلية", "watts": 750, "dayHours": 1, "nightHours": 0}], "inverterMarkupPct": 10, "inverterSurgeRatio": 2, "defaultAutonomyDays": 0, "structurePerPanelCost": 120, "structurePerPanelSell": 180, "nightLoadRatioFallback": 0.5, "inductiveSurgeMultiplier": 3}, "cbLadder": [32, 63, 80, 100, 125, 160, 200, 250], "discounts": [{"brand": "VEICHI", "category": "شواحن/انفرترات هجين MPPT", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "SINOBOLY", "category": "بطاريات ليثيوم", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "بطاريات ليثيوم", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "الريأكتور (Reactor)", "promoActive": true, "sellDiscountPct": -5, "promoDiscountPct": -20, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "صناديق التجميع (Combiner Box)", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "الكابلات والوصلات (MC4)", "promoActive": true, "sellDiscountPct": -30, "promoDiscountPct": -30, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "قواطع وفيوزات DC", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": -5, "supplierDiscountPct": 0}, {"brand": "VEICHI", "category": "انفرتر مضخات VEICHI", "promoActive": true, "sellDiscountPct": 0, "promoDiscountPct": 0, "supplierDiscountPct": 10}, {"brand": "Aiko", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -2, "promoDiscountPct": -10, "supplierDiscountPct": 0}, {"brand": "Jinko", "category": "الألواح الشمسية", "promoActive": true, "sellDiscountPct": -2, "promoDiscountPct": -10, "supplierDiscountPct": 0}], "portfolio": {"hero": {"image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/2a2d2198-8f86-4314-9578-e07ca96e2fc6.jpg", "title": "بورتفوليو حلول الطاقة", "description": "حلول EPC متخصصة في أنظمة الري الزراعي بالطاقة الشمسية داخل المملكة، مبنية على خبرة هندسية في مصر ومشاريع منفذة في وادي الدواسر."}, "kpis": [{"l": "مشاريع منفذة في السعودية", "v": "5"}, {"l": "نطاق قدرات الري المنفذة", "v": "60-500 HP"}, {"l": "هندسة، توريد، تنفيذ، تشغيل", "v": "EPC"}, {"l": "تشغيل داخل المملكة", "v": "2026"}], "partners": [{"img": "assets/portfolio/partner-sunarabia.png", "name": "SUNARABIA"}, {"img": "assets/portfolio/partner-afkarco.png", "name": "AFKARCO"}, {"img": "assets/portfolio/partner-veichi.png", "name": "VEICHI"}, {"img": "assets/portfolio/partner-risen.png", "name": "RISEN"}, {"img": "assets/portfolio/partner-ja-solar.png", "name": "JA Solar"}, {"img": "assets/portfolio/partner-leader.png", "name": "LEADER"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/4f8a3bb0-65a5-4a0d-be0c-b4d62a0dadc8.webp", "name": "SUNGROW"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a0170a92-5a2c-41d5-a1c5-37f0df8df7aa.jpg", "name": "HUAWEI"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/52f9727d-ce5b-4d72-ad68-6a61026bf413.webp", "name": "AIKO"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ac49468e-2a0d-4683-8e56-525dff5440d7.png", "name": "KAYAL"}, {"img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/2b736448-1519-4a9e-a2d2-b51a46e6a65a.webp", "name": "TONGWEI"}], "projects": [{"hp": "500 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/d21592fc-8ad7-4cab-b173-c2523c14ea44.jpg", "desc": "مشروع عالي القدرة لتقليل تكلفة تشغيل مضخات الديزل وتحسين استقرار التشغيل.", "tags": ["استثمار 720000 ريال", "استرداد تقريبي 10 أشهر"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "200 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/27a05e2f-2e03-4bd5-a02b-38159daa5f68.jpg", "desc": "تصميم وتنفيذ منظومة ضخ شمسي بقدرة متوسطة لخدمة احتياج ري يومي مستمر.", "tags": ["EPC", "تشغيل زراعي"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "125 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fbfce0c4-66f4-4858-bf4e-febfbf5210e9.jpg", "desc": "حل هندسي موجه للمزارع التي تحتاج تكلفة طاقة يمكن التنبؤ بها على المدى الطويل.", "tags": ["تصميم", "توريد وتركيب"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "60 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a4d90276-6b7b-46ed-b9b4-c2581fa59248.jpg", "desc": "حالة أعمال حققت تخفيضًا ملموسًا في تكلفة الوقود الشهرية للمزرعة.", "tags": ["استثمار 85000 ريال", "استرداد تقريبي 9 أشهر"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}, {"hp": "60 HP", "img": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/0e75273a-34c4-46c1-914c-532316ff70f9.jpg", "desc": "تنفيذ منظومة شمسية للري مع اختبار وتشغيل وتسليم فني للموقع.", "tags": ["اختبار وتشغيل", "دعم فني"], "place": "وادي الدواسر - 2026", "title": "منظومة ري زراعي بالطاقة الشمسية"}], "roiCases": [{"l": "تكلفة ديزل شهرية 10-12 ألف ريال، استرداد تقريبي 9 أشهر.", "v": "60 HP"}, {"l": "تكلفة ديزل شهرية تقارب 75 ألف ريال، استرداد تقريبي 10 أشهر.", "v": "500 HP"}, {"l": "تكلفة ديزل شهرية 30 ألف ريال، استرداد تقريبي 10 أشهر.", "v": "200 HP"}, {"l": "تكلفة ديزل شهرية 20 ألف ريال، استرداد تقريبي 9 أشهر.", "v": "125 HP"}], "timeline": [{"desc": "تنفيذ مشاريع ري شمسي، Off-grid، ومشاريع تجارية وصناعية.", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/5ce39b7c-6394-4f45-9871-171479f81b06.jpg", "label": "الأصل", "title": "Alasl Solar - Egypt"}, {"desc": "تركيز عميق على أنظمة الضخ والري من 30 HP إلى 500 HP.", "image": null, "label": "النمو", "title": "تخصص زراعي"}, {"desc": "تأسيس وتشغيل في المملكة مع مشاريع منفذة في وادي الدواسر.", "image": null, "label": "2026", "title": "Holoul Energy KSA"}], "panelNote": "نقيس نجاح المشروع بالعائد الذي يحققه للعميل، وليس بعدد الألواح فقط. هدفنا تقليل تكلفة التشغيل، رفع الاعتمادية، وبناء أصل طويل الأجل للمزرعة.", "panelTitle": "Engineering Value Beyond Solar", "projectsTag": "وادي الدواسر - 2026", "businessCases": [{"hp": "60 HP", "place": "وادي الدواسر — ري زراعي — 2026", "title": "منظومة ري زراعي بالطاقة الشمسية", "diesel": "10,000–12,000 ريال", "payback": "≈ 9 أشهر", "results": ["التخلص من معظم تكلفة الديزل الشهرية", "تقليل احتياجات الصيانة ومخاطر التوقف", "إزالة التعرض لارتفاع أسعار الديزل مستقبلًا", "تحقيق فترة استرداد خلال ٩ أشهر تقريبًا"], "investment": "85,000 ريال"}, {"hp": "500 HP", "place": "وادي الدواسر — ري زراعي — 2026", "title": "منظومة ري زراعي بالطاقة الشمسية", "diesel": "≈ 75,000 ريال", "payback": "≈ 10 أشهر", "results": ["خفض ملموس في تكلفة التشغيل الشهرية", "انخفاض عبء الصيانة على أسطول المضخات", "تقليل المخاطر التشغيلية المرتبطة بتوريد الديزل", "استرداد رأس المال خلال ١٠ أشهر تقريبًا"], "investment": "720,000 ريال"}], "projectsTitle": "مشاريع منفذة في المملكة", "capabilitySteps": [{"l": "Survey ودراسة الموقع", "v": "01"}, {"l": "تصميم هندسي وتحجيم النظام", "v": "02"}, {"l": "توريد من شركاء موثوقين", "v": "03"}, {"l": "تركيب واختبارات حماية", "v": "04"}, {"l": "Commissioning وتسليم", "v": "05"}, {"l": "دعم فني وتشغيل وصيانة", "v": "06"}]}, "mc4PerUnit": 5, "cableMarkup": 1.3, "cablePerMeter": 4, "combinerBoxes": [[4, 749], [8, 949], [10, 1149], [16, 1649], [22, 2649], [30, 3849], [34, 4598], [38, 4798], [40, 4998], [46, 5498], [50, 6147], [56, 6647], [60, 7698], [64, 8447], [68, 8647], [70, 8847], [76, 9347], [90, 11547]], "discountTiers": [{"label": "بدون خصم", "factor": 0}, {"label": "خصم عميل مزرعة", "factor": 0.2}, {"label": "خصم عميل مشروع زراعي", "factor": 0.4}, {"label": "خصم عميل شركات", "factor": 0.6}, {"label": "خصم خاص", "factor": 0.8}], "reactorLadder": [50, 80, 100, 160, 315, 450, 560, 1000], "reactorPrices": {"50": 389, "80": 479, "100": 499, "160": 599, "315": 999, "450": 1374, "560": 1539, "1000": 2529}, "stringsAdjust": 0, "batteryCatalog": [{"model": "VCLB-1.2K-100-Li", "voltage": "12.8V", "capacityWh": 1280, "priceExclVat": 782}, {"model": "VCLB-2.5K-200-Li", "voltage": "12.8V", "capacityWh": 2560, "priceExclVat": 1100}, {"model": "VCLB-2.5K-100-Li", "voltage": "25.6V", "capacityWh": 2560, "priceExclVat": 1100}, {"model": "VCLB-5.1K-200-Li", "voltage": "25.6V", "capacityWh": 5120, "priceExclVat": 2100}, {"model": "VCLB-5k-w01", "voltage": "51.2V", "capacityWh": 5120, "priceExclVat": 2609}, {"model": "VCLB-10k-w02", "voltage": "51.2V", "capacityWh": 10240, "priceExclVat": 4500}, {"model": "VCLB-15k-BC", "voltage": "51.2V", "capacityWh": 14336, "priceExclVat": 5652}], "productCatalog": [{"rows": [["VCLB-1.2K-100-Li", "100A", "12.8V", "749", "861.35"], ["VCLB-2.5K-200-Li", "200A", "12.8V", "1100.00", "1265.00"], ["VCLB-2.5K-100-Li", "100A", "25.6V", "1100.00", "1265.00"], ["VCLB-5.1K-200-Li", "200A", "25.6V", "2100.00", "2415.00"], ["VCLB-5k-w01", "100A", "51.2V", "2609.00", "3000.35"], ["VCLB-10k-w02", "200A", "51.2V", "4500.00", "5175.00"], ["VCLB-15k-BC", "280A", "51.2V", "5652.00", "6499.80"], ["Sinoboly-200A-25.1Vs", "200A", "25.1", "2600", "2847.62"], ["Sinoboly-200A-51V", "200A", "51", "4500", "5175"], ["Sinoboly-628A-51V", "628A", "51", "10500", "12075"]], "columns": ["الموديل", "التيار", "الفولت", "السعر", "السعر شامل الضريبة"], "category": "بطاريات ليثيوم", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/f3d8a8eb-d1a4-4f20-b564-7ce7aa006144.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "7.5 كجم", "أقصى جهد شحن": "14.6 فولت", "الجهد الاسمي": "12.8 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "100A", "السعة الاسمية": "100Ah (1280Wh)", "الأبعاد (ط×ع×ا)": "260×168×211 مم", "جهد قطع التفريغ": "10.8 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "100A", "ذروة تيار التفريغ": "200A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "50A"}, "available": true, "description": "بطارية ليثيوم حديد فوسفات (LiFePO4) بجهد 12.8 فولت، بتصميم خفيف الوزن (ثلث وزن بطارية الرصاص الحمضية المكافئة) وسعة استخدام كاملة 100%، مناسبة للتطبيقات البحرية والمقطورات (RV) والأنظمة المنفصلة عن الشبكة.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "22 كجم", "أقصى جهد شحن": "14.6 فولت", "الجهد الاسمي": "12.8 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "200A", "السعة الاسمية": "200Ah (2560Wh)", "الأبعاد (ط×ع×ا)": "484×168×240 مم", "جهد قطع التفريغ": "10.8 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "200A", "ذروة تيار التفريغ": "400A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 12.8 فولت وسعة أعلى (200Ah)، من نفس عائلة VCLB خفيفة الوزن، مناسبة للتطبيقات البحرية والمقطورات والأنظمة المنفصلة عن الشبكة التي تحتاج طاقة تخزين أكبر.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "22 كجم", "أقصى جهد شحن": "29.2 فولت", "الجهد الاسمي": "25.6 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "100A", "السعة الاسمية": "100Ah (2560Wh)", "الأبعاد (ط×ع×ا)": "484×168×240 مم", "جهد قطع التفريغ": "21.6 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "100A", "ذروة تيار التفريغ": "200A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "50A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 25.6 فولت (24 فولت اسمي)، بنفس مزايا عائلة VCLB — وزن خفيف وسعة استخدام كاملة، مناسبة لأنظمة 24 فولت المنفصلة عن الشبكة.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/fd071a3a-8aea-4864-adbb-d767debe1184.jpg", "specs": {"الوزن": "37 كجم", "أقصى جهد شحن": "29.2 فولت", "الجهد الاسمي": "25.6 فولت", "درجة الحماية": "IP65", "أقصى تيار شحن": "200A", "السعة الاسمية": "200Ah (5120Wh)", "الأبعاد (ط×ع×ا)": "520×267×220 مم", "جهد قطع التفريغ": "21.6 فولت", "مدى حرارة الشحن": "0 إلى 55°م", "أقصى تفريغ مستمر": "200A", "ذروة تيار التفريغ": "400A", "مدى حرارة التفريغ": "-20 إلى 60°م", "تيار الشحن الموصى به": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 25.6 فولت وسعة أعلى (200Ah)، مناسبة لأنظمة 24 فولت المنفصلة عن الشبكة التي تحتاج طاقة تخزين أكبر.", "datasheetUrl": "https://www.veichi.com/product/vclb-12-51K-100-200-li-rechargeable-lithium-ion-battery.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/086a486b-8d0e-4b73-a891-0aa9aa01ec26.jpg", "specs": {"الوزن": "47.2 كجم", "الأبعاد": "520×470×141.5 مم", "الاتصال": "RS232 / CAN / RS485", "التوازي": "حتى 15 وحدة", "عمر الدورة": "6000 دورة عند 80% عمق تفريغ", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "جهد قطع الشحن": "56.16 فولت", "السعة الاسمية": "100Ah (5120Wh)", "جهد قطع التفريغ": "45.6 فولت", "تيار الشحن الموصى به": "50A (0.5C)", "أقصى تيار تفريغ مستمر": "100A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت (48 فولت اسمي) بتصميم تركيب حائطي جديد، تدعم توصيل حتى 15 وحدة على التوازي لزيادة السعة، مزودة بشاشة LED لحالة الشحن، ومناسبة لأنظمة التخزين المنزلية والتجارية الصغيرة.", "datasheetUrl": "https://www.veichi.com/product/vclb-5k-w01-rechargeable-lithium-ion-battery.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/e1f16aac-3a5f-428b-83cc-aec4d5923a61.jpg", "specs": {"الوزن": "96.5 كجم", "الأبعاد": "800×590×142 مم", "الاتصال": "RS232 / CAN / RS485", "التوازي": "حتى 15 وحدة", "عمر الدورة": "6000 دورة عند 80% عمق تفريغ", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "جهد قطع الشحن": "56.16 فولت", "السعة الاسمية": "200Ah (10240Wh)", "جهد قطع التفريغ": "45.6 فولت", "تيار الشحن الموصى به": "100A (0.5C)", "أقصى تيار تفريغ مستمر": "200A", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "VCLB-10K-W01"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت وسعة أعلى (200Ah)، بنفس تصميم التركيب الحائطي وشاشة LED، تدعم حتى 15 وحدة على التوازي.", "datasheetUrl": "https://www.veichi.com/product/vclb-10k-w01-rechargeable-lithium-ion-battery.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/f8caafa9-9421-4542-afd0-be488f3b4bd0.jpg", "specs": {"الوزن": "128.9 كجم", "الأبعاد": "800×500×227 مم", "الاتصال": "CAN / RS485 / RS232", "التوازي": "حتى 16 وحدة (حتى 229 كيلوواط/ساعة)", "ذروة تفريغ": "250A لمدة 10 دقائق", "عمر الدورة": "6000 دورة عند 25°م", "الجهد الاسمي": "51.2 فولت", "درجة الحماية": "IP65", "كثافة الطاقة": "حتى 166 واط/ساعة لكل كجم", "السعة الاسمية": "280Ah (14,336Wh)", "مدى جهد التشغيل": "46.4–57.6 فولت", "أقصى ارتفاع تشغيل": "3000 متر", "أقصى تيار شحن/تفريغ": "200A", "التيار الاسمي للشحن/التفريغ": "140A"}, "available": false, "description": "بطارية ليثيوم حديد فوسفات بجهد 51.2 فولت وسعة 280Ah، بخلايا من درجة EVE A+ ونظام حماية متعدد المستويات، تدعم التوازي حتى 16 وحدة (سعة إجمالية حتى 229 كيلوواط/ساعة)، ومتوافقة مع كل انفرترات 48 فولت التي تدعم بطاريات LFP.", "datasheetUrl": "https://www.veichi.com/product/vclb-15-bc-high-voltage-lithium-battery.html"}, "7": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "specs": {}, "available": true, "description": ""}, "8": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "available": true}, "9": {"brand": "SINOBOLY", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/da61a7ae-2952-48d6-a69f-7b05d4bacaf3.jpg", "available": true}}}, {"rows": [["SIS4-12V 1KW MPPT", "40A", "150 VDC", "449", "516.35"], ["SIS4-12V 2KW MPPT", "80A", "400 VDC", "699", "803.85"], ["SIS-24V 3KW MPPT", "100A", "450 VDC", "999", "1148.85"], ["SISV-24V 4.2KW (TWIN) MPPT", "120A", "500 VDC", "1049", "1206.35"], ["SIS 5KW-S MPPT", "100A", "500 VDC", "1149", "1321.35"], ["SISV 6.2KW (TWIN) MPPT", "120A", "500 VDC", "1199", "1378.85"], ["SISV 8KW (TWIN) MPPT", "120A", "500 VDC", "2299", "2643.85"], ["SISV 11KW (TWIN) MPPT", "150A", "500 VDC", "2499", "2873.85"], ["VLT 10KW 3P IP65", "220A", "800 VDC", "5899", "6783.85"], ["VLT 12KW 3P IP65", "250A", "800 VDC", "6399", "7358.85"], ["VLT 15KW 3P IP65", "290A", "800 VDC", "7499", "8623.85"], ["VHT 20KW IP65", "40A", "1000 VDC", "8499", "9773.85"], ["VHT 30KW IP65", "100A", "1000 VDC", "15499", "17823.85"], ["VHT 50KW IP65", "100A", "1000 VDC", "19499", "22423.85"], ["VCHB-61.4K-STF High Voltage Rack", "1C", "-", "43999", "50598.85"]], "columns": ["الموديل", "التيار (A)", "أقصى جهد DC", "السعر", "السعر شامل الضريبة"], "category": "شواحن/انفرترات هجين MPPT", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/0a14eac4-e583-4ff9-8522-e1ed8d054842.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "20–150 VDC", "الوزن الصافي": "3.5 كجم", "أقصى تيار شحن AC": "40A", "الأبعاد (ط×ع×ا)": "290×240×91 مم", "القدرة المقننة": "1000W / 1000VA", "أقصى تيار شحن شمسي": "40A", "زمن التحويل (Transfer Time)": "10ms", "أقصى قدرة ألواح مسموحة": "600W", "الاسم الرسمي عند فيتشي": "SIS4-1K-12-S", "ذروة الكفاءة (شمسي → خرج)": "98%", "ذروة الكفاءة (بطارية → خرج)": "94%"}, "available": true, "description": "شاحن/انفرتر MPPT مدمج لأنظمة التخزين المنزلية بجهد بطارية 12 فولت، بمخرج موجة جيبية نقية (Pure Sine Wave) وشاشة LCD ملونة، ويدعم التحكم عن بعد عبر تطبيق الجوال (واي فاي/GPRS).", "datasheetUrl": "https://www.veichi.com/product/off-grid-inverter/"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "30–400 VDC", "الوزن الصافي": "4.6 كجم", "منافذ الاتصال": "RS232 / GPRS / WIFI", "أقصى تيار شحن AC": "60A", "الأبعاد (ط×ع×ا)": "357×273×95 مم", "القدرة المقننة": "2000W / 1600W", "أقصى تيار شحن شمسي": "80A", "زمن التحويل (Transfer Time)": "10ms (كمبيوتر) / 20ms (أجهزة منزلية)", "أقصى قدرة ألواح مسموحة": "3000W", "الاسم الرسمي عند فيتشي": "SIS4-2K-12-S", "ذروة الكفاءة (شمسي → خرج)": "98%", "ذروة الكفاءة (بطارية → خرج)": "94%"}, "available": true, "description": "نفس عائلة SIS4 بقدرة أعلى (2 كيلوواط) وجهد دخول شمسي أوسع يصل حتى 400 فولت، مناسب لأنظمة تخزين منزلية أكبر تحتاج قدرة ألواح إضافية.", "datasheetUrl": "https://www.veichi.com/product/off-grid-inverter/"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/7420a827-c99a-4741-a478-3211e07b4644.jpg", "specs": {"مدى جهد MPPT": "120–430 VDC", "التوازي (Parallel)": "حتى 9 وحدات", "أقصى تيار خرج AC": "13A", "القدرة المقننة": "3000W", "أقصى تيار دخول DC": "13A", "أقصى كفاءة تحويل (ربط شبكة)": "95%", "كفاءة (بطارية → تيار متردد)": "93%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SIS-3K-H"}, "available": true, "description": "انفرتر هجين (Hybrid) بقدرة 3 كيلوواط يدعم التوازي حتى 9 وحدات وإخراج موجة جيبية نقية، مناسب لأنظمة التخزين المنزلية متوسطة الحجم.", "datasheetUrl": "https://www.veichi.com/product/sis-hybrid-solar-inverter.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "18.2A", "أقصى تيار شحن AC": "100A", "القدرة المقننة": "4200W", "أقصى تيار دخول DC": "18A", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "120A", "جهد البطارية الاسمي": "24 / 48 فولت", "الاسم الرسمي عند فيتشي": "SISV-4.2K-H(TWIN)", "كفاءة (بطارية → تيار متردد)": "94%", "أقصى حمل ثانوي (وضع البطارية)": "1400W"}, "available": true, "description": "انفرتر هجين بمخرجين مستقلين (TWIN) يسمح بتغذية حملين مختلفين في نفس الوقت مع أولويات وجدولة يومية قابلة للبرمجة، ويعمل بجهد بطارية 24 أو 48 فولت.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6a9bbf1f-fee4-42f9-beb7-765129edebd4.jpg", "specs": {"مدى جهد MPPT": "120–430 VDC", "أقصى تيار شحن": "100A", "التوازي (Parallel)": "حتى 9 وحدات", "أقصى تيار خرج AC": "21.7A", "القدرة المقننة": "5000W", "أقصى تيار دخول DC": "27A", "جهد البطارية الاسمي": "48 فولت", "الاسم الرسمي عند فيتشي": "SIS-5K-H", "أقصى كفاءة تحويل (ربط شبكة)": "95%", "كفاءة (بطارية → تيار متردد)": "93%"}, "available": true, "description": "انفرتر هجين بقدرة 5 كيلوواط من نفس عائلة SIS، يدعم التوازي حتى 9 وحدات، مناسب للمنازل ذات الاستهلاك الأعلى.", "datasheetUrl": "https://www.veichi.com/product/sis-hybrid-solar-inverter.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "27A", "أقصى تيار شحن AC": "100–140A", "القدرة المقننة": "6200W", "أقصى تيار دخول DC": "22A", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "140A", "جهد البطارية الاسمي": "24 / 48 فولت", "الاسم الرسمي عند فيتشي": "SISV-6.2K-H(TWIN)", "كفاءة (بطارية → تيار متردد)": "94%"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN) بقدرة أعلى (6.2 كيلوواط)، مناسب لأحمال منزلية أكبر مع نفس مزايا الأولويات والجدولة القابلة للبرمجة.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "عدد متتبعات MPPT": "2", "أقصى تيار خرج AC": "35.6A", "أقصى تيار شحن AC": "100–140A", "القدرة المقننة": "8200W", "أقصى تيار دخول DC": "2×18A (متتبعين MPPT، 18A لكل متتبع)", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "140A", "جهد البطارية الاسمي": "24 / 48 فولت", "كفاءة (بطارية → تيار متردد)": "94%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SISV-8.2K-H(TWIN)"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN)، الطراز الرسمي المنشور بقدرة 8.2 كيلوواط (كتالوجك يذكره تقريبًا كـ 8 كيلوواط).", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6fd66add-0eef-4839-bd48-478cca9eaabb.jpg", "specs": {"مدى جهد MPPT": "60–450 VDC", "أقصى تيار خرج AC": "44.3A", "أقصى تيار شحن AC": "140A", "القدرة المقننة": "10200W", "أقصى تيار دخول DC": "2×18A (ثنائي تتبع MPPT)", "أقصى كفاءة تحويل": "98%", "أقصى تيار شحن شمسي": "160A", "جهد البطارية الاسمي": "24 / 48 فولت", "كفاءة (بطارية → تيار متردد)": "94%", "الاسم الرسمي عند فيتشي (أقرب تطابق)": "SISV-10.2K-H(TWIN)"}, "available": true, "description": "نفس عائلة SISV ثنائية المخرج (TWIN)، بأعلى قدرة في هذه السلسلة.", "datasheetUrl": "https://www.veichi.com/product/sisv-hybrid-grid-solar-inverter.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"اتصال": "واي فاي مدمج للمراقبة عن بُعد", "التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "عدد متتبعات MPPT": "2", "جهد بطارية اسمي": "40–62 VDC (وحدة نمطية)", "عدد أطوار الخرج": "3 أطوار (230VAC فاز-تعادل / 400VAC فاز-فاز)", "أقرب عائلة رسمية عند فيتشي": "VLT-12K-H/VLT-15K-H (نفس المنصة)", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "أقصى تيار خرج AC (طوارئ شبكة)": "40A", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65 (يعمل داخليًا وخارجيًا)، بمخرجين مستقلين قابلين للبرمجة وتوازي حتى 6 وحدات.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "9": {"brand": "VEICHI", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "القدرة المقننة": "12000W", "الجهد الاسمي للخرج": "230VAC (فاز-تعادل) / 400VAC (فاز-فاز)", "دعم عدم توازن الحمل": "150%", "التيار المقنن للخرج": "17.4A / 21.7A لكل طور", "أقصى تيار شحن بطارية": "حتى 250–300A", "أقصى تيار دخول AC (شبكة)": "40A", "الاسم الرسمي عند فيتشي": "VLT-12K-H", "عدد متتبعات MPPT / أقصى تيار": "2 متتبع، 27A لكل متتبع", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65، بمخرجين مستقلين لتغذية نظامين مختلفين في نفس الوقت، ويدعم عدم توازن حمل حتى 150% بين الأطوار.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "10": {"brand": "VEICHI", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "350–950 VDC", "التوازي (Parallel)": "حتى 6 وحدات", "القدرة المقننة": "15000W", "الجهد الاسمي للخرج": "230VAC (فاز-تعادل) / 400VAC (فاز-فاز)", "دعم عدم توازن الحمل": "150%", "التيار المقنن للخرج": "17.4A / 21.7A لكل طور", "أقصى تيار شحن بطارية": "حتى 250–300A", "أقصى تيار دخول AC (شبكة)": "40A", "الاسم الرسمي عند فيتشي": "VLT-15K-H", "عدد متتبعات MPPT / أقصى تيار": "2 متتبع، 27A لكل متتبع", "أقصى كفاءة تحويل (ربط شبكة)": "96%", "كفاءة (بطارية → تيار متردد)": "91%"}, "available": true, "description": "نفس عائلة VLT ثلاثية الطور، بأعلى قدرة في هذه السلسلة (15 كيلوواط)، مناسب للفلل والمنشآت التجارية الصغيرة.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-1.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–950 VDC", "أقصى كفاءة": "98.4%", "عدد متتبعات MPPT": "2", "أقصى تيار خرج AC": "33.5A لكل طور", "القدرة المقننة": "20000W", "الكفاءة الأوروبية": "97.5%", "أقصى تيار دخول شمسي": "30A لكل متتبع (إجمالي 60A)", "أقصى تيار شحن/تفريغ": "40A / 40A", "الاسم الرسمي عند فيتشي": "VHT-20K-40-H", "زمن التحويل للطوارئ (UPS)": "أقل من 10ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "30 كيلوواط"}, "available": true, "description": "انفرتر هجين ثلاثي الطور بتصنيف IP65، مزوّد بشاشة LCD ملونة وتحكم عن بعد عبر التطبيق، مع تيار شحن/تفريغ يصل حتى 40A ومدى جهد بطارية واسع يناسب أنظمة الليثيوم الكبيرة.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-3.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–850 VDC", "أقصى كفاءة": "98.8%", "عدد متتبعات MPPT": "4", "يدعم مولد ديزل": "نعم", "أقصى تيار خرج AC": "50A لكل طور", "القدرة المقننة": "30000W", "الكفاءة الأوروبية": "98.3%", "أقصى تيار شحن/تفريغ": "100A / 100A", "الاسم الرسمي عند فيتشي": "VHT-30K-100-H", "التوازي (ربط شبكة / عزل)": "حتى 10 وحدات (ربط شبكة) / 4 وحدات (معزول)", "زمن التحويل للطوارئ (UPS)": "أقل من 20ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "45 كيلوواط"}, "available": true, "description": "انفرتر هجين ثلاثي الطور للمنشآت التجارية والصناعية الصغيرة، بتيار شحن/تفريغ مرتفع (100A) ودعم مولدات الديزل كمصدر طاقة احتياطي.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-4.html"}, "13": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a285c0f1-c831-4398-9ee4-2444a9ebc4f2.jpg", "specs": {"التصنيف": "IP65 — داخلي وخارجي", "مدى جهد MPPT": "200–950 VDC", "أقصى كفاءة": "98.8%", "عدد متتبعات MPPT": "4", "يدعم مولد ديزل": "نعم", "أقصى تيار خرج AC": "83A لكل طور", "القدرة المقننة": "50000W", "الكفاءة الأوروبية": "98.3%", "أقصى تيار شحن/تفريغ": "100A / 100A", "الاسم الرسمي عند فيتشي": "VHT-50K-100-H", "التوازي (ربط شبكة / عزل)": "حتى 10 وحدات (ربط شبكة) / 4 وحدات (معزول)", "زمن التحويل للطوارئ (UPS)": "أقل من 20ms", "جهد بطارية اسمي (ليثيوم)": "135–750 VDC", "أقصى قدرة ألواح موصى بها": "75 كيلوواط"}, "available": true, "description": "نفس عائلة VHT للمنشآت التجارية، بأعلى قدرة في هذه السلسلة (50 كيلوواط)، مناسب للمشاريع التجارية والصناعية متوسطة الحجم.", "datasheetUrl": "https://www.veichi.com/product/hybrid-solar-inverter-4.html"}, "14": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/b363e3e7-36c3-41cc-bc02-4c654939ac27.jpg", "specs": {"الوزن": "586 كجم", "الاتصال": "CAN / RS485، واي فاي مدمج", "التصنيف": "IP20 (تركيب داخلي)", "التوافق": "يعمل مع أغلب الانفرترات (فيتشي، Ingeteam، Solis، GoodWe، Growatt، Solplanet، SAJ، Deye، Hoymiles وغيرها)", "عمر الدورة": "≥8000 دورة / 10 سنوات", "نوع الخلية": "ليثيوم حديد فوسفات LiFePO4", "الجهد/السعة": "614.3V / 100Ah", "الأبعاد (ع×ق×ا)": "590×390×1829 مم", "عمق التفريغ (DoD)": "95%", "مدى جهد التشغيل": "535.2–691.2 VDC", "نظام إطفاء الحريق": "إطفاء بالإيروسول، يكتشف ويطفئ خلال 5 ثوانٍ", "أقصى تيار شحن/تفريغ": "100A (1C)", "الاسم الرسمي عند فيتشي": "VCHB-61.4K-STF (تهيئة 12 طبقة)", "عدد الطبقات (وحدات نمطية)": "12 طبقة", "الطاقة الإجمالية (لهذه التهيئة)": "61.44 كيلوواط/ساعة", "ذروة تيار تفريغ (لمدة دقيقتين، 25°م)": "125A (1.25C)"}, "available": true, "description": "بطارية ليثيوم عالية الجهد (LiFePO4) بتصميم \\"بدون رف\\" (Rackless) قابل للتكديس المباشر (Plug & Play)، تُركّب الوحدة الواحدة خلال 30 دقيقة تقريبًا. تدعم توصيل حتى 12 حزمة على التوازي (حتى 921 كيلوواط/ساعة إجمالاً)، ومزودة بنظام إطفاء حريق ذكي يكتشف ويطفئ الحريق خلال 5 ثوانٍ. متوافقة مع أغلب الانفرترات المعروفة (فيتشي، جروات، جودوي، ديي، هويملز، وغيرها).", "datasheetUrl": "https://www.veichi.com/product/vchb-614k-stf-rechargeable-lithium-ion-battery.html"}}}, {"rows": [["VEICHI Reactor 16A", "1%", "296.00", "340.40"], ["VEICHI Reactor 28A", "1%", "319.00", "366.85"], ["VEICHI Reactor 50A", "1%", "389.00", "447.35"], ["VEICHI Reactor 80A", "1%", "479.00", "550.85"], ["VEICHI Reactor 100A", "1%", "499.00", "573.85"], ["VEICHI Reactor 160A", "1%", "599.00", "688.85"], ["VEICHI Reactor 224A", "1%", "839.00", "964.85"], ["VEICHI Reactor 315A", "1%", "999.00", "1148.85"], ["VEICHI Reactor 450A", "1%", "1374.00", "1580.10"], ["VEICHI Reactor 560A", "1%", "1539.00", "1769.85"], ["VEICHI Reactor 690A", "1%", "1594.00", "1833.10"], ["VEICHI Reactor 1000A", "1%", "2529.00", "2908.35"], ["VEICHI Reactor 1250A", "1%", "2999.00", "3448.85"], ["VEICHI Reactor 560A", "4%", "4899.00", "5633.85"], ["VEICHI Reactor 1000A", "4%", "5799.00", "6668.85"], ["VEICHI Reactor 1250A", "4%", "6299.00", "7243.85"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "الريأكتور (Reactor)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/bd48f50d-b084-4c5e-b11f-fc36d68c8cc7.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "16 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 16 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "28 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 28 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "50 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 50 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "80 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 80 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "100 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 100 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "160 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 160 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "224 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 224 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "315 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 315 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "450 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 450 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "690 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 690 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "1%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 1%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 1%% هي الأشيع للاستخدام المنزلي/التجاري القياسي.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "13": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "560 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 560 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "14": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1000 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1000 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}, "15": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/70fcadd0-5f16-48e9-af2b-777c605683f7.jpg", "specs": {"الوظيفة": "تقليل التوافقيات (THD) والحد من تيار الاندفاع", "التيار المقنن": "1250 أمبير", "نسبة المعاوقة (Impedance)": "4%", "موضع التركيب المعتاد": "على التوالي بين المصدر والانفرتر (AC أو DC حسب التصميم)"}, "available": true, "description": "مفاعل تخانق (Line Reactor) بتيار مقنن 1250 أمبير ونسبة معاوقة 4%، يُركّب على التوالي بين مصدر الطاقة والانفرتر لتقليل التوافقيات الكهربائية (Harmonics) والحد من تيار الاندفاع (Inrush Current) عند بدء التشغيل، مما يطيل عمر مكونات الانفرتر ويقلل التداخل الكهرومغناطيسي. فئة 4%% توفر تصفية توافقيات أعلى من فئة 1%%، وتُفضَّل مع المولدات أو الشبكات ضعيفة الاستقرار.", "datasheetUrl": "https://www.veichi.com/product/output-filter-reactor.html"}}}, {"rows": [["VEICHI Combiner BOX 04", "4+4 Input", "749.00", "861.35"], ["VEICHI Combiner BOX 08", "8+8 Input", "949.00", "1091.35"], ["VEICHI Combiner BOX 10", "10+10 Input", "1149.00", "1321.35"], ["VEICHI Combiner BOX 16", "16+16 Input", "1649.00", "1896.35"], ["VEICHI Combiner BOX 22", "22+22 Input", "2649.00", "3046.35"], ["VEICHI Combiner BOX 30", "30+30 Input", "3849.00", "4426.35"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "صناديق التجميع (Combiner Box)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/5890dc85-20e8-410a-9973-48b6cbfc2a08.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "4+4 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 4 سلسلة من الألواح الشمسية (4 موجب + 4 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "8+8 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 8 سلسلة من الألواح الشمسية (8 موجب + 8 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "10+10 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 10 سلسلة من الألواح الشمسية (10 موجب + 10 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "16+16 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 16 سلسلة من الألواح الشمسية (16 موجب + 16 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "22+22 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 22 سلسلة من الألواح الشمسية (22 موجب + 22 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/ed3fae71-f83f-459e-880b-ed7220637d23.jpg", "specs": {"الوظيفة": "تجميع تيار عدة سلاسل من الألواح الشمسية في مخرج واحد", "الحماية المعتادة": "فيوز DC لكل سلسلة + مانع صواعق (SPD)", "عدد مداخل السلاسل": "30+30 (موجب/سالب)", "درجة الحماية المعتادة": "IP65 (تركيب خارجي)"}, "available": true, "description": "صندوق تجميع (PV Combiner Box) يدمج 30 سلسلة من الألواح الشمسية (30 موجب + 30 سالب) في مخرج واحد، ويحتوي عادة على فيوزات حماية لكل سلسلة على حدة ومانع صواعق (SPD)، مما يقلل عدد الكابلات الواصلة للانفرتر ويسهّل العزل عند الأعطال أو الصيانة.", "datasheetUrl": "https://www.veichi.com/product/pv-combiner-box/"}}}, {"rows": [["VEICHI MC4 Single", "1500 VDC", "4.00", "4.60"], ["VEICHI MC4 Dual Core", "1000 VDC", "18.00", "20.70"], ["VEICHI MC4 Dual Core", "1500 VDC", "22.00", "25.30"], ["كابل", "6 mm", "4", "4.6"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "الكابلات والوصلات (MC4)", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/3e6da5a3-1c5c-42dd-8c11-c40508378c21.webp", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/d8697bb3-25cc-4d51-a17e-1d49cc109c3d.jpg", "specs": {"مادة العزل": "PV40Z", "درجة الحماية": "IP68", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1500 فولت DC", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس الكابل المتوافق": "2.5 / 4 / 6 مم²", "معيار التنفيذ والاعتماد": "IEC 62852:2014 / TÜV"}, "available": true, "description": "موصل MC4 قياسي من سلسلة SI-PV005، بجهد تشغيل أقصى 1500 فولت DC وتيار مقنن 30 أمبير. درجة حماية IP68 (أعلى فئة، يتحمل الغمر المؤقت في الماء) ومقاومة تماس منخفضة جدًا (≤0.5 مللي أوم) تقلل الفقد والحرارة عند نقاط التوصيل. جسم العزل من مادة PV40Z المقاومة للأشعة فوق البنفسجية والحرارة، مناسب لتوصيل كابلات الألواح الشمسية بمقاس 2.5/4/6 مم² في الأنظمة عالية الجهد (1500V).", "datasheetUrl": "https://www.veichi.com/product/si-photovoltaic-dc-cable.html"}, "1": {"brand": "VEICHI", "specs": {"مادة العزل": "PC EXL9330 / XLPO", "درجة الحماية": "IP67", "شهادة المنتج": "CE", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1000 فولت DC", "الموصل المتوافق": "SI-PV004 / SI-PV005", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس كابل الدخل/الخرج": "1×4 مم² (متوفر أيضًا 6 مم²)"}, "available": true, "description": "وصلة Y من سلسلة SI-PV004-2T1 تجمع فرعين (2 إلى 1) من سلاسل الألواح الشمسية في كابل رئيسي واحد، بجهد تشغيل أقصى 1000 فولت DC وتيار مقنن 30 أمبير. تقلل عدد الكابلات الواصلة لصندوق التجميع أو الانفرتر، ودرجة حماية IP67 تجعلها مناسبة للتركيب الخارجي المستمر.", "datasheetUrl": "https://www.veichi.com/product/photovoltaic-dc-cable/"}, "2": {"brand": "VEICHI", "specs": {"مادة العزل": "PV40Z / XLPO", "درجة الحماية": "IP68", "شهادة المنتج": "CE", "التيار المقنن": "30 أمبير", "مقاومة التماس": "≤0.5 مللي أوم", "أقصى جهد تشغيل": "1500 فولت DC", "الموصل المتوافق": "SI-PV004 / SI-PV005", "درجة مقاومة اللهب": "UL94 V-0", "مادة ملامس التوصيل": "نحاس مطلي بالقصدير", "مدى الحرارة المحيطة": "-40°م إلى +85°م", "مقاس كابل الدخل/الخرج": "1×4 مم² (النسخة 4-إلى-1 تدعم 6 مم²)"}, "available": true, "description": "وصلة Y من سلسلة SI-PV005-2T1 تجمع فرعين (2 إلى 1) من سلاسل الألواح الشمسية في كابل رئيسي واحد، بجهد تشغيل أقصى 1500 فولت DC وتيار مقنن 30 أمبير. درجة حماية IP68 تجعلها مناسبة للأنظمة عالية الجهد والتركيب الخارجي طويل الأمد.", "datasheetUrl": "https://www.veichi.com/product/photovoltaic-dc-cable/"}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/528adffc-faa3-4659-acd4-7111a52c5f66.jpeg", "specs": {"الموصل": "نحاس مجدول مطلي بالقصدير (84×0.285 مم)", "شهادة المنتج": "TÜV SÜD EN50618:2014 CPR B2ca-s1a,d1,a1 (متوافق أيضًا مع TÜV Rheinland 2PfG 1169)", "المقطع العرضي": "6 مم²", "مدى درجة الحرارة": "-40°م إلى +90°م (تحمل قصير حتى 200°م لمدة 5 ثوانٍ)", "مقاومة الموصل (DC)": "3.39 أوم/كم", "درجة مقاومة اللهب": "عالية (Low Smoke, Halogen Free)", "جهد التشغيل المقنن": "AC 1.0/1.0 كيلوفولت — DC 1.5 كيلوفولت", "مادة العزل والغلاف": "بولي أوليفين متشابك كيميائيًا منخفض الدخان خالٍ من الهالوجين (XLPO/XLPE)", "القطر الخارجي للكابل": "6.3 مم", "التيار الأقصى عند 60°م": "57 أمبير", "اختبار العزل (Withstand Test)": "AC 6.5 كيلوفولت/5 دقائق — DC 15 كيلوفولت/5 دقائق", "مقاومة الأشعة فوق البنفسجية": "نعم"}, "available": true, "maxSolarKw": null, "description": "كابل شمسي أحادي القطب مقاس 6 مم² من طراز SI-H1Z2Z2-K، مصمم خصيصًا لتوصيل الألواح الشمسية بالانفرتر. العزل والغلاف من مادة XLPO/XLPE متشابكة كيميائيًا (Cross-linked)، منخفضة الدخان وخالية من الهالوجين، مقاومة للأشعة فوق البنفسجية والعوامل الجوية، ومناسبة للتركيب الخارجي طويل الأمد وفي درجات الحرارة العالية والمنخفضة. حاصل على اعتماد TÜV SÜD EN50618:2014 مع تصنيف مقاومة الحريق CPR B2ca-s1a,d1,a1، وهو ذات مواصفات متوافقة أيضًا مع معيار TÜV Rheinland 2PfG 1169 الأكثر شيوعًا عالميًا لكابلات الطاقة الشمسية.", "datasheetUrl": "https://www.veichi.com/product/si-photovoltaic-dc-cable.html"}}}, {"rows": [["MCCB DC 100A", "1000 VDC", "139.00", "159.85"], ["MCCB DC 125A", "1000 VDC", "149.00", "171.35"], ["MCCB DC 160A", "1000 VDC", "169.00", "194.35"], ["MCCB DC 200A", "1000 VDC", "189.00", "217.35"], ["MCCB DC 250A", "1000 VDC", "239.00", "274.85"], ["MCCB DC 280A", "1000 VDC", "369.00", "424.35"], ["MCCB DC 400A", "1000 VDC", "799.00", "918.85"], ["MCCB DC 500A", "1000 VDC", "899.00", "1033.85"], ["MCCB DC 630A", "1000 VDC", "1099.00", "1263.85"], ["FUSE 20A", "1000 VDC", "9.00", "10.35"], ["FUSE 25A", "1000 VDC", "11.00", "12.65"], ["FUSE 32A", "1000 VDC", "14.00", "16.10"], ["Holder 32A", "1000 VDC", "12.00", "13.80"]], "columns": ["الصنف", "الوصف", "السعر", "السعر شامل الضريبة"], "category": "قواطع وفيوزات DC", "categoryInfo": "", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/a12efd80-a33d-4748-bffd-e52578a2c303.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "100 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 100 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "1": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "125 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 125 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "2": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "160 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 160 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "3": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "200 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 200 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "4": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "250 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 250 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "5": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "280 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 280 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "6": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "400 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 400 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "7": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "500 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 500 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "8": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية من التيار الزائد وقصر الدائرة + فصل يدوي للعزل", "أقصى جهد عزل": "1000 فولت DC", "التيار المقنن": "630 أمبير", "عدد الأقطاب المعتاد": "2P (قطبين) لدوائر DC"}, "available": true, "description": "قاطع دائرة مصبوب (MCCB) مخصص للتيار المستمر (DC) بتيار مقنن 630 أمبير وجهد عزل أقصى 1000 فولت DC، يحمي دائرة الألواح الشمسية أو الانفرتر من التيار الزائد وقصر الدائرة، ويعمل أيضًا كمفتاح فصل يدوي لعزل الدائرة بأمان أثناء الصيانة.", "datasheetUrl": null}, "9": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "20 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 20 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "10": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "25 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 25 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "11": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "حماية سلسلة الألواح من التيار الزائد بالانصهار عند التجاوز", "أقصى جهد": "1000 فولت DC", "التيار المقنن": "32 أمبير"}, "available": true, "description": "فيوز (مصهر) حماية للتيار المستمر بتيار مقنن 32 أمبير وجهد أقصى 1000 فولت DC، يقطع الدائرة بالانصهار عند تجاوز التيار الحد الآمن، ويُركَّب عادة داخل صندوق التجميع لحماية كل سلسلة ألواح على حدة.", "datasheetUrl": null}, "12": {"brand": "VEICHI", "image": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/37ee5962-630e-4976-b72b-adcbf4b0fa05.jpg", "specs": {"الوظيفة": "تركيب وتثبيت الفيوز بشكل آمن وقابل للاستبدال", "التيار المقنن": "32 أمبير"}, "available": true, "description": "حامل فيوز (Fuse Holder) بتيار مقنن 32 أمبير، يُستخدم لتركيب وتثبيت الفيوزات داخل صندوق التجميع بشكل آمن وقابل للاستبدال بسهولة عند الحاجة.", "datasheetUrl": null}}}, {"rows": [["VEICHI Pump Inverter 0.75KW", "850V", "3.0A", "", ""], ["VEICHI Pump Inverter 1.5KW", "850V", "4.0A", "", ""], ["VEICHI Pump Inverter 2.2KW", "850V", "6A", "610.00", "701.50"], ["VEICHI Pump Inverter 4KW", "850V", "10A", "", ""], ["VEICHI Pump Inverter 5.5KW", "850V", "13A", "720.00", "828.00"], ["VEICHI Pump Inverter 7.5KW", "850V", "17A", "999.00", "1148.85"], ["VEICHI Pump Inverter 11KW", "850V", "25A", "1133.00", "1302.95"], ["VEICHI Pump Inverter 15KW", "850V", "32A", "", ""], ["VEICHI Pump Inverter 18.5KW", "850V", "38A", "1799.00", "2068.85"], ["VEICHI Pump Inverter 22KW", "850V", "45A", "2111.00", "2427.65"], ["VEICHI Pump Inverter 30KW", "850V", "60A", "2777.00", "3193.55"], ["VEICHI Pump Inverter 37KW", "850V", "75A", "3333.00", "3832.95"], ["VEICHI Pump Inverter 45KW", "850V", "90A", "", ""], ["VEICHI Pump Inverter 55KW", "850V", "110A", "4999.00", "5748.85"], ["VEICHI Pump Inverter 75KW", "850V", "150A", "5777.00", "6643.55"], ["VEICHI Pump Inverter 90KW", "850V", "180A", "7222.00", "8305.30"], ["VEICHI Pump Inverter 110KW", "850V", "210A", "8333.00", "9582.95"], ["VEICHI Pump Inverter 132KW", "850V", "250A", "11222.00", "12905.30"], ["VEICHI Pump Inverter 160KW", "850V", "310A", "12333.00", "14182.95"], ["VEICHI Pump Inverter 185KW", "850V", "340A", "", ""], ["VEICHI Pump Inverter 200KW", "850V", "380A", "17444.00", "20060.60"], ["VEICHI Pump Inverter 220KW", "850V", "415A", "", ""], ["VEICHI Pump Inverter 250KW", "850V", "470A", "21111.00", "24277.65"], ["VEICHI Pump Inverter 280KW", "850V", "510A", "", ""], ["VEICHI Pump Inverter 315KW", "850V", "600A", "22999.00", "26448.85"], ["VEICHI Pump Inverter 355KW", "850V", "670A", "36666.00", "42165.90"], ["VEICHI Pump Inverter 400KW", "850V", "750A", "43333.00", "49832.95"], ["VEICHI Pump Inverter 450KW", "850V", "810A", "", ""], ["VEICHI Pump Inverter 500KW", "850V", "860A", "49999.00", "57498.85"], ["VEICHI Pump Inverter 560KW", "850V", "990A", "53333.00", "61332.95"], ["VEICHI Pump Inverter 630KW", "850V", "1100A", "73333.00", "84332.95"], ["VEICHI Pump Inverter 710KW", "850V", "1260A", "79999.00", "91998.85"]], "columns": ["الموديل", "أقصى جهد DC", "التيار المقنن", "السعر", "السعر شامل الضريبة"], "category": "انفرتر مضخات VEICHI", "categoryInfo": "عائلة انفرترات الطاقة الشمسية لمضخات المياه من VEICHI (سلسلة SI) — تحوّل التيار المستمر القادم من الألواح الشمسية مباشرة إلى تيار متردد لتشغيل مضخات المياه (طرد مركزي، آبار عميقة، ري)، بتقنية MPPT مدمجة لاستخلاص أقصى طاقة ممكنة من الألواح. تدعم أيضًا التغذية من كهرباء الشبكة كمصدر احتياطي عند غياب الشمس. تُستخدم على نطاق واسع في الري الزراعي وتوريد المياه بالمناطق النائية، وتغطي نطاق قدرات من 2.2 كيلوواط حتى 710 كيلوواط بثلاث فئات: فئة اقتصادية 220 فولت، فئة IP65 للتركيب الخارجي المباشر بجانب المضخة، وفئة صناعية للقدرات الكبيرة.", "categoryImage": "https://xhgwvszdatqlvlgqiikj.supabase.co/storage/v1/object/public/product-images/6a4c88ec-be0a-4f6e-a40b-ce438416cec2.jpg", "productDetails": {"0": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 1, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "1": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 2.2, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "2": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 3.3, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "3": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 5.6, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "4": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 8, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "5": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 10, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "6": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si21/si21-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 14.3, "description": "موديلات بجهد دخل DC حتى 450 فولت، مناسبة لتغذية أحادية أو ثلاثية الطور 220 فولت — فئة اقتصادية للمضخات الصغيرة والمتوسطة (2.2 حتى 22 كيلوواط)، للتركيب الداخلي في لوحة كهربائية.", "datasheetUrl": "https://d.veichi.com/datasheet/si21-solar-pump-inverter-datasheet.pdf"}, "7": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 19.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "8": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 23.4, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "9": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 28.6, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "10": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 39, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "11": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 48.1, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "12": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 58.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "13": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 71.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "14": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 97.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "15": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 121.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "16": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 148.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "17": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 178.2, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "18": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 216, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "19": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 249.75, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "20": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 270, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "21": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 297, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "22": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 337.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "23": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 378, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "24": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 425.25, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "25": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 479.25, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "26": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 540, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "27": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": false, "maxSolarKw": 607.5, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "28": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 675, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "29": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si23/si23-all.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 756, "description": "موديلات بجهد دخل DC حتى 900 فولت لتغذية ثلاثية الطور 380-415 فولت، للتركيب الداخلي في كابينة أو لوحة كهربائية — تغطي نطاقًا واسعًا من القدرات من 2.2 حتى 710 كيلوواط، مناسبة للمشاريع الكبيرة ومحطات الضخ الصناعية.", "datasheetUrl": "https://d.veichi.com/datasheet/si23-solar-pump-inverter-datasheet.pdf"}, "30": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si30/si30-1.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 850.5, "description": "موديلات بتصنيف حماية IP65 مقاومة للماء والغبار، تُركّب مباشرة بجانب المضخة في الهواء الطلق بدون الحاجة لكابينة — مناسبة لمشاريع الري الزراعي في المزارع والمناطق النائية (4 حتى 22 كيلوواط).", "datasheetUrl": "https://d.veichi.com/datasheet/si30-solar-pump-inverter-datasheet.pdf"}, "31": {"brand": "VEICHI", "image": "https://www.veichi.com/skin/vcen/images/product/si30/si30-1.jpg", "specs": {"الوظيفة": "تحويل تيار DC من الألواح الشمسية إلى AC لتشغيل مضخات المياه مباشرة", "تقنية MPPT": "تتبع نقطة القدرة القصوى لاستخلاص أقصى طاقة من الألواح الشمسية", "الاستخدامات": "تشغيل المواتير الكهربائية والمضخات الغاطسة (الغطاسات) بالطاقة الشمسية أو كهرباء الشبكة، بشكل مستقر وكفاءة عالية", "مصدر التغذية": "شمسي (DC) أو كهرباء الشبكة (AC) كمصدر احتياطي عند غياب الشمس", "أنواع المضخات المدعومة": "طرد مركزي، آبار عميقة، ري، مسابح، نافورات"}, "available": true, "maxSolarKw": 958.5, "description": "موديلات بتصنيف حماية IP65 مقاومة للماء والغبار، تُركّب مباشرة بجانب المضخة في الهواء الطلق بدون الحاجة لكابينة — مناسبة لمشاريع الري الزراعي في المزارع والمناطق النائية (4 حتى 22 كيلوواط).", "datasheetUrl": "https://d.veichi.com/datasheet/si30-solar-pump-inverter-datasheet.pdf"}}}], "concretePerUnit": 230, "defaultPanelKey": "Aiko|665", "earthingPerUnit": 2500, "flexTubePerUnit": 50, "hpCapacityRatio": 1.15, "leadsWebhookUrl": "https://script.google.com/macros/s/AKfycbx6McxQSAcXLC84nBQDkd6KSHYx2tUVU-81yCJP4WgiatFpw0FJQ5jXCieBIXpfPhhh/exec", "steelPanelPerHP": 16, "combinerHeadroom": 1.1, "maxStringVoltage": 720, "reactorMarkupPct": 20, "transportMinimum": 2000, "transportPerTrip": 200, "cableLowMultiplier": 45, "defaultDiscountIdx": 0, "panelMarginPerWatt": 0.02, "cableHighMultiplier": 90, "elecInstallPerPanel": 30, "mechInstallPerPanel": 40, "readyOffgridSystems": [{"id": 1, "name": "ديوانية الدوري", "notes": "أُعيد تسعيرها بمعدات فيتشي (توريد خامات فقط، بدون تركيب/شاسيه). السعر القديم كان 27,370 بمعدات هويمايلز.", "acType": "سبيلت", "cables": "60 كيبل 6ML 6م، 4 توصيلات MC4-1، 8 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 28534, "lampCount": 20, "lampHours": 12, "acCountDay": 2, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 18, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 2, "acHoursNight": 6, "batteryCount": 3, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "شاشة تلفزيون 100 واط - 4 ساعات", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 8KW (TWIN) MPPT", "inverterPowerW": 8000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 2, "name": "مجلس المقناص", "notes": "أُعيد تسعيرها بمعدات فيتشي (توريد خامات فقط). السعر القديم كان 22,345.", "acType": "سبيلت", "cables": "60 كيبل 6ML 6م، 4 توصيلات MC4-1، 6 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 23100, "lampCount": 10, "lampHours": 12, "acCountDay": 2, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 18, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 2, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 8KW (TWIN) MPPT", "inverterPowerW": 8000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 3, "name": "غرفة السكن", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 14,285.", "acType": "سبيلت", "cables": "40 كيبل 6ML 6م، 2 توصيلات MC4-1، 8م كيبل 35مل أحمر وأسود", "status": "متوفر", "priceSar": 16868, "lampCount": 15, "lampHours": 8, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 10, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 3, "batteryModel": "VCLB-5k-w01", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 1500, "inverterBrand": "فيتشي", "inverterModel": "SISV 6.2KW (TWIN) MPPT", "inverterPowerW": 6200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 4, "name": "غرفة المشراق", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 10,900. مصحّحة سابقًا: جهازا تبريد مختلفان (سبيلت نهارًا / صحراوي أضعف ليلاً).", "acType": "سبيلت نهارًا + صحراوي ليلاً", "cables": "30 كيبل 6ML 6م، 2 توصيلات MC4-1، 6 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 11979, "lampCount": 10, "lampHours": 12, "acCountDay": 1, "acHoursDay": 6, "lampPowerW": 15, "panelBrand": "Aiko", "panelCount": 8, "acPowerDayW": 1000, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 7, "batteryCount": 1, "batteryModel": "VCLB-10k-w02", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 100, "inverterBrand": "فيتشي", "inverterModel": "SISV 6.2KW (TWIN) MPPT", "inverterPowerW": 6200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 10.24}, {"id": 5, "name": "كرفان المدهال", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول تقني من بطارية جافة (200Ah) لليثيوم — السعر القديم كان 7,210 بفرق +61%. افتراض: البطارية الجافة القديمة كانت 12V.", "acType": "سبيلت (نهارًا فقط)", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 10564, "lampCount": 10, "lampHours": 6, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 6, "acPowerDayW": 1500, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 2, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SISV-24V 4.2KW (TWIN) MPPT", "inverterPowerW": 4200, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 6, "name": "المخيم الاقتصادي", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول من بطارية جافة لليثيوم — السعر القديم كان 6,200 بفرق +80%. افتراض: البطارية الجافة القديمة كانت 12V. 15 لمبة × 10 واط = 150 واط، مؤكَّد من العميل سابقًا.", "acType": "صحراوي", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 10067, "lampCount": 15, "lampHours": 6, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 5, "acPowerDayW": 100, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 1, "acHoursNight": 6, "batteryCount": 2, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 100, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 7, "name": "المخيم الصغير", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 5,145 بفرق +58%. افتراض: البطارية الجافة القديمة كانت 12V.", "acType": "صحراوي (نهارًا فقط)", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 7532, "lampCount": 10, "lampHours": 8, "acCountDay": 1, "acHoursDay": 8, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 5, "acPowerDayW": 200, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 8, "name": "مكشات", "notes": "أُعيد تسعيرها بمعدات فيتشي. السعر القديم كان 4,315 بفرق +79%. لا يوجد مكيف في هذه المنظومة إطلاقًا - غير مناسبة لعميل محتاج تبريد.", "acType": "لا يوجد", "cables": "20 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 7096, "lampCount": 10, "lampHours": 8, "acCountDay": 0, "acHoursDay": 0, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 4, "acPowerDayW": 0, "batteryType": "ليثيوم", "fridgeCount": 1, "fridgeHours": 24, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-5.1K-200-Li", "fridgePowerW": 100, "otherDevices": "", "acPowerNightW": 0, "inverterBrand": "فيتشي", "inverterModel": "SIS-24V 3KW MPPT", "inverterPowerW": 3000, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 5.12}, {"id": 9, "name": "الراعي", "notes": "أُعيد تسعيرها بمعدات فيتشي: تحول من بطارية جافة لليثيوم — السعر القديم كان 1,453 بفرق +117%. لا يوجد إنفرتر أصلاً (منظم شحن فقط)، فرق السعر بالكامل من البطارية.", "acType": "لا يوجد", "cables": "10 كيبل 6ML 6م، 1 توصيلات MC4-1، 1 وصلة 35مل مع نهاية كيبل 1م", "status": "متوفر", "priceSar": 2990, "lampCount": 1, "lampHours": 8, "acCountDay": 0, "acHoursDay": 0, "lampPowerW": 10, "panelBrand": "Aiko", "panelCount": 1, "acPowerDayW": 0, "batteryType": "ليثيوم", "fridgeCount": 0, "fridgeHours": 0, "panelPowerW": 665, "acCountNight": 0, "acHoursNight": 0, "batteryCount": 1, "batteryModel": "VCLB-1.2K-100-Li", "fridgePowerW": 0, "otherDevices": "شاحن جوال (بدون تفاصيل قدرة)", "acPowerNightW": 0, "inverterBrand": "لا يوجد (منظم شحن 20A فقط)", "inverterModel": null, "inverterPowerW": 0, "batteryCapacityUnit": "kWh", "batteryUnitCapacity": 1.28}], "structurePriceFixed": 1499, "hybridInverterCatalog": [{"kw": 1, "model": "SIS4-12V 1KW MPPT", "priceExclVat": 449}, {"kw": 2, "model": "SIS4-12V 2KW MPPT", "priceExclVat": 699}, {"kw": 3, "model": "SIS-24V 3KW MPPT", "priceExclVat": 999}, {"kw": 4.2, "model": "SISV-24V 4.2KW (TWIN) MPPT", "priceExclVat": 1049}, {"kw": 5, "model": "SIS 5KW-S MPPT", "priceExclVat": 1149}, {"kw": 6.2, "model": "SISV 6.2KW (TWIN) MPPT", "priceExclVat": 1199}, {"kw": 8, "model": "SISV 8KW (TWIN) MPPT", "priceExclVat": 2299}, {"kw": 10.2, "model": "SISV 11KW (TWIN) MPPT", "priceExclVat": 2499}, {"kw": 10, "model": "VLT 10KW 3P IP65", "priceExclVat": 5899}, {"kw": 12, "model": "VLT 12KW 3P IP65", "priceExclVat": 6399}, {"kw": 15, "model": "VLT 15KW 3P IP65", "priceExclVat": 7499}, {"kw": 20, "model": "VHT 20KW IP65", "priceExclVat": 8499}, {"kw": 30, "model": "VHT 30KW IP65", "priceExclVat": 15499}, {"kw": 50, "model": "VHT 50KW IP65", "priceExclVat": 19499}], "inverterPowerIncrease": 0, "panelsPerStringAdjust": 0, "combinerMinSpareStrings": 0, "structurePriceRotational": 1499}	2026-09-21 15:37:26.932+00
\.


--
-- Data for Name: project_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_costs (id, project_id, cost_type, description, amount, created_at) FROM stdin;
1	2	other	\N	73000	2026-08-16 15:34:49.01963+00
2	1	other	\N	173500	2026-08-16 15:36:07.476788+00
3	5	other	\N	161000	2026-08-16 15:58:48.810602+00
4	6	materials	\N	10403	2026-08-16 16:22:58.417414+00
6	6	transportation	\N	50	2026-08-18 20:17:52.31716+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, opportunity_id, customer_id, site_id, project_number, contract_value, scope_type, contract_signed_date, project_manager, engineer, planned_supply_date, actual_supply_date, planned_install_date, actual_install_date, status, notes, created_at, updated_at, id_system_type, inverter_spec, panel_spec, structure_type) FROM stdin;
5	1	12	\N	PROJ-0531133171-LUM-P-AUG2026-1555	175000	lumpsum	2026-07-09	م محمود الحسيني	م محمود الحسيني	2026-08-09	2026-08-09	2026-08-10	2026-08-10	commissioned		2026-08-16 15:55:39.989228+00	2026-08-16 15:57:45.316+00	pump	\N	\N	\N
6	7	26	\N	PROJ-0554001217-SUP-P-AUG2026	10925	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-18	2026-08-18	2026-08-18	2026-08-18	commissioned		2026-08-16 16:20:23.937828+00	2026-08-18 20:15:39.238+00	pump	\N	\N	\N
1	2	11	\N	PROJ-0555115352-SUP-P-AUG2026	175000	supply	2026-07-01	م محمود الحسيني	م محمود الحسيني	2026-07-09	2026-08-09	2026-08-09	2026-08-09	commissioned		2026-08-12 06:23:38.786816+00	2026-08-16 15:40:00.691+00	pump	\N	\N	\N
2	5	12	\N	PROJ-0531133171-LUM-P-AUG2026	85000	lumpsum	2026-03-15	م محمود الحسيني	م محمود الحسيني	2026-03-16	2026-03-16	2026-03-31	2026-03-31	commissioned		2026-08-12 11:42:14.266973+00	2026-08-16 15:28:26.853+00	pump	\N	\N	\N
3	4	9	\N	PROJ-0555115688-SUP-P-AUG2026	55000	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-17	2026-08-17	2026-08-17	2026-08-17	in_progress		2026-08-16 15:13:21.761183+00	2026-08-16 15:19:13.009+00	pump	\N	\N	\N
4	3	9	\N	PROJ-0555115688-SUP-P-AUG2026-1513	95000	supply	2026-08-16	م محمود الحسيني	م محمود الحسيني	2026-08-17	2026-08-17	2026-08-17	2026-08-17	commissioned		2026-08-16 15:13:36.488194+00	2026-08-24 19:05:47.034+00	pump	\N	\N	\N
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, opportunity_id, customer_id, quotation_number, version, linked_quote_id, valid_until, sales_person, engineer, items, discount_total, vat_percent, subtotal, vat_amount, total, cost, gross_profit, gross_margin, status, notes, created_by, created_at, updated_at, ql_reference, id_system_type, pump_hp, capacity_kw, inverter_spec, panel_spec, structure_type, scope_type) FROM stdin;
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, rep_username, rep_display_name, client_name, client_phone, hp, final_total, snapshot, created_at, customer_id) FROM stdin;
73	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكزافيت	501411010	100	98813	{"hp": 100, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-09-05 09:05:21.140688+00	38
74	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكزافيت	501411010	100	148514	{"hp": 100, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-09-05 09:06:13.065612+00	38
3	ALHUSSEINI	م محمود الحسيني	الشيخ علوش بن محسن بن قويد	0504101359	600	838137	{"hp": 600, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:16:46.288822+00	3
1	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:13:06.019153+00	\N
4	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	639497	{"hp": 450, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:23:01.30727+00	5
5	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	417794	{"hp": 450, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:24:14.095115+00	5
6	ALHUSSEINI	م محمود الحسيني	عبدالعزيز محمد الدوسري	0599909493	450	417794	{"hp": 450, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-17 11:24:59.253852+00	5
10	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	465291	{"hp": 350, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 14:43:42.332633+00	4
11	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	465291	{"hp": 350, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 14:44:36.804264+00	4
12	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	457400	{"hp": 350, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 15:02:30.399101+00	4
75	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	112082	{"hp": 120, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:45:42.673377+00	\N
76	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	112082	{"hp": 120, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:46:10.53457+00	\N
16	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	75	68785	{"hp": 75, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:25:15.645822+00	\N
77	ALHUSSEINI	م محمود الحسيني	عبدالرحمن منصور - الكرافيت	551411010	120	169904	{"hp": 120, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-05 17:46:55.35918+00	\N
36	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:00:47.429411+00	7
37	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:01:47.017741+00	7
38	ALHUSSEINI	م محمود الحسيني	عبدالله محمد الدوسري 	0531457772	400	372149	{"hp": 400, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 10:02:53.941281+00	7
40	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0567712263	450	423433	{"hp": 450, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-02 19:23:16.289635+00	8
41	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0567712263	450	630013	{"hp": 450, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-02 19:24:06.062644+00	8
43	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	100	97001	{"hp": 100, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 533, "discountOverrideIdx": null}	2026-08-03 06:55:44.225579+00	9
44	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	100	146410	{"hp": 100, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 533, "discountOverrideIdx": null}	2026-08-03 06:56:34.14753+00	9
78	ALHUSSEINI	م محمود الحسيني	تبو مهدي جار العقيد	556635456	10	8867	{"hp": 10, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-11 16:59:44.085556+00	40
2	ALHUSSEINI	م محمود الحسيني	0	0000	600	838137	{"hp": 600, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-12 11:14:51.564801+00	\N
7	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-18 08:53:11.228881+00	\N
8	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	706620	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-18 19:11:09.722992+00	\N
9	ALHUSSEINI	م محمود الحسيني	0	0	500	686610	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 12:27:31.797831+00	\N
14	ALHUSSEINI	م محمود الحسيني	0	0	300	273281	{"hp": 300, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-22 07:10:28.107902+00	\N
15	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-27 11:57:48.794924+00	\N
17	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	75	68785	{"hp": 75, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:29:09.170898+00	\N
19	ALHUSSEINI	م محمود الحسيني	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 10:59:24.442053+00	\N
20	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:12:48.463555+00	\N
21	ALHUSSEINI	م محمود الحسيني	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:13:48.248172+00	\N
50	ALHUSSEINI	م محمود الحسيني	محمد جبران	0557761677	60	9724	{"hp": 60, "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 440, "discountOverrideIdx": null}	2026-08-08 07:44:04.818685+00	10
18	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0555117066	75	68785	{"hp": 75, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 05:29:43.514222+00	\N
22	ALHUSSEINI	م محمود الحسيني	0	0	500	462121	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-30 11:17:45.304218+00	\N
23	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 10:53:17.858084+00	\N
24	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 10:59:08.178986+00	\N
25	\N	الحاسبة الآلية (تسعير مباشر من العميل)	محمد 	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:03:45.389996+00	\N
26	\N	الحاسبة الآلية (تسعير مباشر من العميل)	محمد 	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:03:59.077388+00	\N
27	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:08:50.053896+00	\N
28	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:11:05.596633+00	\N
29	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:14:06.261231+00	\N
30	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:17:03.157882+00	\N
31	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:19:29.71914+00	\N
32	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	692567	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-31 11:19:40.625108+00	\N
33	ALHUSSEINI	م محمود الحسيني	0	0	200	181391	{"hp": 200, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:04:54.58689+00	\N
34	ALHUSSEINI	م محمود الحسيني	0	0	200	181391	{"hp": 200, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:05:48.011051+00	\N
35	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	200	272147	{"hp": 200, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 06:06:53.547374+00	\N
39	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	500	695894	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-01 12:02:06.453292+00	\N
42	ALHUSSEINI	م محمود الحسيني	0	0	100	97161	{"hp": 100, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -2000, "discountOverrideIdx": null}	2026-08-03 06:51:46.065277+00	\N
45	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0	500	714203	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-03 10:05:15.001621+00	\N
46	ALHUSSEINI	م محمود الحسيني	عبدالرحمن ناصر محمد القحطاني	0	500	714203	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-03 10:05:19.275653+00	\N
47	ALHUSSEINI	م محمود الحسيني	0	0	60	3517	{"hp": 60, "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": false, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-04 21:08:15.962087+00	\N
48	ALHUSSEINI	م محمود الحسيني	0	0	60	3517	{"hp": 60, "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": false, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-04 21:08:41.34035+00	\N
49	ALHUSSEINI	م محمود الحسيني	0	0	500	708125	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -500, "discountOverrideIdx": null}	2026-08-06 19:25:25.476823+00	\N
79	ALHUSSEINI	م محمود الحسيني	سالم مرزوق -٠ الكرافيت 	555115510	\N	42715	{"type": "product-cart", "items": [{"qty": 32, "name": "Jinko 650W", "price": 393, "category": "الألواح الشمسية"}, {"qty": 2, "name": "Sinoboly-628A-51V", "price": "11025", "category": "بطاريات ليثيوم"}, {"qty": 2, "name": "SISV 6.2KW (TWIN) MPPT", "price": "1258.95", "category": "شواحن/انفرترات هجين MPPT"}]}	2026-09-16 16:31:45.301558+00	41
52	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	60	11862	{"hp": 60, "toggles": {"mc4": false, "ip65": true, "earth": false, "panel": false, "cables": false, "supply": false, "reactor": true, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-16 14:25:58.355688+00	26
51	ALHUSSEINI	م محمود الحسيني	الشيخ حمود بن ناصر	0555115688	50	50001	{"hp": 50, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -1685, "discountOverrideIdx": null}	2026-08-12 11:28:11.967621+00	\N
80	\N	الحاسبة الآلية (تسعير مباشر من العميل)	0	0	350	493544	{"hp": 350, "toggles": {"mc4": true, "ip65": true, "earth": true, "panel": true, "cables": true, "supply": true, "reactor": true, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 11, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-19 08:41:28.452395+00	42
13	ALHUSSEINI	م محمود الحسيني	محمد الحارثي	0509837564	350	308616	{"hp": 350, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-07-19 15:06:16.741853+00	4
53	ALHUSSEINI	م محمود الحسيني	أبو ماجد	0509927849	10	9129	{"hp": 10, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:24:05.206398+00	28
54	ALHUSSEINI	م محمود الحسيني	عادل ديماس الجوف 	0560595743	250	324069	{"hp": 250, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 9, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:26:23.086288+00	29
55	ALHUSSEINI	م محمود الحسيني	الشيخه الاميره 	0506222121	150	195760	{"hp": 150, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 9, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-18 05:49:27.549624+00	30
56	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	696916	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-20 11:48:22.751577+00	31
57	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	704644	{"hp": 500, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:10:43.151687+00	31
58	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:11:46.35746+00	31
59	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:12:15.895847+00	31
60	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	693144	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:13:00.052612+00	31
61	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	500	474682	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": -6000, "discountOverrideIdx": null}	2026-08-21 11:14:47.706739+00	31
62	ALHUSSEINI	م محمود الحسيني	ابو منه	0565480579	500	467782	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:47:52.627672+00	32
63	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:48:20.510326+00	32
64	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:50:54.804812+00	32
65	ALHUSSEINI	م محمود الحسيني	0565480579	0565480579	500	467782	{"hp": 500, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-22 05:56:59.084815+00	32
66	ALHUSSEINI	م محمود الحسيني	فألح مفرج الطويله	0551833823	600	560308	{"hp": 600, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-08-23 08:05:24.522245+00	33
67	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:17:56.511649+00	31
68	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:18:55.645016+00	31
69	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	757774	{"hp": 800, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:19:17.742217+00	31
70	ALHUSSEINI	م محمود الحسيني	عادل ماسه الوادي	0550900968	800	1125448	{"hp": 800, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:20:01.62291+00	31
81	ALHUSSEINI	م محمود الحسيني	0	0	100	95243	{"hp": 100, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 0, "structureType": "FIXED", "specialDiscountAmt": 0, "discountOverrideIdx": null}	2026-09-19 10:33:05.401654+00	42
71	ALHUSSEINI	م محمود الحسيني	احمد حامد السوداني	0565480579	400	375612	{"hp": 400, "toggles": {"mc4": true, "ip65": false, "earth": false, "panel": true, "cables": true, "supply": false, "reactor": false, "combiner": true, "concrete": false, "inverter": true, "elecworks": false, "structure": false, "civilworks": false}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:31:05.771096+00	32
72	ALHUSSEINI	م محمود الحسيني	احمد حامد السوداني	0565480579	400	559594	{"hp": 400, "toggles": {"mc4": true, "ip65": true, "earth": false, "panel": true, "cables": true, "supply": true, "reactor": false, "combiner": true, "concrete": true, "inverter": true, "elecworks": true, "structure": true, "civilworks": true}, "panelIdx": 10, "structureType": "FIXED", "inverterBrandIdx": 0, "specialDiscountAmt": 0, "discountOverrideIdx": 0}	2026-08-24 11:31:51.084862+00	32
\.


--
-- Data for Name: reps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reps (id, username, password_hash, display_name, active, created_at, session_version, permissions) FROM stdin;
1	ALHUSSEINI	3ba982075eba89702c1637b9ce03d8a3d8b6dce9434dd07a4c30b5525ab27850	م محمود الحسيني	t	2026-07-12 10:56:49.950578+00	2	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
2	AhmedBnHamd	15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225	احمد بن حمد	f	2026-07-15 20:30:09.782466+00	1	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
3	test	9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08	test	f	2026-07-22 06:30:58.215591+00	1	{"calcs": false, "pricing": false, "products": false, "portfolio": false}
\.


--
-- Data for Name: service_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_tickets (id, customer_id, site_id, asset_id, project_id, ticket_number, issue_description, priority, status, assigned_engineer, resolution_notes, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_surveys (id, opportunity_id, site_id, customer_id, engineer_name, survey_date, gps_lat, gps_lng, pump_type, pump_manufacturer, pump_model, pump_hp, pump_kw, flow, head, well_depth, static_water_level, dynamic_water_level, motor_manufacturer, motor_model, motor_hp, motor_kw, motor_voltage, motor_current, motor_frequency, motor_rpm, motor_power_factor, motor_efficiency, existing_diesel_generator, generator_capacity, diesel_consumption, electricity_grid, electricity_tariff, existing_solar, hours_per_day, days_per_month, seasonal_operation, required_water_production, available_area, roof_or_ground, shading, orientation, tilt, soil, access, distance, cable_length, technical_notes, photos, documents, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, customer_id, name, region, city, location_address, gps_lat, gps_lng, google_maps_link, farm_area, agricultural_activity, number_of_wells, number_of_pumps, water_source, well_depth, required_water_flow, required_operating_hours, current_energy_source, diesel_consumption, electricity_consumption, existing_system, technical_notes, photos, documents, created_at, updated_at) FROM stdin;
1	12	125	الوسطي_-_وادي_الدواسر	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	طريق خميس بعد الصوامع	[]	[]	2026-08-13 05:16:37.922777+00	2026-08-13 05:16:37.922777+00
2	9	مزرعه الشيخ حمود بن ناصر	الوسطي_-_وادي_الدواسر	\N	https://maps.app.goo.gl/9XVWYhLYzEFqsYZRA	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	الشماليه  من الطريق الدائري	[]	[]	2026-08-16 15:02:12.778161+00	2026-08-16 15:02:12.778161+00
\.


--
-- Data for Name: technical_studies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technical_studies (id, opportunity_id, site_survey_id, quote_id, pv_capacity, number_of_panels, panel_model, panel_wattage, inverter, inverter_capacity, pump, vfd, structure, dc_cables, ac_cables, protection, combiner_boxes, monitoring, expected_production, expected_operating_hours, estimated_diesel_saving, estimated_electricity_saving, capex, opex, estimated_roi, payback_period, notes, created_at, updated_at) FROM stdin;
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activities_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assets_id_seq', 11, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 42, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, true);


--
-- Name: crm_interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.crm_interactions_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 42, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 9, true);


--
-- Name: maintenance_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_contracts_id_seq', 1, false);


--
-- Name: opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.opportunities_id_seq', 7, true);


--
-- Name: payment_milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_milestones_id_seq', 5, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 3, true);


--
-- Name: project_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_costs_id_seq', 6, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 6, true);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotes_id_seq', 81, true);


--
-- Name: reps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reps_id_seq', 3, true);


--
-- Name: service_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_tickets_id_seq', 1, false);


--
-- Name: site_surveys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_surveys_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: technical_studies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.technical_studies_id_seq', 1, false);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: admin_secret admin_secret_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_secret
    ADD CONSTRAINT admin_secret_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: crm_interactions crm_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_pkey PRIMARY KEY (id);


--
-- Name: crm_settings crm_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_settings
    ADD CONSTRAINT crm_settings_pkey PRIMARY KEY (id);


--
-- Name: customers customers_phone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_key UNIQUE (phone);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: einvoice_config einvoice_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.einvoice_config
    ADD CONSTRAINT einvoice_config_pkey PRIMARY KEY (id);


--
-- Name: invoice_counters invoice_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_counters
    ADD CONSTRAINT invoice_counters_pkey PRIMARY KEY (counter_key);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: maintenance_contracts maintenance_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: payment_milestones payment_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT payment_milestones_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pricing_config pricing_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_config
    ADD CONSTRAINT pricing_config_pkey PRIMARY KEY (id);


--
-- Name: project_costs project_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: reps reps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_pkey PRIMARY KEY (id);


--
-- Name: reps reps_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_username_key UNIQUE (username);


--
-- Name: service_tickets service_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_pkey PRIMARY KEY (id);


--
-- Name: site_surveys site_surveys_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: site_surveys site_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: technical_studies technical_studies_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_opportunity_id_key UNIQUE (opportunity_id);


--
-- Name: technical_studies technical_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_pkey PRIMARY KEY (id);


--
-- Name: customers_last_quote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_last_quote_idx ON public.customers USING btree (last_quote_at DESC);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: idx_activities_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activities_customer ON public.activities USING btree (customer_id);


--
-- Name: idx_activities_opportunity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activities_opportunity ON public.activities USING btree (opportunity_id);


--
-- Name: idx_assets_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_customer ON public.assets USING btree (customer_id);


--
-- Name: idx_assets_opportunity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_opportunity_id ON public.assets USING btree (opportunity_id);


--
-- Name: idx_assets_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_serial ON public.assets USING btree (serial_number);


--
-- Name: idx_assets_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_site_id ON public.assets USING btree (site_id);


--
-- Name: idx_assets_warranty_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_warranty_end ON public.assets USING btree (warranty_end_date);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_log_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id);


--
-- Name: idx_contacts_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contacts_customer ON public.contacts USING btree (customer_id);


--
-- Name: idx_crm_interactions_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crm_interactions_customer ON public.crm_interactions USING btree (customer_id);


--
-- Name: idx_customers_next_follow_up; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_next_follow_up ON public.customers USING btree (next_follow_up_date);


--
-- Name: idx_customers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_status ON public.customers USING btree (status);


--
-- Name: idx_invoices_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_customer_id ON public.invoices USING btree (customer_id);


--
-- Name: idx_invoices_milestone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_milestone_id ON public.invoices USING btree (milestone_id);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_project ON public.invoices USING btree (project_id);


--
-- Name: idx_invoices_related_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_related_invoice_id ON public.invoices USING btree (related_invoice_id);


--
-- Name: idx_invoices_source_quotation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_source_quotation_id ON public.invoices USING btree (source_quotation_id);


--
-- Name: idx_maint_contracts_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maint_contracts_customer ON public.maintenance_contracts USING btree (customer_id);


--
-- Name: idx_maint_contracts_next_visit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maint_contracts_next_visit ON public.maintenance_contracts USING btree (next_visit_date);


--
-- Name: idx_maintenance_contracts_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_contracts_project_id ON public.maintenance_contracts USING btree (project_id);


--
-- Name: idx_milestones_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_milestones_project ON public.payment_milestones USING btree (project_id);


--
-- Name: idx_opportunities_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_contact_id ON public.opportunities USING btree (contact_id);


--
-- Name: idx_opportunities_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opportunities_site_id ON public.opportunities USING btree (site_id);


--
-- Name: idx_opps_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opps_customer ON public.opportunities USING btree (customer_id);


--
-- Name: idx_opps_follow_up; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opps_follow_up ON public.opportunities USING btree (next_follow_up_date);


--
-- Name: idx_opps_stage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_opps_stage ON public.opportunities USING btree (stage);


--
-- Name: idx_payments_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_project ON public.payments USING btree (project_id);


--
-- Name: idx_project_costs_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_costs_project ON public.project_costs USING btree (project_id);


--
-- Name: idx_projects_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_customer ON public.projects USING btree (customer_id);


--
-- Name: idx_projects_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_site_id ON public.projects USING btree (site_id);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_quotations_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_customer_id ON public.quotations USING btree (customer_id);


--
-- Name: idx_quotations_linked_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_linked_quote_id ON public.quotations USING btree (linked_quote_id);


--
-- Name: idx_quotations_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_number ON public.quotations USING btree (quotation_number);


--
-- Name: idx_quotations_opportunity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quotations_opportunity ON public.quotations USING btree (opportunity_id);


--
-- Name: idx_service_tickets_asset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_asset_id ON public.service_tickets USING btree (asset_id);


--
-- Name: idx_service_tickets_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_project_id ON public.service_tickets USING btree (project_id);


--
-- Name: idx_service_tickets_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_tickets_site_id ON public.service_tickets USING btree (site_id);


--
-- Name: idx_site_surveys_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_surveys_customer ON public.site_surveys USING btree (customer_id);


--
-- Name: idx_site_surveys_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_surveys_site_id ON public.site_surveys USING btree (site_id);


--
-- Name: idx_sites_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_customer ON public.sites USING btree (customer_id);


--
-- Name: idx_sites_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_region ON public.sites USING btree (region);


--
-- Name: idx_technical_studies_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_technical_studies_quote_id ON public.technical_studies USING btree (quote_id);


--
-- Name: idx_technical_studies_site_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_technical_studies_site_survey_id ON public.technical_studies USING btree (site_survey_id);


--
-- Name: idx_tickets_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_customer ON public.service_tickets USING btree (customer_id);


--
-- Name: idx_tickets_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_priority ON public.service_tickets USING btree (priority);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_status ON public.service_tickets USING btree (status);


--
-- Name: invoices_approval_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_approval_status_idx ON public.invoices USING btree (approval_status) WHERE (project_id IS NULL);


--
-- Name: invoices_project_id_null_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_project_id_null_idx ON public.invoices USING btree (created_at) WHERE (project_id IS NULL);


--
-- Name: invoices_rep_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_rep_username_idx ON public.invoices USING btree (rep_username);


--
-- Name: quotes_client_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_client_name_idx ON public.quotes USING btree (lower(client_name));


--
-- Name: quotes_client_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_client_phone_idx ON public.quotes USING btree (client_phone);


--
-- Name: quotes_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quotes_customer_id_idx ON public.quotes USING btree (customer_id);


--
-- Name: uq_invoices_one_credit_note; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_invoices_one_credit_note ON public.invoices USING btree (related_invoice_id) WHERE (document_type = 'credit_note'::text);


--
-- Name: invoices trg_invoices_block_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_block_delete BEFORE DELETE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_block_delete();


--
-- Name: invoices trg_invoices_block_tamper; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_block_tamper BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_block_tamper();


--
-- Name: invoices trg_invoices_require_issued_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_invoices_require_issued_at BEFORE INSERT ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.invoices_require_issued_at();


--
-- Name: activities activities_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: activities activities_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: assets assets_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: assets assets_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE SET NULL;


--
-- Name: assets assets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: contacts contacts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: crm_interactions crm_interactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_milestone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES public.payment_milestones(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_related_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_related_invoice_id_fkey FOREIGN KEY (related_invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_source_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_source_quotation_id_fkey FOREIGN KEY (source_quotation_id) REFERENCES public.quotations(id) ON DELETE SET NULL;


--
-- Name: maintenance_contracts maintenance_contracts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: maintenance_contracts maintenance_contracts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_contracts
    ADD CONSTRAINT maintenance_contracts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: opportunities opportunities_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: opportunities opportunities_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: opportunities opportunities_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: payment_milestones payment_milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT payment_milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: payments payments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_costs project_costs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: projects projects_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: projects projects_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: quotations quotations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: quotations quotations_linked_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_linked_quote_id_fkey FOREIGN KEY (linked_quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: quotations quotations_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: service_tickets service_tickets_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: service_tickets service_tickets_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: service_tickets service_tickets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: service_tickets service_tickets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: site_surveys site_surveys_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: site_surveys site_surveys_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: site_surveys site_surveys_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_surveys
    ADD CONSTRAINT site_surveys_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: sites sites_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: technical_studies technical_studies_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id) ON DELETE CASCADE;


--
-- Name: technical_studies technical_studies_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE SET NULL;


--
-- Name: technical_studies technical_studies_site_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technical_studies
    ADD CONSTRAINT technical_studies_site_survey_id_fkey FOREIGN KEY (site_survey_id) REFERENCES public.site_surveys(id) ON DELETE SET NULL;


--
-- Name: activities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_secret; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_secret ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings anyone can read settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "anyone can read settings" ON public.app_settings FOR SELECT USING (true);


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: contacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crm_interactions ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.crm_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: einvoice_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.einvoice_config ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_counters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_counters ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings only authenticated can update settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "only authenticated can update settings" ON public.app_settings FOR UPDATE USING ((( SELECT auth.role() AS role) = 'authenticated'::text));


--
-- Name: opportunities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_milestones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_milestones ENABLE ROW LEVEL SECURITY;

--
-- Name: payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

--
-- Name: pricing_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pricing_config ENABLE ROW LEVEL SECURITY;

--
-- Name: project_costs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_costs ENABLE ROW LEVEL SECURITY;

--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: quotations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quotations ENABLE ROW LEVEL SECURITY;

--
-- Name: quotes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;

--
-- Name: reps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reps ENABLE ROW LEVEL SECURITY;

--
-- Name: service_tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: site_surveys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.site_surveys ENABLE ROW LEVEL SECURITY;

--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: technical_studies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.technical_studies ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict Qotg90XoqDKPSwVslPWpaIzYvLhO9mTQyPPzaYHgkyr3PU0dGgbzRCFrpbc9qgW

